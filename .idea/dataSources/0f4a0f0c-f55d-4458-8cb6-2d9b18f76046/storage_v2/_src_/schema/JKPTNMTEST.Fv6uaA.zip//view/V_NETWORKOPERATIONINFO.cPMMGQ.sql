create view V_NETWORKOPERATIONINFO as
SELECT A.EVENTID,
       A.ROADID,
       H.ROADNAME,
       to_char(A.RECTIME, 'yyyy-mm-dd') RECTIME,
       to_char(A.PRESTORETIME, 'yyyy-mm-dd') PRESTORETIME,
       to_char(A.FRESTORETIME, 'yyyy-mm-dd') FRESTORETIME,
       A.STARTSTAKEID,
       A.ENDSTAKEID,
       abs(round(A.ENDSTAKEID - A.STARTSTAKEID, 3)) STAKESCOPE,
       A.DIR,
       fun_get_paramdicname('DirType', A.DIR) DIRNAME,
       A.EVENTTYPE,
       G.DICNAME EVENTTYPENAME,
       A.ORGID,
       D.ORGNAME,
       A.ISOVER,
       A.INFOTYPE,
       J.DICNAME INFOTYPENAME,
       floor((nvl(a.FRESTORETIME, sysdate) - A.RECTIME) * 24) TOTALTIME
  FROM JKPT_SJGL_EVENT A
 INNER JOIN JKPT_BASE_ORG D
    ON A.ORGID = D.ORGID
 INNER JOIN JKPT_BASE_ORG_ROAD H
    ON H.ROADID = A.ROADID
 INNER JOIN (select * from jkpt_comm_paramdic where GROUPTYPE in ('RoadConditionType','InformationType')) G
    ON A.EVENTTYPE = G.DICVALUE
 INNER JOIN (select * from jkpt_comm_paramdic where GROUPTYPE = 'InfoType') J
    ON A.INFOTYPE = J.DICVALUE order by A.Rectime desc,A.Infotype,A.Eventtype,A.Eventid desc, A.Frestoretime desc
/

