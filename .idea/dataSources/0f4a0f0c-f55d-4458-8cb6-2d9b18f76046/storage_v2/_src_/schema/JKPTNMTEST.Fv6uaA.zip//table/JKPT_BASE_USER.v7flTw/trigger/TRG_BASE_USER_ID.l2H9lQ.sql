create trigger TRG_BASE_USER_ID
  before insert
  on JKPT_BASE_USER
  for each row
declare
  -- local variables here
  v_userkeyid number;
begin
  select seq_base_user.nextval into v_userkeyid from dual;
  select v_userkeyid || '@ITC',v_userkeyid into :new.Userid,:new.userkeyid from dual;
end trg_base_user_id;


/

