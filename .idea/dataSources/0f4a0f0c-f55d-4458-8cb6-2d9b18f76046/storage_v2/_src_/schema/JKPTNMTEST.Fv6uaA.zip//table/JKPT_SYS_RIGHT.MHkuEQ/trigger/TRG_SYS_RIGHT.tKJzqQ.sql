create trigger TRG_SYS_RIGHT
  before insert
  on JKPT_SYS_RIGHT
  for each row
declare
  -- local variables here
begin
  select seq_sys_right.nextval into :new.id from dual;
end trg_sys_right;


/

