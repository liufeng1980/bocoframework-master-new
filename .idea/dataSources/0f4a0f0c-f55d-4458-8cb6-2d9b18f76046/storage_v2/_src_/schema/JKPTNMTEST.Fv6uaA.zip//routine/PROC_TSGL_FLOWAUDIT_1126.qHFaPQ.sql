create PROCEDURE PROC_TSGL_FLOWAUDIT_1126(PJSDEALTYPE    in varchar2,
                                                PJSDEALSTATUS  in varchar2,
                                                PRECEIVEUSERID in varchar2,
                                                PRECEIVEORGID  in varchar2,
                                                PSUGGESTION    in varchar2,
                                                PFKID          in varchar2, --jkpt_tsgl_auditinfo表主键
                                                PSUBMITTYPE    in varchar2,
                                                PRETURNVAL     OUT NUMBER,
                                                PMSG           OUT varchar2) AS
  VAUDITINFO_PKID  NUMBER; --jkpt_tsgl_auditinfo表主键（新序列号）
  VCOMPLAINT_PKID  NUMBER; --JKPT_TSGL_COMPLAINT表主键
  VFREQUENCY       NUMBER; --不满意次数，从0依次递增
  VMAXFREQUENCY    NUMBER;
  VSENDORGID       VARCHAR2(20);
  VPASSPATH        VARCHAR2(1);
  VTOPASSPATH      VARCHAR2(1);
  VSENDSTATUS      NUMBER;
  VSENDUSERID      VARCHAR2(20);
  VPKID_MAX_AD     NUMBER; --JKPT_TSGL_AUDITDETAIL表主键
  VRECEIVEORGID    VARCHAR2(20); --接收机构
  VREMARK_1        VARCHAR2(10); --1-分中心已受理
  VSUGGESTION      VARCHAR2(50); --发送方处理意见及要求
  VCURDEALSTATUS   NUMBER; --获取当前流转状态
  VCURDEALDESCRIBE VARCHAR2(100); --获取当前流转描述
  VDEALDESCRIBE    VARCHAR2(100); --审核通过描述信息
  VCOUNT           NUMBER; --行数
BEGIN
  --获取投诉审核当前最新信息
  SELECT a.fkid,
         a.frequency,
         a.receiveorgid,
         a.passpath,
         a.currentstatus,
         a.senduserid,
         a.remark_1
    into VCOMPLAINT_PKID,
         VFREQUENCY,
         VSENDORGID,
         VPASSPATH,
         VSENDSTATUS,
         VSENDUSERID,
         VREMARK_1
    FROM JKPT_TSGL_AUDITINFO a
   where a.pkid = PFKID
     and a.iscurrent = '1';

  --获取投诉历史最新记录主键
  select max(a.pkid)
    into VPKID_MAX_AD
    from JKPT_TSGL_AUDITDETAIL a
   where a.fkid = PFKID;

  --呼叫中心处理
  if PJSDEALTYPE = 'CallCenter' then

    --处理意见及要求
    if PSUBMITTYPE = '1' then
      --用户满意
      VSUGGESTION := '投诉完成，用户满意';
    elsif PSUBMITTYPE = '2' then
      --用户认可
      VSUGGESTION := '投诉完成，用户认可';
    elsif PSUBMITTYPE = '3' then
      --用户不满意
      VSUGGESTION := '用户未完成，用户不满意';
    elsif PSUBMITTYPE = '4' then
      --放入回收站
      VSUGGESTION := '无效投诉';
    end if;

    if PSUBMITTYPE = '1' or PSUBMITTYPE = '2' then

      update JKPT_TSGL_COMPLAINT a
         set ARCHIVETIME  = sysdate,
             ISARCHIVE    = '1',
             USEDDAYS     = func_base_getdays(a.creationtime, sysdate),
             CURRENTORGID = VSENDORGID
       where pkid = VCOMPLAINT_PKID;

      update Jkpt_Tsgl_Auditinfo a
         set a.currentsuggestion = PSUGGESTION,
             ISARCHIVE           = '1',
             ARCHIVETIME         = sysdate,
             CURRENTSTATUS       = 99,
             DEALRESULT          = PSUBMITTYPE,
             USEDDAYS            = func_base_getdays(a.creationtime, sysdate),
             SENDUSERID          = PRECEIVEUSERID,
             a.SENDORGID         = VSENDORGID,
             CURRENTSTATUSDESC   = VSUGGESTION
       where pkid = PFKID;

    elsif PSUBMITTYPE = '3' then

      update Jkpt_Tsgl_Auditinfo a
         set a.currentsuggestion = PSUGGESTION,
             a.iscurrent         = '0',
             a.dealresult        = PSUBMITTYPE,
             CURRENTSTATUS       = 98,
             SENDUSERID          = PRECEIVEUSERID,
             ARCHIVETIME         = sysdate,
             USEDDAYS            = func_base_getdays(a.creationtime, sysdate),
             CURRENTSTATUSDESC   = VSUGGESTION
       where pkid = PFKID;

      select seq_tsgl_auditinfo_id.nextval into VAUDITINFO_PKID from dual;

      select max(a.frequency) + 1
        into VMAXFREQUENCY
        from JKPT_TSGL_AUDITINFO a
       where a.fkid = VCOMPLAINT_PKID;

      select allotorgid
        into VRECEIVEORGID
        from jkpt_tsgl_orgrelation a
       where a.grouptype = PJSDEALTYPE
         and rownum = 1;

      --判断流程状态及描述
      SELECT a.successstatus, a.successdescribe
        into VCURDEALSTATUS, VCURDEALDESCRIBE
        FROM JKPT_TSGL_STEPDEFINE a
       where a.sender = any (select b.grouptype
                from JKPT_TSGL_ORGRELATION b
               where b.orgid = VSENDORGID)
         and a.successreceiver = any
       (select b.grouptype
                from JKPT_TSGL_ORGRELATION b
               where b.orgid = VRECEIVEORGID);

      --添加投诉次数表
      insert into JKPT_TSGL_AUDITINFO
        (fkid, frequency, sendorgid, pkid, receiveorgid, senduserid)
      values
        (VCOMPLAINT_PKID,
         VMAXFREQUENCY,
         VSENDORGID,
         VAUDITINFO_PKID,
         VRECEIVEORGID,
         PRECEIVEUSERID);

      --创建投诉历史表
      insert into JKPT_TSGL_AUDITDETAIL
        (fkid,
         pkid,
         complaintid,
         frequency,
         statusinfo,
         senduserid,
         passpath,
         receiveorgid,
         status,
         sendorgid,
         isreject,
         isshow,
         receiveuserid)
      values
        (VAUDITINFO_PKID,
         seq_tsgl_auditdetail_id.nextval,
         VCOMPLAINT_PKID,
         VMAXFREQUENCY,
         '投诉已受理',
         PRECEIVEUSERID,
         1,
         VSENDORGID,
         0,
         VSENDORGID,
         0,
         0,
         PRECEIVEUSERID);

      insert into JKPT_TSGL_AUDITDETAIL
        (fkid,
         pkid,
         complaintid,
         frequency,
         statusinfo,
         senduserid,
         passpath,
         receiveorgid,
         status,
         sendorgid,
         isreject,
         isshow)
      values
        (VAUDITINFO_PKID,
         seq_tsgl_auditdetail_id.nextval,
         VCOMPLAINT_PKID,
         VMAXFREQUENCY,
         VCURDEALDESCRIBE,
         PRECEIVEUSERID,
         1,
         VRECEIVEORGID,
         VCURDEALSTATUS,
         VSENDORGID,
         0,
         0);

      --修改等处理机构编码
      update JKPT_TSGL_COMPLAINT a
         set a.currentorgid = VRECEIVEORGID
       where a.pkid = VCOMPLAINT_PKID;

      --判断是否存在附件
      select count(1)
        into VCOUNT
        from JKPT_BASE_ATTACHMENT a
       where a.creationorgid = VSENDORGID
         and a.headid = PFKID;

      --存在附件，添加附件到新投诉流程中
      if VCOUNT > 0 then
        insert into jkpt_base_attachment
          (attachmentid,
           headid,
           type,
           oldname,
           newname,
           filepath,
           uploadtime,
           filesize,
           remark_2,
           remark_1,
           grouptype,
           filetype,
           creationorgid,
           creationuserid)
          select SEQ_BASE_ATTZCHMENTID.nextval,
                 VAUDITINFO_PKID,
                 a.type,
                 a.oldname,
                 a.newname,
                 a.filepath,
                 sysdate,
                 a.filesize,
                 a.remark_1,
                 a.remark_2,
                 a.grouptype,
                 a.filetype,
                 a.creationorgid,
                 a.creationuserid
            from JKPT_BASE_ATTACHMENT a
           where a.creationorgid = VSENDORGID
             and a.headid = PFKID;
      end if;

    elsif PSUBMITTYPE = '4' then
      update JKPT_TSGL_COMPLAINT a
         set RECYCLEBINTIME = sysdate,
             ISRECYCLEBIN   = '1',
             USEDDAYS       = func_base_getdays(a.creationtime, sysdate)
       where pkid = VCOMPLAINT_PKID;

      update Jkpt_Tsgl_Auditinfo a
         set a.currentsuggestion = VSUGGESTION,
             ISRECYCLEBIN        = '1',
             RECYCLEBINTIME      = sysdate,
             CURRENTSTATUS       = 99,
             USEDDAYS            = func_base_getdays(a.creationtime, sysdate),
             SENDUSERID          = PRECEIVEUSERID,
             CURRENTSTATUSDESC   = VSUGGESTION
       where pkid = PFKID;

    end if;

    if PSUBMITTYPE = '1' or PSUBMITTYPE = '2' then
      update JKPT_TSGL_AUDITDETAIL a
         set a.dealtime      = sysdate,
             a.suggestion    = PSUGGESTION,
             a.statusinfo    = VSUGGESTION,
             a.receiveuserid = PRECEIVEUSERID,
             a.newstatus     = 99
       where pkid = VPKID_MAX_AD;
    elsif PSUBMITTYPE = '3' then
      update JKPT_TSGL_AUDITDETAIL a
         set a.dealtime      = sysdate,
             a.suggestion    = PSUGGESTION,
             a.statusinfo    = VSUGGESTION,
             a.receiveuserid = PRECEIVEUSERID,
             a.newstatus     = 98
       where pkid = VPKID_MAX_AD;
    elsif PSUBMITTYPE = '4' then
      update JKPT_TSGL_AUDITDETAIL a
         set a.dealtime      = sysdate,
             a.suggestion    = VSUGGESTION,
             a.statusinfo    = VSUGGESTION,
             a.receiveuserid = PRECEIVEUSERID,
             a.newstatus     = 99
       where pkid = VPKID_MAX_AD;
    end if;

    commit;
    PRETURNVAL := 1;
    return;
  end if;

  --获取接收机构
  if PJSDEALTYPE = 'OperationDept' or PJSDEALTYPE = 'MonitorDept' or PJSDEALTYPE = 'GaoLuHearCenter' then
    if VPASSPATH = '1' then
      if PSUBMITTYPE = '1' then
        VRECEIVEORGID := PRECEIVEORGID;
      else
        select b.sendorgid
          into VRECEIVEORGID
          from jkpt_tsgl_auditdetail b
         where b.pkid = (select max(pkid)
                           from jkpt_tsgl_auditdetail a
                          where a.fkid = PFKID
                            and a.receiveorgid = VSENDORGID
                            and a.isreject <> '1');
      end if;
    else
      if PSUBMITTYPE = '1' then
        select b.sendorgid
          into VRECEIVEORGID
          from jkpt_tsgl_auditdetail b
         where b.pkid = (select max(pkid)
                           from jkpt_tsgl_auditdetail a
                          where a.fkid = PFKID
                            and a.receiveorgid = VSENDORGID
                            and a.passpath <> VPASSPATH
                            and a.isreject <> '1');
      else
        select b.sendorgid
          into VRECEIVEORGID
          from jkpt_tsgl_auditdetail b
         where b.pkid = (select max(pkid)
                           from jkpt_tsgl_auditdetail a
                          where a.fkid = PFKID
                            and a.receiveorgid = VSENDORGID
                            and a.isreject <> '1');
      end if;
    end if;
  elsif PJSDEALTYPE = 'SubCenter' then
    if PSUBMITTYPE = '2' then
      select b.sendorgid
        into VRECEIVEORGID
        from jkpt_tsgl_auditdetail b
       where b.pkid = (select max(pkid)
                         from jkpt_tsgl_auditdetail a
                        where a.fkid = PFKID
                          and a.receiveorgid = VSENDORGID
                          and a.receiveorgid <> a.sendorgid
                          and a.isreject <> '1');
    else
      if VREMARK_1 = '1' then
        --已受理
        select b.sendorgid
          into VRECEIVEORGID
          from jkpt_tsgl_auditdetail b
         where b.pkid = (select max(pkid)
                           from jkpt_tsgl_auditdetail a
                          where a.fkid = PFKID
                            and a.sendorgid <> VSENDORGID
                            and a.isreject <> '1');
      else
        --受理
        select a.allotorgid
          into VRECEIVEORGID
          from JKPT_TSGL_ORGRELATION a
         where a.grouptype = PJSDEALTYPE
           and a.orgid = VSENDORGID;
      end if;
    end if;
  end if;

  if PJSDEALTYPE = 'SubCenter' then
    if PSUBMITTYPE = '1' or PSUBMITTYPE = '3' then
      SELECT a.successstatus,
             a.successdescribe,
             dealsucessdescribe,
             passpath
        into VCURDEALSTATUS, VCURDEALDESCRIBE, VDEALDESCRIBE, VTOPASSPATH
        FROM JKPT_TSGL_STEPDEFINE a
       where a.sender = any (select b.grouptype
                from JKPT_TSGL_ORGRELATION b
               where b.orgid = VSENDORGID)
         and a.successreceiver = any
       (select b.grouptype
                from JKPT_TSGL_ORGRELATION b
               where b.orgid = VRECEIVEORGID);
    else
      SELECT a.rejectstatus, a.rejectdescribe, dealrejectdescribe, passpath
        into VCURDEALSTATUS, VCURDEALDESCRIBE, VDEALDESCRIBE, VTOPASSPATH
        FROM JKPT_TSGL_STEPDEFINE a
       where a.sender = any (select b.grouptype
                from JKPT_TSGL_ORGRELATION b
               where b.orgid = VRECEIVEORGID)
         and a.successreceiver = any
       (select b.grouptype
                from JKPT_TSGL_ORGRELATION b
               where b.orgid = VSENDORGID);
    end if;
  else
    if VPASSPATH = '1' then
      if PSUBMITTYPE = '1' then
        SELECT a.successstatus,
               a.successdescribe,
               dealsucessdescribe,
               passpath
          into VCURDEALSTATUS, VCURDEALDESCRIBE, VDEALDESCRIBE, VTOPASSPATH
          FROM JKPT_TSGL_STEPDEFINE a
         where a.sender = any (select b.grouptype
                  from JKPT_TSGL_ORGRELATION b
                 where b.orgid = VSENDORGID)
           and a.passpath = VPASSPATH
           and a.successreceiver = any
         (select b.grouptype
                  from JKPT_TSGL_ORGRELATION b
                 where b.orgid = VRECEIVEORGID);
      else
        SELECT a.rejectstatus,
               a.rejectdescribe,
               dealrejectdescribe,
               passpath
          into VCURDEALSTATUS, VCURDEALDESCRIBE, VDEALDESCRIBE, VTOPASSPATH
          FROM JKPT_TSGL_STEPDEFINE a
         where a.sender = any (select b.grouptype
                  from JKPT_TSGL_ORGRELATION b
                 where b.orgid = VRECEIVEORGID)
           and a.passpath = VPASSPATH
           and a.successreceiver = any
         (select b.grouptype
                  from JKPT_TSGL_ORGRELATION b
                 where b.orgid = VSENDORGID);
      end if;
    else
      if PSUBMITTYPE = '1' then
        SELECT a.successstatus,
               a.successdescribe,
               dealsucessdescribe,
               passpath
          into VCURDEALSTATUS, VCURDEALDESCRIBE, VDEALDESCRIBE, VTOPASSPATH
          FROM JKPT_TSGL_STEPDEFINE a
         where a.sender = any (select b.grouptype
                  from JKPT_TSGL_ORGRELATION b
                 where b.orgid = VSENDORGID)
           and a.successreceiver = any (select b.grouptype
                  from JKPT_TSGL_ORGRELATION b
                 where b.orgid = VRECEIVEORGID)
           and rownum = 1;
      else
        SELECT a.rejectstatus,
               a.rejectdescribe,
               dealrejectdescribe,
               passpath
          into VCURDEALSTATUS, VCURDEALDESCRIBE, VDEALDESCRIBE, VTOPASSPATH
          FROM JKPT_TSGL_STEPDEFINE a
         where a.sender = any (select b.grouptype
                  from JKPT_TSGL_ORGRELATION b
                 where b.orgid = VRECEIVEORGID)
           and a.successreceiver = any (select b.grouptype
                  from JKPT_TSGL_ORGRELATION b
                 where b.orgid = VSENDORGID)
           and rownum = 1;
      end if;
    end if;
  end if;

  --被驳回处理
  if PSUBMITTYPE = '2' then
    update JKPT_TSGL_AUDITDETAIL a
       set a.dealtime      = sysdate,
           a.statusinfo    = VDEALDESCRIBE,
           a.suggestion    = PSUGGESTION,
           a.receiveuserid = PRECEIVEUSERID,
           a.newstatus     = VCURDEALSTATUS,
           a.receiveorgid  = VSENDORGID,
           a.isreject      = '1'
     where pkid = VPKID_MAX_AD;
  else
    update JKPT_TSGL_AUDITDETAIL a
       set a.dealtime      = sysdate,
           a.statusinfo    = VDEALDESCRIBE,
           a.suggestion    = PSUGGESTION,
           a.receiveuserid = PRECEIVEUSERID,
           a.newstatus     = VCURDEALSTATUS,
           a.receiveorgid  = VSENDORGID
     where pkid = VPKID_MAX_AD;
  end if;

  --被驳回处理
  if PSUBMITTYPE = '2' then
    insert into jkpt_tsgl_auditdetail
      (fkid,
       statusinfo,
       senduserid,
       dealtime,
       passpath,
       pkid,
       status,
       sendorgid,
       receiveorgid,
       frequency,
       complaintid,
       isreject)
    values
      (PFKID,
       VCURDEALDESCRIBE,
       PRECEIVEUSERID,
       sysdate,
       VTOPASSPATH,
       seq_tsgl_auditdetail_id.nextval,
       VCURDEALSTATUS,
       VSENDORGID,
       VRECEIVEORGID,
       VFREQUENCY,
       VCOMPLAINT_PKID,
       '1');

    update Jkpt_Tsgl_Auditinfo a
       set a.currentstatus     = VCURDEALSTATUS,
           a.currentsuggestion = PSUGGESTION,
           a.sendorgid         = VSENDORGID,
           a.senduserid        = PRECEIVEUSERID,
           a.receiveorgid      = VRECEIVEORGID,
           a.passpath          = VTOPASSPATH,
           a.isreject          = '1',
           a.currentstatusdesc = VCURDEALDESCRIBE
     where pkid = PFKID;
  else
    insert into jkpt_tsgl_auditdetail
      (fkid,
       statusinfo,
       senduserid,
       dealtime,
       passpath,
       pkid,
       status,
       sendorgid,
       receiveorgid,
       frequency,
       complaintid)
    values
      (PFKID,
       VCURDEALDESCRIBE,
       PRECEIVEUSERID,
       sysdate,
       VTOPASSPATH,
       seq_tsgl_auditdetail_id.nextval,
       VCURDEALSTATUS,
       VSENDORGID,
       VRECEIVEORGID,
       VFREQUENCY,
       VCOMPLAINT_PKID);

    update Jkpt_Tsgl_Auditinfo a
       set a.currentstatus     = VCURDEALSTATUS,
           a.currentsuggestion = PSUGGESTION,
           a.sendorgid         = VSENDORGID,
           a.senduserid        = PRECEIVEUSERID,
           a.receiveorgid      = VRECEIVEORGID,
           a.passpath          = VTOPASSPATH,
           a.isreject          = '0',
           a.currentstatusdesc = VCURDEALDESCRIBE
     where pkid = PFKID;
  end if;

  --分中心受理标识
  if PSUBMITTYPE = '3' and PJSDEALTYPE = 'SubCenter' then
    update Jkpt_Tsgl_Auditinfo a set a.remark_1 = '1' where pkid = PFKID;
  end if;

  if (PSUBMITTYPE = '2' and PJSDEALTYPE = 'SubCenter') or
     ((PJSDEALTYPE = 'OperationDept' or PJSDEALTYPE = 'MonitorDept' or PJSDEALTYPE = 'GaoLuHearCenter') and
     PSUBMITTYPE = '2' and VPASSPATH = '2') then
    update Jkpt_Tsgl_Auditinfo a set a.remark_1 = NULL where pkid = PFKID;
  end if;

  --更新当前待处理机构
  update JKPT_TSGL_COMPLAINT a
     set a.currentorgid = VRECEIVEORGID
   where pkid = VCOMPLAINT_PKID;

  commit;
  PRETURNVAL := 1;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    PRETURNVAL := 0;
    PMSG       := sqlerrm;
    insert into jkpt_comm_log
      (logid, mainmodule, userid, opesummarize, isexception, remark1)
    values
      (seq_comm_log_id.nextval,
       '投诉管理',
       PRECEIVEUSERID,
       PMSG,
       '1',
       '投诉管理审核出现异常');
    commit;
    PMSG := '执行失败';
END PROC_TSGL_FLOWAUDIT_1126;
/

