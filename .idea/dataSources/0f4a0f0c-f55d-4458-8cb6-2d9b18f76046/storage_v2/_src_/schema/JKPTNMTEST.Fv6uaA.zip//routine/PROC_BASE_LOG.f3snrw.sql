create PROCEDURE PROC_BASE_LOG(p_model           in varchar2,
                                          p_descriptioninfo in varchar2,
                                          p_begintime       in date,
                                          p_endtime         in date,
                                          p_flag            in char,
                                          p_errmsg          in varchar2) as
begin
  insert into jkpt_base_log
    (keyid, model, descriptioninfo, begintime, endtime, flag, errmsg)
  values
    (seq_base_log.nextval,
     p_model,
     p_descriptioninfo,
     p_begintime,
     p_endtime,
     p_flag,
     p_errmsg);
     commit;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END PROC_BASE_LOG;
/

