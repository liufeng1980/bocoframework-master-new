create FUNCTION fun_Split_Attachment(p_list varchar2)
  return attachment_temp_table
  pipelined is
  l_idx         pls_integer;
  e_idx         pls_integer;
  c_idx         pls_integer;
  d_idx         pls_integer;
  a_idx         pls_integer;
  v_list        varchar2(2000) := p_list;
  p_sep         varchar2(1) := '~';
  q_sep         varchar2(1) := '`';
  strTemp       varchar2(2000);
  strPriceTemp  varchar2(2000);
  strBatchTemp  varchar2(2000);
  strReasonTemp varchar2(2000);
  strOther      varchar2(2000);
begin
  loop
    l_idx := instr(v_list, p_sep);
    if l_idx > 0 then
      strTemp := substr(v_list, 0, l_idx - 1);
      c_idx   := instr(strTemp, q_sep);
      if c_idx > 0 then
        strPriceTemp  := substr(strTemp, c_idx + 1);
        d_idx         := instr(strPriceTemp, q_sep);
        strReasonTemp := substr(strPriceTemp, d_idx + 1);
        a_idx         := instr(strReasonTemp, q_sep);
        strOther      := substr(strReasonTemp, a_idx + 1);
        e_idx         := instr(strOther, q_sep);
        if (e_idx = 0) then
          select length(strOther) + 1 into e_idx from dual;
        end if;
        pipe row(attachment_temp(nvl(substr(strTemp, 0, c_idx - 1), 0),
                                 nvl(substr(strPriceTemp, 0, d_idx - 1), 0),
                                 nvl(substr(strReasonTemp, 0, a_idx - 1), 0),
                                 nvl(substr(strOther, 0, e_idx - 1), 0)));
      end if;
      v_list := substr(v_list, l_idx + length(p_sep));
    else
      c_idx := instr(v_list, q_sep);
      if c_idx > 0 then
        strPriceTemp  := substr(v_list, c_idx + 1);
        d_idx         := instr(strPriceTemp, q_sep);
        strReasonTemp := substr(strPriceTemp, d_idx + 1);
        a_idx         := instr(strReasonTemp, q_sep);
        strOther      := substr(strReasonTemp, a_idx + 1);
        e_idx         := instr(strOther, q_sep);
        if (e_idx = 0) then
          select length(strOther) + 1 into e_idx from dual;
        end if;
        pipe row(attachment_temp(nvl(substr(v_list, 0, c_idx - 1), 0),
                                 nvl(substr(strPriceTemp, 0, d_idx - 1), 0),
                                 nvl(substr(strReasonTemp, 0, a_idx - 1), 0),
                                 nvl(substr(strOther, 0, e_idx - 1), 0)));
      end if;
      exit;
    end if;
  end loop;

  return;
end fun_Split_Attachment;
/

