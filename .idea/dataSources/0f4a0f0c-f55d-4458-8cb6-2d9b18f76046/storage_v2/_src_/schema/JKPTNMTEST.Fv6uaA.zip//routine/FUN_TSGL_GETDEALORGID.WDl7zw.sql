create FUNCTION FUN_tsgl_GetDealOrgID(PAuditInfoID in number)
  RETURN VARCHAR2 AS
  RETURNVAL  VARCHAR2(100) := '';
  VCount     number;
  VIsArchive varchar2(1) := '0';
BEGIN
  --判断投诉是否归档，如果未归档，则不用获取处理机构
  select a.isarchive into VIsArchive
    from jkpt_tsgl_auditinfo a
   where a.pkid = PAuditInfoID;
   if VIsArchive='0' then
     return RETURNVAL;
   end if;
  --判断是否是运营科直接处理完成：条件是运营科是否存在passpath=2 and 未审核意见不为空 and 不是被驳回
  select count(1)
    into VCount
    from jkpt_tsgl_auditdetail a
   where a.fkid = PAuditInfoID
     and a.receiveorgid in
         (select b.orgid
            from jkpt_tsgl_orgrelation b
           where b.grouptype = 'OperationDept')
     and a.suggestion is not null
     and a.isreject = '0'
     and a.passpath = 2;
  if VCount > 0 then
    --判断分中心是否有审核记录
    select count(1)
      into VCount
      from jkpt_tsgl_auditdetail a
     where a.fkid = PAuditInfoID
       and a.Receiveorgid in
           (select a.orgid
              from jkpt_tsgl_orgrelation a
             where a.grouptype = 'SubCenter')
       and a.sendorgid = a.receiveorgid
       and a.suggestion is not null;

    if VCount > 0 then
      select b.receiveorgid
        into RETURNVAL
        from jkpt_tsgl_auditdetail b
       where b.pkid = (select max(a.pkid)
                         from jkpt_tsgl_auditdetail a
                        where a.fkid = PAuditInfoID
                          and a.Receiveorgid in
                              (select a.orgid
                                 from jkpt_tsgl_orgrelation a
                                where a.grouptype = 'SubCenter')
                          and a.sendorgid = a.receiveorgid
                          and a.suggestion is not null);
    end if;
  else
    select count(1)
      into VCount
      from jkpt_tsgl_auditdetail a
     where a.fkid = PAuditInfoID
       and a.receiveorgid in
           (select b.orgid
              from jkpt_tsgl_orgrelation b
             where b.grouptype = 'OperationDept')
       and a.suggestion is not null
       and a.isreject = '0'
       and a.passpath = 1;
    if VCount > 0 then
      select b.receiveorgid
        into RETURNVAL
        from jkpt_tsgl_auditdetail b
       where b.pkid = (select max(a.pkid)
                         from jkpt_tsgl_auditdetail a
                        where a.fkid = PAuditInfoID
                          and a.Receiveorgid in
                              (select a.orgid
                                 from jkpt_tsgl_orgrelation a
                                where a.grouptype = 'OperationDept')
                          and a.suggestion is not null
                          and a.isreject = '0'
                          and a.passpath = 1);
    end if;
  end if;

  return RETURNVAL;
END FUN_tsgl_GetDealOrgID;
/

