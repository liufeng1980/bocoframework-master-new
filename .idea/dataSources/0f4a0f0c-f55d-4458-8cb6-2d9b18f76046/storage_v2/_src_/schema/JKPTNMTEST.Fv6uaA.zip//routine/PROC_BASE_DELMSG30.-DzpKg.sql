create procedure proc_base_delMsg30 as
  VORGID VARCHAR2(1000);
begin
  execute immediate 'alter table jkpt_base_msg NOLOGGING';
  delete jkpt_base_msg t where (sysdate - t.creationtime) > 30;
  execute immediate 'alter table jkpt_base_msg LOGGING';
  commit;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
end proc_base_delMsg30;
/

