create view V_INTELLIGENCESTATISTICS as
SELECT M.ORGID,
       M.ORGNAME,
       M.ROADID,
       M.ROADNAME,
       M.DEVICEID,
       M.DEVICENAME,
       M.TIMES,
       N.STAKEID
  FROM (SELECT A.ORGID,
               A.ORGNAME,
               A.ROADID,
               A.ROADNAME,
               A.DEVICEID,
               A.DEVICENAME,
               COUNT(1) TIMES
          FROM V_INTELLIGENCE A
         GROUP BY A.ORGID,
                  A.ORGNAME,
                  A.ROADID,
                  A.ROADNAME,
                  A.DEVICEID,
                  A.DEVICENAME) M,
       JKPT_BASE_DEVICE N
 WHERE M.DEVICEID = N.DEVICEID
/

