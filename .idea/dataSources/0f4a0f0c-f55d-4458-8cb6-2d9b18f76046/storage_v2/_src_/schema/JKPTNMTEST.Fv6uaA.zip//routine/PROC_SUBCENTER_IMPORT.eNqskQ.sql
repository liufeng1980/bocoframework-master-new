create PROCEDURE PROC_SUBCENTER_IMPORT IS
  CURSOR CUR IS
    SELECT * FROM JKPT_SUB_CENTER_IMPORT_CONFIG ORDER BY ID;
  C_ROW             CUR%ROWTYPE;
  v_statusflag      char(1) := '1';
  v_errmsg          varchar2(2000) := '';
  v_model           varchar2(50) := '分中心数据导入';
  v_begintime       date;
  v_endtime         date;
BEGIN

  FOR C_ROW IN CUR LOOP
    /*DBMS_OUTPUT.PUT_LINE(C_ROW.FROM_TABLE);
    DBMS_OUTPUT.PUT_LINE(C_ROW.TABLE_TYPE);
    DBMS_OUTPUT.PUT_LINE(C_ROW.IMPORT_MAX_ID);
    DBMS_OUTPUT.PUT_LINE(C_ROW.SUB_CENTER_ID);*/
    select sysdate into v_begintime from dual;
    proc_subcenter_import_by_every(C_ROW.id,
                                   C_ROW.FROM_TABLE,
                                   C_ROW.TABLE_TYPE,
                                   C_ROW.IMPORT_MAX_ID,
                                   C_ROW.SUB_CENTER_ID);
    select sysdate into v_endtime from dual;
    proc_base_log(v_model,
                  '分中心数据导入成功...',
                  v_begintime,
                  v_endtime,
                  v_statusflag,
                  v_errmsg);
  END LOOP;
EXCEPTION
  WHEN OTHERS THEN
    v_statusflag := '0';
    --DBMS_OUTPUT.PUT_LINE(SQLERRM);
    proc_base_log(v_model,
                  '分中心数据导入失败...',
                  v_begintime,
                  sysdate,
                  v_statusflag,
                  substr(sqlerrm, 1000));
END PROC_SUBCENTER_IMPORT;
/

