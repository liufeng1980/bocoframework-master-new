create procedure proc_auto_charge as
  v_max_dealId             number := 0;
  v_deal_count             number := 50000; --每次处理条数
  v_stats_months_maxid     number := 0;
  v_station_day_his_maxid  number := 0;
  v_station_hour_his_maxid number := 0;
  v_heat_line_maxid        number := 0;
  v_count                  number;
  v_errmsg                 varchar2(2000);
begin
  --获取最大处理Id
  select a.deallid
    into v_max_dealId
    from jkpt_sync_record a
   where a.keyid = 1;

  --获取charge_stats_month表的最大Id
  select nvl(max(id), 0) into v_stats_months_maxid from charge_stats_month;

  --获取charge_station_day_his表的最大Id
  select nvl(max(id), 0)
    into v_station_day_his_maxid
    from charge_station_day_his;

  --获取charge_station_hour_his表的最大Id
  select nvl(max(id), 0)
    into v_station_hour_his_maxid
    from charge_station_hour_his;

  --获取charge_heat_line表的最大Id
  select nvl(max(id), 0) into v_heat_line_maxid from charge_heat_line;

  --将本次处理的数据保存在charge_flow_temp_data表中
  insert into charge_flow_temp_data
    (id,
     listno,
     entrytime,
     entrystation,
     icardid,
     exittime,
     exitstation,
     exitvehiclemodel,
     plate,
     cash,
     noncash,
     vehicletype,
     cardid,
     tmiles)
    select id,
           listno,
           entrytime,
           entrystation,
           icardid,
           exittime,
           exitstation,
           exitvehiclemodel,
           plate,
           cash,
           noncash,
           vehicletype,
           cardid,
           tmiles
      from (select row_number() over(order by id) rn,
                   id,
                   listno,
                   entrytime,
                   entrystation,
                   icardid,
                   exittime,
                   exitstation,
                   exitvehiclemodel,
                   plate,
                   cash,
                   noncash,
                   vehicletype,
                   cardid,
                   tmiles
              from charge_flow_data t
             where t.id > v_max_dealId)
     where rn <= v_deal_count;

  --获取最新数据条数
  select count(1) into v_count from charge_flow_temp_data;
  if v_count = 0 then
    commit;
    return;
  end if;

  dbms_output.put_line(v_count);

  --收费及车流量按月份车型车种统计
  merge into charge_stats_month a
  using (select v_stats_months_maxid + rn id,
                statsmonth,
                exitvehiclemodel,
                vehicletype,
                trafficflow,
                cash,
                noncash
           from (select row_number() over(order by trunc(t.exittime, 'mm'), exitvehiclemodel, vehicletype) rn,
                        trunc(t.exittime, 'mm') statsmonth,
                        t.exitvehiclemodel,
                        t.vehicletype,
                        count(1) trafficflow,
                        nvl(sum(t.cash), 0) cash,
                        nvl(sum(t.noncash), 0) noncash
                   from charge_flow_temp_data t
                  group by trunc(t.exittime, 'mm'),
                           t.exitvehiclemodel,
                           t.vehicletype
                  order by statsmonth, exitvehiclemodel, vehicletype)) b
  on (a.statsmonth = b.statsmonth and a.exitvehiclemodel = b.exitvehiclemodel and a.vehicletype = b.vehicletype)
  when matched then
    update
       set a.trafficflow = a.trafficflow + b.trafficflow,
           a.cash        = a.cash + b.cash,
           a.noncash     = a.noncash + b.noncash
  when not matched then
    insert
      (id,
       statsmonth,
       exitvehiclemodel,
       vehicletype,
       trafficflow,
       cash,
       noncash)
    values
      (b.id,
       b.statsmonth,
       b.exitvehiclemodel,
       b.vehicletype,
       b.trafficflow,
       b.cash,
       b.noncash);

  --历史收费站每日车流量
  merge into charge_station_day_his a
  using (select v_station_day_his_maxid + rn id,
                exitstation,
                statsday,
                trafficflow,
                cash,
                noncash
           from (select row_number() over(order by trunc(t.exittime)) rn,
                        exitstation,
                        trunc(t.exittime) statsday,
                        count(1) trafficflow,
                        nvl(sum(t.cash), 0) cash,
                        nvl(sum(t.noncash), 0) noncash
                   from charge_flow_temp_data t
                  group by exitstation, trunc(exittime))) b
  on (a.statsday = b.statsday and a.exitstation = b.exitstation)
  when matched then
    update
       set a.trafficflow = a.trafficflow + b.trafficflow,
           a.cash        = a.cash + b.cash,
           a.noncash     = a.noncash + b.noncash
  when not matched then
    insert
      (id, exitstation, statsday, trafficflow, cash, noncash)
    values
      (b.id, b.exitstation, b.statsday, b.trafficflow, b.cash, b.noncash);

  --历史收费站每小时车流量
  merge into charge_station_hour_his a
  using (select v_station_hour_his_maxid + rn id,
                exitstation,
                statstime,
                trafficflow,
                cash,
                noncash
           from (select row_number() over(order by trunc(t.exittime, 'hh')) rn,
                        exitstation,
                        trunc(t.exittime, 'hh') statstime,
                        count(1) trafficflow,
                        nvl(sum(t.cash), 0) cash,
                        nvl(sum(t.noncash), 0) noncash
                   from charge_flow_temp_data t
                  group by exitstation, trunc(exittime, 'hh'))) b
  on (a.statstime = b.statstime and a.exitstation = b.exitstation)
  when matched then
    update
       set a.trafficflow = a.trafficflow + b.trafficflow,
           a.cash        = a.cash + b.cash,
           a.noncash     = a.noncash + b.noncash
  when not matched then
    insert
      (id, exitstation, statstime, trafficflow, cash, noncash)
    values
      (b.id, b.exitstation, b.statstime, b.trafficflow, b.cash, b.noncash);

  --热门路线
  merge into charge_heat_line a
  using (select v_heat_line_maxid + rn id,
                entrystation,
                exitstation,
                statsmonth,
                trafficflow
           from (select row_number() over(order by count(1) desc) rn,
                        entrystation,
                        exitstation,
                        to_char(t.exittime, 'yyyymm') statsmonth,
                        count(1) trafficflow
                   from charge_flow_temp_data t
                  group by entrystation,
                           exitstation,
                           to_char(exittime, 'yyyymm'))
          where rn <= 500) b
  on (a.statsmonth = b.statsmonth and a.entrystation = b.entrystation and a.exitstation = b.exitstation)
  when matched then
    update set a.trafficflow = a.trafficflow + b.trafficflow
  when not matched then
    insert
      (id, entrystation, exitstation, statsmonth, trafficflow)
    values
      (b.id, b.entrystation, b.exitstation, b.statsmonth, b.trafficflow);

  --更新最新处理Id
  update jkpt_sync_record a
     set a.deallid =
         (select nvl(max(id), 0) from charge_flow_temp_data),
         a.dealtime = sysdate
   where a.keyid = 1;

  --删除当日收费流水
  execute immediate 'truncate table charge_flow_data_today';
  --插入当日最新收费流水
  insert into charge_flow_data_today
    (id,
     listno,
     entrytime,
     entrystation,
     icardid,
     exittime,
     exitstation,
     exitvehiclemodel,
     plate,
     cash,
     noncash,
     vehicletype,
     cardid,
     tmiles,
     middate,
     writedate)
    select id,
           listno,
           entrytime,
           entrystation,
           icardid,
           exittime,
           exitstation,
           exitvehiclemodel,
           plate,
           cash,
           noncash,
           vehicletype,
           cardid,
           tmiles,
           middate,
           writedate
      from charge_flow_data
     where exittime between trunc(sysdate) and
           trunc(sysdate + 1) - 1 / 24 / 60 / 60;

  commit;
exception
  when others then
    rollback;
    v_errmsg := sqlerrm;
    dbms_output.put_line(v_errmsg);
    insert into jkpt_comm_log
      (logid, mainmodule, userid, opesummarize, isexception, remark1)
    values
      (seq_comm_log_id.nextval,
       '收费数据同步',
       '999999999',
       v_errmsg,
       '1',
       '收费数据同步出现异常');
    commit;
end;
/

