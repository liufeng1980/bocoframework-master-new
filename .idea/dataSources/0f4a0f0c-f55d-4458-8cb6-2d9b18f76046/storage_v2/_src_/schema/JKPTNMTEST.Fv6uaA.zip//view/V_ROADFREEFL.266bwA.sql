create view V_ROADFREEFL as
select '' orgname,'' roadname,'' devicename,'' avgspeed,'' avgspeedname from dual
/

