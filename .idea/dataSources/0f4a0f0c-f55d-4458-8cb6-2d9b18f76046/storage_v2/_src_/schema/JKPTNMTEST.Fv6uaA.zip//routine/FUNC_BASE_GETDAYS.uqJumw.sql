create FUNCTION func_base_getdays(pStartTime in date,
                                             pEndTime   in date)
  RETURN number AS
  vReturnVal number;
BEGIN
  vReturnVal := 0;

  select count(*)
    into vReturnVal
    from jkpt_base_holiday
   where datevalue >= pStartTime
     and datevalue <= pEndTime
     and isholiday <> 1;

  if (vReturnVal = 0) then
    vReturnVal := 1;
  end if;
  return vReturnVal;
END func_base_getdays;
/

