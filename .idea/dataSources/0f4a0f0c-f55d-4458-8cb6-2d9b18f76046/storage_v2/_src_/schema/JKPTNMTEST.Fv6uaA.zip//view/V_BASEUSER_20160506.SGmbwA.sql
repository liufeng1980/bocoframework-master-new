create view V_BASEUSER_20160506 as
select A.USERID,
       A.USERNAME,
       A.SEX,
       DECODE(A.SEX, '1', '男', '2', '女', '') SEXNAME,
       A.NATION,
       A.CONTACT,
       B.ORGID,
       B.ORGNAME,
       C.ROLENAME
  from JKPT_BASE_USER A, JKPT_BASE_ORG B, JKPT_BASE_ROLE C
 WHERE A.ORGID = B.ORGID
   AND A.ROLEID = C.ROLEID
/

