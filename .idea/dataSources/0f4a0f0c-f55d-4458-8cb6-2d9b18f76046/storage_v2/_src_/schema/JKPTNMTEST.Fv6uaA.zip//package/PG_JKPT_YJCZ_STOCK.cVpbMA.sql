create package PG_JKPT_YJCZ_STOCK is

  procedure PROC_InstoreUpdate(pOrderID        IN number,
                               pCount          IN number,
                               pType           IN number,
                               pQADate         IN VARCHAR2,
                               pExpirationDate IN VARCHAR2,
                               pSupplierID     IN VARCHAR2,
                               pPrice          in number,
                               pOrgID          in varchar2,
                               pStoreID        in number,
                               pInvoice        in varchar2,
                               pHaveInvoice    in number,
                               pModifyUserID   in varchar2,
                               pReturnVal      OUT NUMBER,
                               pMSG            OUT varchar2);

  procedure PROC_InstoreDel(pOrderID   IN number,
                            pReturnVal OUT NUMBER,
                            pMSG       OUT varchar2);

  procedure PROC_OutstoreAdd(pGoodsID        IN number,
                             pCount          IN number,
                             pType           IN number,
                             pGetOrgID       IN VARCHAR2,
                             pReceiptor      in varchar2,
                             pCreationUserID in varchar2,
                             pReturnVal      OUT NUMBER,
                             pMSG            OUT varchar2);

  procedure PROC_OutstoreUpdate(pOrderID      IN number,
                                pCount        IN number,
                                pType         IN number,
                                pGetOrgID     IN VARCHAR2,
                                pReceiptor    in varchar2,
                                pModifyUserID in varchar2,
                                pReturnVal    OUT NUMBER,
                                pMSG          OUT varchar2);

end PG_JKPT_YJCZ_STOCK;
/

