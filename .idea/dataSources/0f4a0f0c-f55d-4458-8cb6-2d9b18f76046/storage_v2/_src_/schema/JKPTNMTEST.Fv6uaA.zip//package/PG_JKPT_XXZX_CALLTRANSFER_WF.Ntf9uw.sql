create package PG_JKPT_XXZX_CALLTRANSFER_WF is

  --添加呼叫流转
  procedure PROC_AddCallTransfer(pCreationUserID   IN varchar2,
                                 pContent          in varchar2,
                                 pCreationOrgID    in varchar2,
                                 pCustomerName     in varchar2,
                                 pCustomerMobile   in varchar2,
                                 pPosition         in varchar2,
                                 pCallTransferType in varchar2,
                                 pPlateNum         in varchar2,
                                 pModel            in varchar2,
                                 pDirection        in varchar2,
                                 pRemark_3         in varchar2, --话务系统单号
                                 pMsgId            out number,
                                 pReturnVal        out number,
                                 pMSG              out varchar2);

  --呼叫流转审批
  procedure PROC_MSG_FLOWAUDIT(PJSDealType   IN VARCHAR2,
                               PSendUserID   IN VARCHAR2,
                               PReceiveOrgID IN VARCHAR2,
                               PSuggestion   IN VARCHAR2,
                               PAuditID      IN VARCHAR2, --jkpt_msg_calltransfer_audit表主键
                               PSubmitType   IN VARCHAR2, --1:通过，2:驳回，3:受理，4:处理完成,5:放入回收站
                               PREMARK_6     IN NUMBER,
                               pReturnVal    OUT NUMBER,
                               PMSG          OUT VARCHAR2);

  --添加呼叫流转
  procedure PROC_ReAddCallTransfer(pCreationUserID   IN varchar2,
                                   pContent          in varchar2,
                                   pCreationOrgID    in varchar2,
                                   pCustomerName     in varchar2,
                                   pCustomerMobile   in varchar2,
                                   pPosition         in varchar2,
                                   pCallTransferType in varchar2,
                                   pPlateNum         in varchar2,
                                   pModel            in varchar2,
                                   pDirection        in varchar2,
                                   pAuditID          in varchar2,
                                   pRemark_3         in varchar2, --话务系统单号
                                   pReturnVal        out number,
                                   pMSG              out varchar2);

  function FUN_getstatusdescpart1(pMsgid in number) RETURN VARCHAR2;

  FUNCTION FUN_getstatusdescpart2(pMsgid in number) RETURN VARCHAR2;

  function FUN_GETMYCURRENTCOUNT(pOrgID in varchar2) return number;

end PG_JKPT_XXZX_CALLTRANSFER_WF;
/

