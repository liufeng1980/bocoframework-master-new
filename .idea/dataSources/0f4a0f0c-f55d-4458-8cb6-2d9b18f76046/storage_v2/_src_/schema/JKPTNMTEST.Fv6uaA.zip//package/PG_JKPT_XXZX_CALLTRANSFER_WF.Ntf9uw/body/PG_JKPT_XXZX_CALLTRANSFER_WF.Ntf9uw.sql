create package body PG_JKPT_XXZX_CALLTRANSFER_WF is

  -- tian jia hu jiao liu zhuan
  procedure PROC_AddCallTransfer(pCreationUserID   IN varchar2,
                                 pContent          in varchar2,
                                 pCreationOrgID    in varchar2,
                                 pCustomerName     in varchar2,
                                 pCustomerMobile   in varchar2,
                                 pPosition         in varchar2,
                                 pCallTransferType in varchar2,
                                 pPlateNum         in varchar2,
                                 pModel            in varchar2,
                                 pDirection        in varchar2,
                                 pRemark_3         in varchar2, --话务系统单号
                                 pMsgId            out number,
                                 pReturnVal        out number,
                                 pMSG              out varchar2) as
    vPrefix         varchar2(2);
    vCurrentID      varchar2(7);
    vCount          number;
    vCode           varchar2(20);
    vMsgID          number;
    vWaitStatusDesc varchar2(100);
    vAuditID        number;
    vAuditStatus    number; --审核后状态
    vAuditInfo      varchar2(100);
    v_Remark        varchar2(200); --按钮数组
    vReceiveOrgID   varchar2(20);
  begin
    pReturnVal := 1;
    pMSG       := '';

    select a.receiveorgid
      into vReceiveOrgID
      from jkpt_msg_orgrelation a
     where a.grouptype = 'CallCenter'
       and rownum = 1;

    select decode(pCallTransferType,
                  1,
                  'JY',
                  2,
                  'TS',
                  3,
                  'TF',
                  4,
                  'QZ',
                  10,
                  'QT')
      into vPrefix
      from dual;

    --start huo qu bian hao
    select LPAD(currentid, 5, '0')
      into vCurrentID
      from jkpt_base_seq
     where upper(tablename) = 'JKPT_MSG_CALLTRANSFER'
       and prefix = vPrefix
       for update;

    select count(*)
      into vCount
      from JKPT_MSG_CALLTRANSFER_BASE t
     where t.creationtime > trunc(sysdate, 'yyyy')
       and t.calltransfertype = pCallTransferType;
    if (vCount > 0) then
      select vPrefix || to_char(sysdate, 'yy') || vCurrentID
        into vCode　from dual;
      update jkpt_base_seq
         set currentid = currentid + 1
       where upper(tablename) = 'JKPT_MSG_CALLTRANSFER'
         and prefix = vPrefix;
    else
      select vPrefix || to_char(sysdate, 'yy') || '00001'
        into vCode　from dual;
      update jkpt_base_seq
         set currentid = 2
       where upper(tablename) = 'JKPT_MSG_CALLTRANSFER'
         and prefix = vPrefix;
    end if;
    --end huo qu bian hao

    --获取流程初始状态信息
    select a.successstatus,
           a.successdescribe,
           a.dealsucessdescribe,
           a.remark_1
      into vAuditStatus, vWaitStatusDesc, vAuditInfo, v_Remark
      from jkpt_msg_stepdefine a
     where a.modelname = 'MSG_CALLTRANSFER_BASE'
       and a.sendorggroup = ANY (select b.grouptype
              from jkpt_msg_orgrelation b
             where b.sendorgid = pCreationOrgID)
       AND A.successreceiveorggroup = ANY
     (select b.grouptype
              from jkpt_msg_orgrelation b
             where b.sendorgid = vReceiveOrgID);

    select SEQ_MSG_CALLTRANSFERID.Nextval into vMsgID from dual;
    insert into jkpt_msg_calltransfer_base
      (msgid,
       creationuserid,
       creationtime,
       content,
       creationorgid,
       customername,
       customermobile,
       position,
       calltransfertype,
       platenum,
       model,
       direction,
       status,
       code,
       sendorgid,
       senduserid,
       senddate,
       receiveorgid,
       waitstatusdesc,
       remark_3)
    values
      (vMsgID,
       pCreationUserID,
       sysdate,
       pContent,
       pCreationOrgID,
       pCustomerName,
       pCustomerMobile,
       pPosition,
       pCallTransferType,
       pPlateNum,
       pModel,
       pDirection,
       1,
       vCode,
       pCreationOrgID,
       pCreationUserID,
       sysdate,
       vReceiveOrgID,
       vWaitStatusDesc,
       pRemark_3);

    select SEQ_MSG_AUDIT.NEXTVAL into vAuditID from dual;

    insert into jkpt_msg_calltransfer_audit
      (auditid,
       msgid,
       frequency,
       sendorgid,
       senduserid,
       receiveorgid,
       currentstatusdesc,
       currentstatus,
       remark_2)
    values
      (vAuditID,
       vMsgID,
       0,
       pCreationOrgID,
       pCreationUserID,
       vReceiveOrgID,
       vWaitStatusDesc,
       1,
       v_Remark);
    insert into jkpt_msg_calltransfer_detail
      (detailid,
       auditid,
       msgid,
       frequency,
       sendorgid,
       senduserid,
       receiveorgid,
       startstatus,
       endstatus,
       statusdesc,
       suggestion,
       statusinfo)
    values
      (seq_msg_detail.nextval,
       vAuditID,
       vMsgID,
       0,
       pCreationOrgID,
       pCreationUserID,
       vReceiveOrgID,
       1,
       vAuditStatus,
       vWaitStatusDesc,
       '',
       vAuditInfo);

    --将发送机构和接收机构添加到接收机构列表中
    insert into jkpt_msg_receiveorg values (vMsgID, pCreationOrgID);
    insert into jkpt_msg_receiveorg values (vMsgID, vReceiveOrgID);

    pMsgId := vMsgID;
    commit;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := sqlerrm;
  end PROC_AddCallTransfer;

  procedure PROC_MSG_FLOWAUDIT(PJSDealType   IN VARCHAR2,
                               PSendUserID   IN VARCHAR2,
                               PReceiveOrgID IN VARCHAR2,
                               PSuggestion   IN VARCHAR2,
                               PAuditID      IN VARCHAR2, --jkpt_msg_calltransfer_audit表主键
                               PSubmitType   IN VARCHAR2, --1:通过，2:驳回，3:受理，4:处理完成,5:放入回收站
                               PREMARK_6     IN NUMBER,
                               pReturnVal    OUT NUMBER,
                               PMSG          OUT VARCHAR2) as
    vMsgID                NUMBER;
    vFrequency            NUMBER; --重新流转次数，从0依次递增
    vSendOrgID            VARCHAR2(20);
    vCurrentstatus        NUMBER;
    vSenduserid           VARCHAR2(20);
    vSuggestion           VARCHAR2(50); --当前处理人的处理意见及要求
    vCurDealStatus        NUMBER; --获取待流转流程状态
    vCurDealDescribe      VARCHAR2(100); --获取待流转流程描述
    vDealDescribe         VARCHAR2(100); --审核通过或者驳回描述信息：（通过，驳回）
    vIsReject             VARCHAR2(1);
    vReceiveOrgID         VARCHAR2(20); --接收机构
    vCreateOrgID          VARCHAR2(20); --创建机构
    vCallTransferTypeDesc varchar2(20);
    v_Remark              varchar2(200); --按钮数组
    v_Remark_6            NUMBER;
    v_count               number;
  begin

    vIsReject := '0';
    if PSubmitType = '2' then
      vIsReject := '1';
    end if;

    vReceiveOrgID := PReceiveOrgID;

    --获取呼叫流转审核当前最新信息
    SELECT A.Msgid,
           A.Frequency,
           A.Receiveorgid,
           A.Currentstatus,
           A.Senduserid,
           A.REMARK_6
      INTO vMsgID,
           vFrequency,
           VSendOrgID,
           vCurrentstatus,
           vSenduserid,
           v_Remark_6
      FROM jkpt_msg_calltransfer_audit A
     WHERE A.Auditid = PAuditID
       AND A.Iscurrent = '1';

    --判断是否重复提交
    if PREMARK_6 <> v_Remark_6 then
      PRETURNVAL := 0;
      select '该 ' ||
             fun_get_dicname('CallTransferType', a.calltransfertype) ||
             ' 已被 ' || c.username || ' 处理完成'
        into PMSG
        from JKPT_MSG_CALLTRANSFER_BASE  a,
             JKPT_MSG_CALLTRANSFER_AUDIT b,
             jkpt_base_user              c
       where a.msgid = b.msgid
         and b.Auditid = PAuditID
         and b.senduserid = c.loginid;
      return;
    end if;

    --每次修改变量+1，控制重复提交
    update jkpt_msg_calltransfer_audit a
       set a.remark_6 = nvl(a.remark_6, 1) + 1
     where msgid = vMsgID;

    --呼叫中心处理
    IF PJSDealType = 'CallCenter' THEN
      --放入回收站
      VSUGGESTION := '无效呼叫流转';
      select a.creationorgid
        into vReceiveOrgID
        from jkpt_msg_calltransfer_base a
       where a.msgid = vMsgID;

      UPDATE JKPT_MSG_CALLTRANSFER_BASE A
         SET FINISHTIME     = SYSDATE,
             ISRECYCLEBIN   = '1',
             USEDDAYS       = FUNC_BASE_GETDAYS(A.CREATIONTIME, SYSDATE),
             SENDORGID      = VSendOrgID,
             SENDUSERID     = PSendUserID,
             SENDDATE       = SYSDATE,
             RECEIVEORGID   = vReceiveOrgID,
             SENDARGEE      = PSuggestion,
             WAITSTATUSDESC = VSuggestion
       WHERE MSGID = vMsgID;

      UPDATE JKPT_MSG_CALLTRANSFER_AUDIT A
         SET ISRECYCLEBIN      = '1',
             SENDORGID         = VSendOrgID,
             SENDUSERID        = PSendUserID,
             RECEIVEORGID      = vReceiveOrgID,
             CURRENTSTATUSDESC = VSuggestion,
             CURRENTSUGGESTION = PSuggestion,
             FINISHTIME        = SYSDATE,
             CURRENTSTATUS     = 98,
             USEDDAYS          = FUNC_BASE_GETDAYS(A.DEALTIME, SYSDATE),
             REMARK_2          = replace(REMARK_2, ':1', ':2')
       WHERE AUDITID = PAuditID;

      insert into jkpt_msg_calltransfer_detail
        (detailid,
         auditid,
         msgid,
         frequency,
         sendorgid,
         senduserid,
         receiveorgid,
         startstatus,
         endstatus,
         statusdesc,
         suggestion,
         statusinfo)
      values
        (seq_msg_detail.nextval,
         PAuditID,
         vMsgID,
         vFrequency,
         VSendOrgID,
         PSendUserID,
         vReceiveOrgID,
         vCurrentstatus,
         98,
         vSuggestion,
         PSuggestion,
         vSuggestion);

      COMMIT;
      PRETURNVAL := 1;
      RETURN;
    END IF;

    --获取接收机构
    IF PJSDealType = 'MonitorDept' OR PJSDealType = 'GaoLuHearCenter' OR
       PJSDealType = 'SubCenter' THEN
      if PSubmitType = '2' then
        --获取接收机构
        select a.sendorgid
          into vReceiveOrgID
          from jkpt_msg_calltransfer_detail a
         where a.auditid = PAuditID
           and a.msgid = vMsgID
           and a.frequency = vFrequency
           and a.receiveorgid = VSendOrgID
           and a.isreject = '0'
           and rownum = 1
           and a.sendorgid <> a.receiveorgid;

        --驳回
        select a.rejectstatus,
               a.rejectdescribe,
               a.dealrejectdescribe,
               a.remark_2
          into vCurDealStatus, vCurDealDescribe, vDealDescribe, v_Remark
          from jkpt_msg_stepdefine a
         where a.modelname = 'MSG_CALLTRANSFER_BASE'
           and a.sendorggroup = ANY
         (select b.grouptype
                  from jkpt_msg_orgrelation b
                 where b.sendorgid = vReceiveOrgID)
           AND A.successreceiveorggroup = ANY
         (select b.grouptype
                  from jkpt_msg_orgrelation b
                 where b.sendorgid = VSendOrgID);
      else
        --如果是受理，则处理机构是自己
        if PSubmitType = '3' or PSubmitType = '4' then
          vReceiveOrgID := VSendOrgID;
        end if;
        --通过
        select a.successstatus,
               a.successdescribe,
               a.dealsucessdescribe,
               a.remark_1
          into vCurDealStatus, vCurDealDescribe, vDealDescribe, v_Remark
          from jkpt_msg_stepdefine a
         where a.modelname = 'MSG_CALLTRANSFER_BASE'
           and a.sendorggroup = ANY
         (select b.grouptype
                  from jkpt_msg_orgrelation b
                 where b.sendorgid = VSendOrgID)
           AND A.successreceiveorggroup = ANY
         (select b.grouptype
                  from jkpt_msg_orgrelation b
                 where b.sendorgid = vReceiveOrgID);
      end if;
    END IF;

    --处理完成
    if PSubmitType = '4' then
      vCurDealStatus := '99';
      VSuggestion    := '呼叫流转已处理完成';
      vDealDescribe  := '已处理完成';
    end if;

    insert into jkpt_msg_calltransfer_detail
      (detailid,
       auditid,
       msgid,
       frequency,
       sendorgid,
       senduserid,
       receiveorgid,
       startstatus,
       endstatus,
       statusdesc,
       suggestion,
       statusinfo,
       isreject)
    values
      (seq_msg_detail.nextval,
       PAuditID,
       vMsgID,
       vFrequency,
       VSendOrgID,
       PSendUserID,
       vReceiveOrgID,
       vCurrentstatus,
       vCurDealStatus,
       vCurDealDescribe,
       PSuggestion,
       vDealDescribe,
       vIsReject);

    UPDATE JKPT_MSG_CALLTRANSFER_AUDIT A
       SET SENDORGID         = VSendOrgID,
           SENDUSERID        = PSendUserID,
           RECEIVEORGID      = vReceiveOrgID,
           CURRENTSTATUSDESC = vCurDealDescribe,
           CURRENTSUGGESTION = PSuggestion,
           DEALTIME          = sysdate,
           ISREJECT          = vIsReject,
           CURRENTSTATUS     = vCurDealStatus,
           REMARK_2          = v_Remark
     WHERE AUDITID = PAuditID;

    UPDATE JKPT_MSG_CALLTRANSFER_BASE A
       SET SENDORGID      = VSendOrgID,
           SENDUSERID     = PSendUserID,
           SENDDATE       = SYSDATE,
           RECEIVEORGID   = vReceiveOrgID,
           SENDARGEE      = PSuggestion,
           WAITSTATUSDESC = vCurDealDescribe
     WHERE MSGID = vMsgID;

    if PSubmitType = '4' then

      UPDATE JKPT_MSG_CALLTRANSFER_BASE A
         SET FINISHTIME     = SYSDATE,
             ISFINISH       = '1',
             USEDDAYS       = FUNC_BASE_GETDAYS(A.CREATIONTIME, SYSDATE),
             WAITSTATUSDESC = VSuggestion
       WHERE MSGID = vMsgID;

      UPDATE JKPT_MSG_CALLTRANSFER_AUDIT A
         SET ISFINISH          = '1',
             CURRENTSTATUSDESC = VSuggestion,
             CURRENTSUGGESTION = PSuggestion,
             FINISHTIME        = SYSDATE,
             CURRENTSTATUS     = vCurDealStatus,
             USEDDAYS          = FUNC_BASE_GETDAYS(A.DEALTIME, SYSDATE),
             REMARK_2          = replace(REMARK_2, ':1', ':2')
       WHERE AUDITID = PAuditID;

      select a.creationorgid,
             (select t.dicname
                from jkpt_comm_paramdic t
               where t.grouptype = 'CallTransferType'
                 and dicvalue = a.calltransfertype)
        into vCreateOrgID, vCallTransferTypeDesc
        from jkpt_msg_calltransfer_base a
       where a.msgid = vMsgID;
      insert into jkpt_base_msg
        (id,
         content,
         receiveorgid,
         receiveuserid,
         type,
         sendtype,
         relationid,
         url)
        select seq_base_msgid.nextval,
               vCallTransferTypeDesc || ' 处理完成',
               vCreateOrgID,
               userid,
               2,
               2,
               vMsgID,
               '/callTransfer/toDetail.from?msgId=' || vMsgID ||
               '&auditInfoId=' || PAuditID
          from jkpt_base_user
         where orgid = vCreateOrgID;
    end if;

    --分中心受理标识
    if PSubmitType = '3' and PJSDealType = 'SubCenter' then
      update JKPT_MSG_CALLTRANSFER_AUDIT a
         set a.remark_1 = '1'
       where AUDITID = PAuditID;
      update JKPT_MSG_CALLTRANSFER_BASE a
         set a.remark_1 = '1'
       where msgid = vMsgID;
    end if;

    --分中心驳回
    if PSubmitType = '2' and PJSDealType = 'SubCenter' then
      update JKPT_MSG_CALLTRANSFER_AUDIT a
         set a.remark_1 ='0'
       where AUDITID = PAuditID;
      update JKPT_MSG_CALLTRANSFER_BASE a
         set a.remark_1 = NULL
       where msgid = vMsgID;
    end if;

    --判断是否驳回
    if vIsReject = '1' then
      select count(1)
        into v_count
        from jkpt_flow_reject
       where flowtype = 1
         and flowid = vMsgID
         and receivedorgid = vReceiveOrgID;
      if v_count = 0 then
        insert into jkpt_flow_reject values (1, vMsgID, vReceiveOrgID);
      end if;
    end if;
    --判断接受机构是否存在，如果不存在，则添加
    select count(1) into v_count from jkpt_msg_receiveorg where flowid=vMsgID and orgid=vReceiveOrgID;
    if v_count = 0 then
        insert into jkpt_msg_receiveorg values (vMsgID, vReceiveOrgID);
    end if;

    COMMIT;
    PRETURNVAL := 1;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PRETURNVAL := 0;
      PMSG       := SQLERRM;
      INSERT INTO JKPT_COMM_LOG
        (LOGID, MAINMODULE, USERID, OPESUMMARIZE, ISEXCEPTION, REMARK1)
      VALUES
        (SEQ_COMM_LOG_ID.NEXTVAL,
         '呼叫流转管理',
         PSendUserID,
         PMSG,
         '1',
         '呼叫流转审核出现异常');
      COMMIT;
      PMSG := '执行失败';
  end PROC_MSG_FLOWAUDIT;

  --重新流转
  procedure PROC_ReAddCallTransfer(pCreationUserID   IN varchar2,
                                   pContent          in varchar2,
                                   pCreationOrgID    in varchar2,
                                   pCustomerName     in varchar2,
                                   pCustomerMobile   in varchar2,
                                   pPosition         in varchar2,
                                   pCallTransferType in varchar2,
                                   pPlateNum         in varchar2,
                                   pModel            in varchar2,
                                   pDirection        in varchar2,
                                   pAuditID          in varchar2,
                                   pRemark_3         in varchar2, --话务系统单号
                                   pReturnVal        out number,
                                   pMSG              out varchar2) as
    vMsgID          number;
    vWaitStatusDesc varchar2(100);
    vAuditStatus    number; --审核后状态
    vAuditInfo      varchar2(100);
    vFrequency      number;
    v_Remark        varchar2(200); --按钮数组
    vReceiveOrgID   varchar2(20);
    vAuditID        number;
  begin
    pReturnVal := 1;
    pMSG       := '';

    SELECT A.Msgid, A.Frequency
      INTO vMsgID, vFrequency
      FROM jkpt_msg_calltransfer_audit A
     WHERE A.Auditid = PAuditID
       AND A.Iscurrent = '1';

    select a.receiveorgid
      into vReceiveOrgID
      from jkpt_msg_orgrelation a
     where a.grouptype = 'CallCenter'
       and rownum = 1;

    --获取流程初始状态信息
    select a.successstatus,
           a.successdescribe,
           a.dealsucessdescribe,
           a.remark_1
      into vAuditStatus, vWaitStatusDesc, vAuditInfo, v_Remark
      from jkpt_msg_stepdefine a
     where a.modelname = 'MSG_CALLTRANSFER_BASE'
       and a.sendorggroup = ANY (select b.grouptype
              from jkpt_msg_orgrelation b
             where b.sendorgid = pCreationOrgID)
       AND A.successreceiveorggroup = ANY
     (select b.grouptype
              from jkpt_msg_orgrelation b
             where b.sendorgid = vReceiveOrgID);

    update jkpt_msg_calltransfer_base
       set creationuserid   = pCreationUserID,
           content          = pContent,
           creationorgid    = pCreationOrgID,
           customername     = pCustomerName,
           customermobile   = pCustomerMobile,
           position         = pPosition,
           calltransfertype = pCallTransferType,
           platenum         = pPlateNum,
           model            = pModel,
           direction        = pDirection,
           sendorgid        = pCreationOrgID,
           senduserid       = pCreationUserID,
           senddate         = sysdate,
           receiveorgid     = vReceiveOrgID,
           sendargee        = null,
           waitstatusdesc   = vWaitStatusDesc,
           remark_3         = pRemark_3
     where msgid = vMsgID;
    select seq_msg_audit.nextval into vAuditID from dual;
    insert into jkpt_msg_calltransfer_audit
      (auditid,
       msgid,
       frequency,
       sendorgid,
       senduserid,
       receiveorgid,
       currentstatusdesc,
       currentstatus,
       remark_2)
    values
      (vAuditID,
       vMsgID,
       vFrequency + 1,
       pCreationOrgID,
       pCreationUserID,
       vReceiveOrgID,
       vWaitStatusDesc,
       1,
       v_Remark);
    insert into jkpt_msg_calltransfer_detail
      (detailid,
       auditid,
       msgid,
       frequency,
       sendorgid,
       senduserid,
       receiveorgid,
       startstatus,
       endstatus,
       statusdesc,
       suggestion,
       statusinfo)
    values
      (seq_msg_detail.nextval,
       vAuditID,
       vMsgID,
       vFrequency + 1,
       pCreationOrgID,
       pCreationUserID,
       vReceiveOrgID,
       1,
       vAuditStatus,
       vWaitStatusDesc,
       '',
       vAuditInfo);

    update jkpt_msg_calltransfer_audit a
       set a.iscurrent = '0'
     where a.auditid = PAuditID;
    commit;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败' || sqlerrm;
  end PROC_ReAddCallTransfer;

  FUNCTION FUN_getstatusdescpart1(pMsgid in number) RETURN VARCHAR2 AS
    RETURNVAL     VARCHAR2(1000) := '';
    mTimes        number;
    mCreationTime varchar2(20) := '';
  BEGIN
    select a.frequency + 1, to_char(a.DEALTIME, 'yyyy-MM-dd hh24:mi:ss')
      into mTimes, mCreationTime
      from Jkpt_Msg_Calltransfer_Audit a, jkpt_base_org b
     where a.msgid = pMsgid
       and a.iscurrent = 1
       and a.receiveorgid = b.orgid;
    if (mTimes = 1) then
      RETURNVAL := mCreationTime;
    else
      RETURNVAL := '第' || mTimes || '次处理' || ' ' || mCreationTime;
    end if;

    return RETURNVAL;
  END FUN_getstatusdescpart1;

  FUNCTION FUN_getstatusdescpart2(pMsgid in number) RETURN VARCHAR2 AS
    RETURNVAL          VARCHAR2(1000) := '';
    mCurrentOrgName    varchar2(20) := '';
    mCurrentStatusDesc varchar2(100) := '';
  BEGIN
    select b.orgname, a.currentstatusdesc
      into mCurrentOrgName, mCurrentStatusDesc
      from Jkpt_Msg_Calltransfer_Audit a, jkpt_base_org b
     where a.msgid = pMsgid
       and a.iscurrent = 1
       and a.receiveorgid = b.orgid;

    RETURNVAL := mCurrentOrgName || ' 【' || mCurrentStatusDesc || '】';

    return RETURNVAL;
  END FUN_getstatusdescpart2;

  function FUN_GETMYCURRENTCOUNT(pOrgID in varchar2) return number as
    mCount       number;
    mIsSubCenter number;
  begin
    select count(*)
      into mIsSubCenter
      from jkpt_MSG_orgrelation t
     where t.grouptype = 'SubCenter'
       and t.sendorgid = pOrgID;

    if (mIsSubCenter = 0) then
      select count(*)
        into mCount
        from jkpt_msg_calltransfer_base a, jkpt_msg_calltransfer_audit b
       where a.msgid = b.msgid
         and b.iscurrent = 1
         and a.receiveorgid = pOrgID
         and a.isfinish = '0'
         and a.isrecyclebin = '0';
    else
      select count(*)
        into mCount
        from jkpt_msg_calltransfer_base a, jkpt_msg_calltransfer_audit b
       where a.msgid = b.msgid
         and b.iscurrent = 1
         and a.receiveorgid = pOrgID
         and a.isfinish = '0'
         and a.isrecyclebin = '0'
         and nvl(b.remark_1, ' ') <> '1'; --对于分中心来说 已经受理的不再提示
    end if;

    return mCount;

  end FUN_GETMYCURRENTCOUNT;

end PG_JKPT_XXZX_CALLTRANSFER_WF;
/

