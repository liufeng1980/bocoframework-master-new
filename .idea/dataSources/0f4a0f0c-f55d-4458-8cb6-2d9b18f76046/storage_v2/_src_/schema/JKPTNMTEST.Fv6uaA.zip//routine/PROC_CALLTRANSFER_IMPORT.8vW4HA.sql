create PROCEDURE PROC_CallTransfer_Import(pReturnVal OUT NUMBER,
                                                     pMsg       OUT varchar2) AS
  vMsgID            number;
  vCreationUserID   varchar2(20);
  vCreationTime     date;
  vContent          varchar2(600);
  vStatus           number;
  vCreationOrgID    varchar2(10);
  vCustomerName     varchar2(20);
  vCustomerMobile   varchar2(20);
  vPosition         varchar2(100);
  vCallTransferType number;
  vPlatenum         varchar2(15);
  vModel            varchar2(20);
  vDirection        varchar2(100);
  vCode             varchar2(20);
  vSendOrgID        varchar2(20);
  vSendTime         date;
  vReceiveOrgID     varchar2(20);
  vReplyTime        date;
  vReply            varchar2(600);
  vHandlestatus     number;
  vArchiveTime      date;
  vArchiveOrgID     varchar2(20);
  vArchiveUserID    varchar2(20);
  vLastSendOrgID    varchar2(20);
  vLastReceiveOrgID varchar2(20);
  vLastReply        varchar2(600);
  vLastReplyTime    date;
  vFlag             number;
  vTempMsgID        number;
  vSuggestion       varchar2(600); --当前处理人的处理意见及要求
  vAuditID          number;
  vIsReject         varchar2(1);
  vCurDealStatus    NUMBER; --获取待流转流程状态
  vCurDealDescribe  VARCHAR2(100); --获取待流转流程描述
  vDealDescribe     VARCHAR2(100); --审核通过或者驳回描述信息：（通过，驳回）
  /*v_Remark          varchar2(200); --按钮数组*/

  cursor CUR_1 is
    select a.msgid,
           a.creationuserid,
           a.creationtime,
           a.content,
           a.status,
           a.creationorgid,
           a.customername,
           a.customermobile,
           a.position,
           a.calltransfertype,
           a.platenum,
           a.model,
           a.direction,
           a.code,
           a.sendorgid,
           a.sendtime,
           a.receiveorgid,
           a.replytime,
           a.reply,
           a.handlestatus,
           a.archivetime,
           a.archiveorgid,
           a.archiveuserid,
           c.sendorgid,
           c.receiveorgid,
           c.reply,
           c.replytime
      from (select a.msgid,
                   a.creationuserid,
                   a.creationtime,
                   a.content,
                   a.status,
                   a.creationorgid,
                   a.customername,
                   a.customermobile,
                   a.position,
                   a.calltransfertype,
                   a.platenum,
                   a.model,
                   a.direction,
                   a.code,
                   b.sendorgid,
                   b.sendtime,
                   b.receiveorgid,
                   b.replytime,
                   b.reply,
                   b.handlestatus,
                   a.archivetime,
                   a.archiveorgid,
                   a.archiveuserid,
                   b.receiveid,
                   a.dealtype
              from jkpt_msg_ct_temp a, jkpt_msg_ct_receivetemp b
             where a.msgid = b.msgid
               and a.msgid in
                   (select a.msgid
                      from jkpt_msg_ct_receivetemp a
                     where a.handlestatus = 5
                       and a.msgid in (select msgid
                                         from jkpt_msg_ct_temp b
                                        where b.status = 2)
                     group by a.msgid
                    having count(1) <= 2)) a,
           (select m.msgid,
                   m.sendorgid,
                   m.receiveorgid,
                   m.reply,
                   m.replytime
              from jkpt_msg_ct_receivetemp m
             where m.receiveid = (select max(n.receiveid)
                                    from jkpt_msg_ct_receivetemp n
                                   where m.msgid = n.msgid)) c
     where a.msgid = c.msgid
       and a.dealtype is null
     order by a.msgid, a.receiveid;

  cursor CUR_2 is
    select a.msgid,
           a.creationuserid,
           a.creationtime,
           a.content,
           a.status,
           a.creationorgid,
           a.customername,
           a.customermobile,
           a.position,
           a.calltransfertype,
           a.platenum,
           a.model,
           a.direction,
           a.code,
           a.sendorgid,
           a.sendtime,
           a.receiveorgid,
           a.replytime,
           a.reply,
           a.handlestatus,
           a.archivetime,
           a.archiveorgid,
           a.archiveuserid,
           c.sendorgid,
           c.receiveorgid,
           c.reply,
           c.replytime
      from (select a.msgid,
                   a.creationuserid,
                   a.creationtime,
                   a.content,
                   a.status,
                   a.creationorgid,
                   a.customername,
                   a.customermobile,
                   a.position,
                   a.calltransfertype,
                   a.platenum,
                   a.model,
                   a.direction,
                   a.code,
                   b.sendorgid,
                   b.sendtime,
                   b.receiveorgid,
                   b.replytime,
                   b.reply,
                   b.handlestatus,
                   a.archivetime,
                   a.archiveorgid,
                   a.archiveuserid,
                   b.receiveid,
                   a.dealtype
              from jkpt_msg_ct_temp a, jkpt_msg_ct_receivetemp b
             where a.msgid = b.msgid
               and a.msgid in
                   (select a.msgid
                      from jkpt_msg_ct_receivetemp a
                     where a.handlestatus = 3
                       and a.msgid in (select msgid
                                         from jkpt_msg_ct_temp b
                                        where b.status = 1)
                     group by a.msgid
                    having count(1) <= 2)) a,
           (select m.msgid,
                   m.sendorgid,
                   m.receiveorgid,
                   m.reply,
                   m.replytime
              from jkpt_msg_ct_receivetemp m
             where m.receiveid = (select max(n.receiveid)
                                    from jkpt_msg_ct_receivetemp n
                                   where m.msgid = n.msgid)) c
     where a.msgid = c.msgid
       and a.dealtype is null
     order by a.msgid, a.receiveid;

  cursor CUR_3 is
    select a.msgid,
           a.creationuserid,
           a.creationtime,
           a.content,
           a.status,
           a.creationorgid,
           a.customername,
           a.customermobile,
           a.position,
           a.calltransfertype,
           a.platenum,
           a.model,
           a.direction,
           a.code,
           a.sendorgid,
           a.sendtime,
           a.receiveorgid,
           a.replytime,
           a.reply,
           a.handlestatus,
           a.archivetime,
           a.archiveorgid,
           a.archiveuserid,
           c.sendorgid,
           c.receiveorgid,
           c.reply,
           c.replytime
      from (select a.msgid,
                   a.creationuserid,
                   a.creationtime,
                   a.content,
                   a.status,
                   a.creationorgid,
                   a.customername,
                   a.customermobile,
                   a.position,
                   a.calltransfertype,
                   a.platenum,
                   a.model,
                   a.direction,
                   a.code,
                   b.sendorgid,
                   b.sendtime,
                   b.receiveorgid,
                   b.replytime,
                   b.reply,
                   b.handlestatus,
                   a.archivetime,
                   a.archiveorgid,
                   a.archiveuserid,
                   b.receiveid,
                   a.dealtype
              from jkpt_msg_ct_temp a, jkpt_msg_ct_receivetemp b
             where a.msgid = b.msgid
               and a.msgid in
                   (select a.msgid
                      from jkpt_msg_ct_receivetemp a
                     where a.handlestatus = 3
                       and a.msgid in (select msgid
                                         from jkpt_msg_ct_temp b
                                        where b.status = 1)
                     group by a.msgid
                    having count(1) <= 2)) a,
           (select m.msgid,
                   m.sendorgid,
                   m.receiveorgid,
                   m.reply,
                   m.replytime
              from jkpt_msg_ct_receivetemp m
             where m.receiveid = (select max(n.receiveid)
                                    from jkpt_msg_ct_receivetemp n
                                   where m.msgid = n.msgid)) c
     where a.msgid = c.msgid
       and handlestatus = 3
       and a.dealtype is null
     order by a.msgid, a.receiveid desc;

  cursor CUR_4 is
    select a.msgid,
           a.creationuserid,
           a.creationtime,
           a.content,
           a.status,
           a.creationorgid,
           a.customername,
           a.customermobile,
           a.position,
           a.calltransfertype,
           a.platenum,
           a.model,
           a.direction,
           a.code,
           a.sendorgid,
           a.sendtime,
           a.receiveorgid,
           a.replytime,
           a.reply,
           a.handlestatus,
           a.archivetime,
           a.archiveorgid,
           a.archiveuserid,
           c.sendorgid,
           c.receiveorgid,
           c.reply,
           c.replytime
      from (select a.msgid,
                   a.creationuserid,
                   a.creationtime,
                   a.content,
                   a.status,
                   a.creationorgid,
                   a.customername,
                   a.customermobile,
                   a.position,
                   a.calltransfertype,
                   a.platenum,
                   a.model,
                   a.direction,
                   a.code,
                   b.sendorgid,
                   b.sendtime,
                   b.receiveorgid,
                   b.replytime,
                   b.reply,
                   b.handlestatus,
                   a.archivetime,
                   a.archiveorgid,
                   a.archiveuserid,
                   b.receiveid,
                   a.dealtype
              from jkpt_msg_ct_temp a, jkpt_msg_ct_receivetemp b
             where a.msgid = b.msgid
               and a.msgid in
                   (select a.msgid
                      from jkpt_msg_ct_receivetemp a
                     where a.handlestatus = 4
                       and a.msgid in (select msgid
                                         from jkpt_msg_ct_temp b
                                        where b.status = 1)
                     group by a.msgid
                    having count(1) = 1)) a,
           (select m.msgid,
                   m.sendorgid,
                   m.receiveorgid,
                   m.reply,
                   m.replytime
              from jkpt_msg_ct_receivetemp m
             where m.receiveid = (select max(n.receiveid)
                                    from jkpt_msg_ct_receivetemp n
                                   where m.msgid = n.msgid)) c
     where a.msgid = c.msgid
       and a.dealtype is null
     order by a.msgid, a.receiveid;

BEGIN
  pReturnVal  := 1;
  pMSG        := '';
  vFlag       := 0;
  vIsReject   := '0';
  VSuggestion := '呼叫流转已处理完成';

  --begin 清除无用数据
  --删除有从表，无主表
  delete from jkpt_msg_ct_receivetemp a
   where a.msgid not in (select b.msgid from jkpt_msg_ct_temp b);

  --删除呼叫中心多发记录
  delete from jkpt_msg_ct_receivetemp a
   where a.receiveid in (5256, 5253, 545);

  --修改监控部发给分中心处理状态
  update jkpt_msg_ct_receivetemp a
     set a.handlestatus = 3
   where a.receiveid in (957, 908, 895, 818, 604, 505, 462);

  --修改分中心先处理完成，再受理
  update jkpt_msg_ct_receivetemp a
     set a.handlestatus = 5
   where a.receiveid in (1034, 1041, 1040, 1033, 1020, 1018, 505);

  --删除监控部同时多次转发
  delete from jkpt_msg_ct_receivetemp a
   where a.receiveid in (393, 394, 395, 396, 397, 400, 401);

  --更新已处理完成的状态
  update jkpt_msg_ct_temp a
     set a.status = 2
   where a.msgid in (select a.msgid
                       from jkpt_msg_ct_receivetemp a
                      where a.handlestatus = 5
                        and a.msgid in (select msgid
                                          from jkpt_msg_ct_temp b
                                         where b.status = 1));

  --删除呼叫流转转给呼叫中心的数据
  delete from jkpt_msg_ct_temp a
   where a.msgid in (609, 614, 551, 464);
  delete from jkpt_msg_ct_receivetemp a
   where a.msgid in (609, 614, 551, 464);

  --end 清除无用数据

  --begin 处理 已完成并且处理完成 的记录
  OPEN CUR_1;
  LOOP
    FETCH CUR_1
      into vMsgID,
           vCreationUserID,
           vCreationTime,
           vContent,
           vStatus,
           vCreationOrgID,
           vCustomerName,
           vCustomerMobile,
           vPosition,
           vCallTransferType,
           vPlatenum,
           vModel,
           vDirection,
           vCode,
           vSendOrgID,
           vSendTime,
           vReceiveOrgID,
           vReplyTime,
           vReply,
           vHandlestatus,
           vArchiveTime,
           vArchiveOrgID,
           vArchiveUserID,
           vLastSendOrgID,
           vLastReceiveOrgID,
           vLastReply,
           vLastReplyTime;
    EXIT WHEN CUR_1%NOTFOUND;

    vIsReject := '0';

    if vTempMsgID is null then
      vFlag      := 1;
      vTempMsgID := vMsgID;
    elsif vTempMsgID <> vMsgID then
      vFlag      := 1;
      vTempMsgID := vMsgID;
    else
      vFlag := 0;
    end if;

    if vFlag = 1 then
      insert into jkpt_msg_calltransfer_base
        (msgid,
         creationuserid,
         creationtime,
         content,
         status,
         creationorgid,
         customername,
         customermobile,
         position,
         calltransfertype,
         platenum,
         model,
         direction,
         code,
         useddays,
         isfinish,
         isrecyclebin,
         finishtime,
         sendorgid,
         senduserid,
         senddate,
         receiveorgid,
         sendargee,
         waitstatusdesc,
         remark_1)
      values
        (vMsgID,
         vCreationUserID,
         vCreationTime,
         vContent,
         vStatus,
         vCreationOrgID,
         vCustomerName,
         vCustomerMobile,
         vPosition,
         vCallTransferType,
         vPlatenum,
         vModel,
         vDirection,
         vCode,
         FUNC_BASE_GETDAYS(vCreationTime, vLastReplyTime),
         1,
         0,
         vArchiveTime,
         vLastReceiveOrgID,
         vArchiveUserID,
         vLastReplyTime,
         vLastReceiveOrgID,
         vLastReply,
         VSuggestion,
         '1');

      select seq_msg_audit.nextval into vAuditID from dual;
      insert into jkpt_msg_calltransfer_audit
        (auditid,
         msgid,
         frequency,
         iscurrent,
         isfinish,
         isrecyclebin,
         sendorgid,
         senduserid,
         receiveorgid,
         currentstatusdesc,
         currentsuggestion,
         dealtime,
         useddays,
         remark_1,
         finishtime,
         currentstatus,
         isreject,
         remark_2)
      values
        (vAuditID,
         vMsgID,
         0,
         1,
         1,
         0,
         vLastReceiveOrgID,
         vArchiveUserID,
         vLastReceiveOrgID,
         VSuggestion,
         VSuggestion,
         vLastReplyTime,
         FUNC_BASE_GETDAYS(vCreationTime, vLastReplyTime),
         '1',
         vLastReplyTime,
         99,
         0,
         'shouli:2,bohui:2,tongguo:0,chuliwancheng:2,btnPutinRecycle:0,btnReturnProcess:0');

      update jkpt_msg_ct_temp set DEALTYPE = '1' where msgid = vMsgID;
    end if;

    if vSendOrgID = '0110000' then
      insert into jkpt_msg_calltransfer_detail
        (detailid,
         auditid,
         msgid,
         frequency,
         sendorgid,
         senduserid,
         receiveorgid,
         dealtime,
         startstatus,
         endstatus,
         isreject,
         statusdesc,
         suggestion,
         statusinfo)
      values
        (seq_msg_detail.nextval,
         vAuditID,
         vMsgID,
         0,
         vSendOrgID,
         vCreationUserID,
         vReceiveOrgID,
         vSendTime,
         1,
         1,
         vIsReject,
         '呼叫流转待联网中心监控部响应',
         '',
         '呼叫流转已受理');
    elsif vSendOrgID = '0010000' and vHandlestatus = 3 then

      select a.successstatus, a.successdescribe, a.dealsucessdescribe
        into vCurDealStatus, vCurDealDescribe, vDealDescribe
        from jkpt_msg_stepdefine a
       where a.modelname = 'MSG_CALLTRANSFER_BASE'
         and a.sendorggroup = ANY
       (select b.grouptype
                from jkpt_msg_orgrelation b
               where b.sendorgid = vSendOrgID)
         AND A.successreceiveorggroup = ANY
       (select b.grouptype
                from jkpt_msg_orgrelation b
               where b.sendorgid = vReceiveOrgID);

      insert into jkpt_msg_calltransfer_detail
        (detailid,
         auditid,
         msgid,
         frequency,
         sendorgid,
         senduserid,
         receiveorgid,
         dealtime,
         startstatus,
         endstatus,
         isreject,
         statusdesc,
         suggestion,
         statusinfo)
      values
        (seq_msg_detail.nextval,
         vAuditID,
         vMsgID,
         0,
         vSendOrgID,
         NULL,
         vReceiveOrgID,
         vSendTime,
         1,
         vCurDealStatus,
         vIsReject,
         vCurDealDescribe,
         '',
         vDealDescribe);

      vIsReject := 1;
      select a.rejectstatus, a.rejectdescribe, a.dealrejectdescribe
        into vCurDealStatus, vCurDealDescribe, vDealDescribe
        from jkpt_msg_stepdefine a
       where a.modelname = 'MSG_CALLTRANSFER_BASE'
         and a.sendorggroup = ANY
       (select b.grouptype
                from jkpt_msg_orgrelation b
               where b.sendorgid = vSendOrgID)
         AND A.successreceiveorggroup = ANY
       (select b.grouptype
                from jkpt_msg_orgrelation b
               where b.sendorgid = vReceiveOrgID);

      insert into jkpt_msg_calltransfer_detail
        (detailid,
         auditid,
         msgid,
         frequency,
         sendorgid,
         senduserid,
         receiveorgid,
         dealtime,
         startstatus,
         endstatus,
         isreject,
         statusdesc,
         suggestion,
         statusinfo)
      values
        (seq_msg_detail.nextval,
         vAuditID,
         vMsgID,
         0,
         vReceiveOrgID,
         NULL,
         vSendOrgID,
         vReplyTime,
         2,
         1,
         vIsReject,
         vCurDealDescribe,
         vReply,
         vDealDescribe);
    else
      vIsReject := 0;
      select a.successstatus, a.successdescribe, a.dealsucessdescribe
        into vCurDealStatus, vCurDealDescribe, vDealDescribe
        from jkpt_msg_stepdefine a
       where a.modelname = 'MSG_CALLTRANSFER_BASE'
         and a.sendorggroup = ANY
       (select b.grouptype
                from jkpt_msg_orgrelation b
               where b.sendorgid = vSendOrgID)
         AND A.successreceiveorggroup = ANY
       (select b.grouptype
                from jkpt_msg_orgrelation b
               where b.sendorgid = vReceiveOrgID);

      insert into jkpt_msg_calltransfer_detail
        (detailid,
         auditid,
         msgid,
         frequency,
         sendorgid,
         senduserid,
         receiveorgid,
         dealtime,
         startstatus,
         endstatus,
         isreject,
         statusdesc,
         suggestion,
         statusinfo)
      values
        (seq_msg_detail.nextval,
         vAuditID,
         vMsgID,
         0,
         vSendOrgID,
         NULL,
         vReceiveOrgID,
         vSendTime,
         2,
         3,
         vIsReject,
         vCurDealDescribe,
         '',
         vDealDescribe);

      VSuggestion := '呼叫流转已处理完成';
      insert into jkpt_msg_calltransfer_detail
        (detailid,
         auditid,
         msgid,
         frequency,
         sendorgid,
         senduserid,
         receiveorgid,
         dealtime,
         startstatus,
         endstatus,
         isreject,
         statusdesc,
         suggestion,
         statusinfo)
      values
        (seq_msg_detail.nextval,
         vAuditID,
         vMsgID,
         0,
         vReceiveOrgID,
         vArchiveUserID,
         vReceiveOrgID,
         vReplyTime,
         3,
         99,
         vIsReject,
         VSuggestion,
         vLastReply,
         vDealDescribe);
    end if;

  END LOOP;
  CLOSE CUR_1;
  --end 处理 已完成并且处理完成 的记录

  --begin 处理已驳回 的记录

  --先处理审核
  OPEN CUR_2;
  LOOP
    FETCH CUR_2
      into vMsgID,
           vCreationUserID,
           vCreationTime,
           vContent,
           vStatus,
           vCreationOrgID,
           vCustomerName,
           vCustomerMobile,
           vPosition,
           vCallTransferType,
           vPlatenum,
           vModel,
           vDirection,
           vCode,
           vSendOrgID,
           vSendTime,
           vReceiveOrgID,
           vReplyTime,
           vReply,
           vHandlestatus,
           vArchiveTime,
           vArchiveOrgID,
           vArchiveUserID,
           vLastSendOrgID,
           vLastReceiveOrgID,
           vLastReply,
           vLastReplyTime;
    EXIT WHEN CUR_2%NOTFOUND;

    vIsReject := '0';

    if vTempMsgID is null then
      vFlag      := 1;
      vTempMsgID := vMsgID;
    elsif vTempMsgID <> vMsgID then
      vFlag      := 1;
      vTempMsgID := vMsgID;
    else
      vFlag := 0;
    end if;

    if vFlag = 1 then
      insert into jkpt_msg_calltransfer_base
        (msgid,
         creationuserid,
         creationtime,
         content,
         status,
         creationorgid,
         customername,
         customermobile,
         position,
         calltransfertype,
         platenum,
         model,
         direction,
         code,
         useddays,
         isfinish,
         isrecyclebin,
         finishtime,
         sendorgid,
         senduserid,
         senddate,
         receiveorgid,
         sendargee,
         waitstatusdesc)
      values
        (vMsgID,
         vCreationUserID,
         vCreationTime,
         vContent,
         vStatus,
         vCreationOrgID,
         vCustomerName,
         vCustomerMobile,
         vPosition,
         vCallTransferType,
         vPlatenum,
         vModel,
         vDirection,
         vCode,
         NULL,
         0,
         0,
         NULL,
         vReceiveOrgID,
         NULL,
         vLastReplyTime,
         vSendOrgID,
         vLastReply,
         '呼叫流转待呼叫中心响应');

      select seq_msg_audit.nextval into vAuditID from dual;
      insert into jkpt_msg_calltransfer_audit
        (auditid,
         msgid,
         frequency,
         iscurrent,
         isfinish,
         isrecyclebin,
         sendorgid,
         senduserid,
         receiveorgid,
         currentstatusdesc,
         currentsuggestion,
         dealtime,
         useddays,
         remark_1,
         finishtime,
         currentstatus,
         isreject)
      values
        (vAuditID,
         vMsgID,
         0,
         1,
         0,
         0,
         vReceiveOrgID,
         null,
         vSendOrgID,
         '呼叫流转待呼叫中心响应',
         vLastReply,
         vLastReplyTime,
         null,
         null,
         null,
         1,
         1);

    end if;

    if vSendOrgID = '0110000' then
      insert into jkpt_msg_calltransfer_detail
        (detailid,
         auditid,
         msgid,
         frequency,
         sendorgid,
         senduserid,
         receiveorgid,
         dealtime,
         startstatus,
         endstatus,
         isreject,
         statusdesc,
         suggestion,
         statusinfo)
      values
        (seq_msg_detail.nextval,
         vAuditID,
         vMsgID,
         0,
         vSendOrgID,
         vCreationUserID,
         vReceiveOrgID,
         vSendTime,
         1,
         1,
         vIsReject,
         '呼叫流转待联网中心监控部响应',
         '',
         '呼叫流转已受理');
    else
      vIsReject := 0;
      select a.successstatus, a.successdescribe, a.dealsucessdescribe
        into vCurDealStatus, vCurDealDescribe, vDealDescribe
        from jkpt_msg_stepdefine a
       where a.modelname = 'MSG_CALLTRANSFER_BASE'
         and a.sendorggroup = ANY
       (select b.grouptype
                from jkpt_msg_orgrelation b
               where b.sendorgid = vSendOrgID)
         AND A.successreceiveorggroup = ANY
       (select b.grouptype
                from jkpt_msg_orgrelation b
               where b.sendorgid = vReceiveOrgID);

      insert into jkpt_msg_calltransfer_detail
        (detailid,
         auditid,
         msgid,
         frequency,
         sendorgid,
         senduserid,
         receiveorgid,
         dealtime,
         startstatus,
         endstatus,
         isreject,
         statusdesc,
         suggestion,
         statusinfo)
      values
        (seq_msg_detail.nextval,
         vAuditID,
         vMsgID,
         0,
         vSendOrgID,
         NULL,
         vReceiveOrgID,
         vSendTime,
         1,
         vCurDealStatus,
         vIsReject,
         vCurDealDescribe,
         '',
         vDealDescribe);
    end if;

  END LOOP;
  CLOSE CUR_2;

  --再处理驳回
  OPEN CUR_3;
  LOOP
    FETCH CUR_3
      into vMsgID,
           vCreationUserID,
           vCreationTime,
           vContent,
           vStatus,
           vCreationOrgID,
           vCustomerName,
           vCustomerMobile,
           vPosition,
           vCallTransferType,
           vPlatenum,
           vModel,
           vDirection,
           vCode,
           vSendOrgID,
           vSendTime,
           vReceiveOrgID,
           vReplyTime,
           vReply,
           vHandlestatus,
           vArchiveTime,
           vArchiveOrgID,
           vArchiveUserID,
           vLastSendOrgID,
           vLastReceiveOrgID,
           vLastReply,
           vLastReplyTime;
    EXIT WHEN CUR_3%NOTFOUND;

    vIsReject := '1';
    update jkpt_msg_ct_temp set DEALTYPE = '1' where msgid = vMsgID;

    select a.rejectstatus, a.rejectdescribe, a.dealrejectdescribe
      into vCurDealStatus, vCurDealDescribe, vDealDescribe
      from jkpt_msg_stepdefine a
     where a.modelname = 'MSG_CALLTRANSFER_BASE'
       and a.sendorggroup = ANY (select b.grouptype
              from jkpt_msg_orgrelation b
             where b.sendorgid = vSendOrgID)
       AND A.successreceiveorggroup = ANY
     (select b.grouptype
              from jkpt_msg_orgrelation b
             where b.sendorgid = vReceiveOrgID);

    select a.auditid
      into vAuditID
      from jkpt_msg_calltransfer_audit a
     where a.msgid = vMsgID;

    if vSendOrgID = '0110000' then
      insert into jkpt_msg_calltransfer_detail
        (detailid,
         auditid,
         msgid,
         frequency,
         sendorgid,
         senduserid,
         receiveorgid,
         dealtime,
         startstatus,
         endstatus,
         isreject,
         statusdesc,
         suggestion,
         statusinfo)
      values
        (seq_msg_detail.nextval,
         vAuditID,
         vMsgID,
         0,
         vReceiveOrgID,
         vCreationUserID,
         vSendOrgID,
         vReplyTime,
         1,
         1,
         vIsReject,
         '呼叫流转待呼叫中心响应',
         vLastReply,
         '驳回');
      update jkpt_msg_calltransfer_audit a
         set a.remark_2 = 'shouli:0,bohui:0,tongguo:0,chuliwancheng:0,btnPutinRecycle:1,btnReturnProcess:1'
       where a.auditid = vAuditID;
      update jkpt_msg_calltransfer_audit a
         set a.currentstatusdesc = '呼叫流转待呼叫中心响应',
             a.sendorgid         = '0010000',
             a.receiveorgid      = '0110000'
       where a.auditid = vAuditID;
      update jkpt_msg_calltransfer_base a
         set a.waitstatusdesc = '呼叫流转待呼叫中心响应',
             a.sendorgid      = '0010000',
             a.receiveorgid   = '0110000'
       where a.msgid = vMsgID;
    else
      insert into jkpt_msg_calltransfer_detail
        (detailid,
         auditid,
         msgid,
         frequency,
         sendorgid,
         senduserid,
         receiveorgid,
         dealtime,
         startstatus,
         endstatus,
         isreject,
         statusdesc,
         suggestion,
         statusinfo)
      values
        (seq_msg_detail.nextval,
         vAuditID,
         vMsgID,
         0,
         vReceiveOrgID,
         NULL,
         vSendOrgID,
         vReplyTime,
         2,
         1,
         vIsReject,
         vCurDealDescribe,
         '',
         vDealDescribe);
      update jkpt_msg_calltransfer_audit a
         set a.remark_2 = 'shouli:0,bohui:1,tongguo:1,chuliwancheng:0,btnPutinRecycle:0,btnReturnProcess:0'
       where a.auditid = vAuditID;
      update jkpt_msg_calltransfer_audit a
         set a.currentstatusdesc = '呼叫流转待联网中心监控部响应',
             a.sendorgid         = vReceiveOrgID,
             a.receiveorgid      = vSendOrgID
       where a.auditid = vAuditID;
      update jkpt_msg_calltransfer_base a
         set a.waitstatusdesc = '呼叫流转待联网中心监控部响应',
             a.sendorgid      = vReceiveOrgID,
             a.receiveorgid   = vSendOrgID
       where a.msgid = vMsgID;
    end if;

  END LOOP;
  CLOSE CUR_3;
  --end 处理已驳回 的记录

  --begin 已转发 的记录
  OPEN CUR_4;
  LOOP
    FETCH CUR_4
      into vMsgID,
           vCreationUserID,
           vCreationTime,
           vContent,
           vStatus,
           vCreationOrgID,
           vCustomerName,
           vCustomerMobile,
           vPosition,
           vCallTransferType,
           vPlatenum,
           vModel,
           vDirection,
           vCode,
           vSendOrgID,
           vSendTime,
           vReceiveOrgID,
           vReplyTime,
           vReply,
           vHandlestatus,
           vArchiveTime,
           vArchiveOrgID,
           vArchiveUserID,
           vLastSendOrgID,
           vLastReceiveOrgID,
           vLastReply,
           vLastReplyTime;
    EXIT WHEN CUR_4%NOTFOUND;

    vIsReject := '0';

    if vTempMsgID is null then
      vFlag      := 1;
      vTempMsgID := vMsgID;
    elsif vTempMsgID <> vMsgID then
      vFlag      := 1;
      vTempMsgID := vMsgID;
    else
      vFlag := 0;
    end if;

    if vFlag = 1 then
      insert into jkpt_msg_calltransfer_base
        (msgid,
         creationuserid,
         creationtime,
         content,
         status,
         creationorgid,
         customername,
         customermobile,
         position,
         calltransfertype,
         platenum,
         model,
         direction,
         code,
         useddays,
         isfinish,
         isrecyclebin,
         finishtime,
         sendorgid,
         senduserid,
         senddate,
         receiveorgid,
         sendargee,
         waitstatusdesc)
      values
        (vMsgID,
         vCreationUserID,
         vCreationTime,
         vContent,
         vStatus,
         vCreationOrgID,
         vCustomerName,
         vCustomerMobile,
         vPosition,
         vCallTransferType,
         vPlatenum,
         vModel,
         vDirection,
         vCode,
         NULL,
         0,
         0,
         NULL,
         vLastSendOrgID,
         NULL,
         vLastReplyTime,
         vLastReceiveOrgID,
         vLastReply,
         '呼叫流转待分中心处理完成');

      select seq_msg_audit.nextval into vAuditID from dual;
      insert into jkpt_msg_calltransfer_audit
        (auditid,
         msgid,
         frequency,
         iscurrent,
         isfinish,
         isrecyclebin,
         sendorgid,
         senduserid,
         receiveorgid,
         currentstatusdesc,
         currentsuggestion,
         dealtime,
         useddays,
         remark_1,
         finishtime,
         currentstatus,
         isreject)
      values
        (vAuditID,
         vMsgID,
         0,
         1,
         0,
         0,
         vLastSendOrgID,
         null,
         vLastReceiveOrgID,
         '呼叫流转待分中心处理完成',
         vLastReply,
         vLastReplyTime,
         null,
         null,
         null,
         2,
         0);

      update jkpt_msg_ct_temp set DEALTYPE = '1' where msgid = vMsgID;
    end if;

    if vSendOrgID = '0110000' then
      insert into jkpt_msg_calltransfer_detail
        (detailid,
         auditid,
         msgid,
         frequency,
         sendorgid,
         senduserid,
         receiveorgid,
         dealtime,
         startstatus,
         endstatus,
         isreject,
         statusdesc,
         suggestion,
         statusinfo)
      values
        (seq_msg_detail.nextval,
         vAuditID,
         vMsgID,
         0,
         vSendOrgID,
         vCreationUserID,
         vReceiveOrgID,
         vSendTime,
         1,
         1,
         vIsReject,
         '呼叫流转待联网中心监控部响应',
         '',
         '呼叫流转已受理');
      update jkpt_msg_calltransfer_audit a
         set a.remark_2 = 'shouli:0,bohui:1,tongguo:1,chuliwancheng:0,btnPutinRecycle:0,btnReturnProcess:0'
       where a.auditid = vAuditID;
    else
      vIsReject := 0;
      select a.successstatus, a.successdescribe, a.dealsucessdescribe
        into vCurDealStatus, vCurDealDescribe, vDealDescribe
        from jkpt_msg_stepdefine a
       where a.modelname = 'MSG_CALLTRANSFER_BASE'
         and a.sendorggroup = ANY
       (select b.grouptype
                from jkpt_msg_orgrelation b
               where b.sendorgid = vSendOrgID)
         AND A.successreceiveorggroup = ANY
       (select b.grouptype
                from jkpt_msg_orgrelation b
               where b.sendorgid = vReceiveOrgID);

      insert into jkpt_msg_calltransfer_detail
        (detailid,
         auditid,
         msgid,
         frequency,
         sendorgid,
         senduserid,
         receiveorgid,
         dealtime,
         startstatus,
         endstatus,
         isreject,
         statusdesc,
         suggestion,
         statusinfo)
      values
        (seq_msg_detail.nextval,
         vAuditID,
         vMsgID,
         0,
         vSendOrgID,
         NULL,
         vReceiveOrgID,
         vSendTime,
         1,
         vCurDealStatus,
         vIsReject,
         vCurDealDescribe,
         NULL,
         vDealDescribe);

      update jkpt_msg_calltransfer_audit a
         set a.remark_2 = 'shouli:1,bohui:1,tongguo:0,chuliwancheng:2,btnPutinRecycle:0,btnReturnProcess:0'
       where a.auditid = vAuditID;
      --已受理
      if vHandlestatus = '2' then
        insert into jkpt_msg_calltransfer_detail
          (detailid,
           auditid,
           msgid,
           frequency,
           sendorgid,
           senduserid,
           receiveorgid,
           dealtime,
           startstatus,
           endstatus,
           isreject,
           statusdesc,
           suggestion,
           statusinfo)
        values
          (seq_msg_detail.nextval,
           vAuditID,
           vMsgID,
           0,
           vReceiveOrgID,
           NULL,
           vReceiveOrgID,
           vLastReplyTime,
           2,
           3,
           vIsReject,
           '呼叫流转待分中心处理完成',
           vLastReply,
           '已受理');

        update jkpt_msg_calltransfer_base a
           set a.sendorgid = vReceiveOrgID, a.remark_1 = '1'
         where a.msgid = vMsgID;
        update jkpt_msg_calltransfer_audit a
           set a.sendorgid = vReceiveOrgID, a.remark_1 = '1'
         where a.msgid = vMsgID;
        update jkpt_msg_calltransfer_audit a
           set a.remark_2 = 'shouli:2,bohui:2,tongguo:0,chuliwancheng:1,btnPutinRecycle:0,btnReturnProcess:0'
         where a.auditid = vAuditID;
      end if;

    end if;

  END LOOP;
  CLOSE CUR_4;
  --end 已转发 的记录
  commit;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    PRETURNVAL := 0;
    PMSG       := vMsgID || sqlerrm;
END PROC_CallTransfer_Import;
/

