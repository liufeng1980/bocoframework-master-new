create PROCEDURE PROC_tsgl_Addcomplaint(pCaller            in varchar2,
                                                   pTelphone          IN VARCHAR2,
                                                   pPlateNumber       IN VARCHAR2,
                                                   pCardType          IN VARCHAR2,
                                                   pCardNumber        IN VARCHAR2,
                                                   pTagType           IN VARCHAR2,
                                                   pTagNumber         IN VARCHAR2,
                                                   pComplaintType     IN VARCHAR2,
                                                   pComplaintLevel    IN VARCHAR2,
                                                   pComplaintTarget   IN VARCHAR2,
                                                   pEventTime         IN VARCHAR2,
                                                   pEventPlace        IN VARCHAR2,
                                                   pIsCashPayment     IN VARCHAR2,
                                                   pEventDescribe     IN varchar2,
                                                   pUserAppeal        IN varchar2,
                                                   pCreationOrgID     IN VARCHAR2,
                                                   pCreationUserID    IN VARCHAR2,
                                                   pEtcBillNo         IN VARCHAR2,
                                                   pEtcAcceptTime     IN VARCHAR2,
                                                   pEtcAcceptCount    IN NUMBER,
                                                   pEtcAgency         IN VARCHAR2,
                                                   pEtcAcceptUser     IN VARCHAR2,
                                                   pEtcUserName       IN VARCHAR2,
                                                   pIdType            IN VARCHAR2,
                                                   pIdNo              IN VARCHAR2,
                                                   pBankName          IN VARCHAR2,
                                                   pBankAccount       IN VARCHAR2,
                                                   pEtcRechargeBillNo IN VARCHAR2,
                                                   pPayType           IN VARCHAR2,
                                                   pEtcEventTime      IN VARCHAR2,
                                                   pCurrentOrgId      in varchar2,
                                                   pAttachmentList    IN varchar2,
                                                   pComplaintId       OUT NUMBER,
                                                   pReturnVal         OUT NUMBER,
                                                   pMsg               OUT varchar2) AS
  vSuccessDescribe   varchar2(100);
  vComplaintID       number;
  vAuditInfoID       number;
  vCurrentID         varchar2(7);
  vComplaintCode     varchar2(20);
  vCount             number;
  vCountAllotorgID   number;
  vCountStepDefine   number;
  vParentType        jkpt_tsgl_complaint.parenttype%type;
  vEventTime         jkpt_tsgl_complaint.eventtime%type;
  vEtcBillNo         jkpt_tsgl_complaint.etcBillNo%type;
  vEtcAcceptTime     jkpt_tsgl_complaint.etcAcceptTime%type;
  vEtcAcceptCount    jkpt_tsgl_complaint.etcAcceptCount%type;
  vEtcAgency         jkpt_tsgl_complaint.etcAgency%type;
  vEtcAcceptUser     jkpt_tsgl_complaint.etcAcceptUser%type;
  vEtcUserName       jkpt_tsgl_complaint.etcUserName%type;
  vIdType            jkpt_tsgl_complaint.idType%type;
  vIdNo              jkpt_tsgl_complaint.idNo%type;
  vBankName          jkpt_tsgl_complaint.bankName%type;
  vBankAccount       jkpt_tsgl_complaint.bankAccount%type;
  vEtcRechargeBillNo jkpt_tsgl_complaint.etcRechargeBillNo%type;
  vPayType           jkpt_tsgl_complaint.payType%type;
  vEtcEventTime      jkpt_tsgl_complaint.EtcEventTime%type;
  vComplaintTarget   jkpt_tsgl_complaint.ComplaintTarget%type;
  vEventPlace        jkpt_tsgl_complaint.EventPlace%type;
  vIsCashPayment     jkpt_tsgl_complaint.IsCashPayment%type;
  vAllotOrgName      jkpt_base_org.orgname%type;
  vCurOrgGroupType   jkpt_tsgl_orgrelation.grouptype%type;
BEGIN
  pReturnVal := 1;
  pMSG       := '';

  --huo qu fu lei xing zi dian
  select a.dicparentid
    into vParentType
    from jkpt_comm_paramdic a
   where a.grouptype = 'ComplaintType'
     and a.dicvalue = pComplaintType;

  --jian cha shi fou pei zhi mo ren jie shou ji gou
  select count(*)
    into vCountAllotorgID
    from jkpt_tsgl_orgrelation a
   where a.orgid = pCreationOrgID
     and a.complaintparenttype = vParentType;

  if (vCountAllotorgID < 1) then
    pReturnVal := -1;
    pMSG       := '没有配置第一次默认接收机构';
    return;
  else
    select grouptype
      into vCurOrgGroupType
      from jkpt_tsgl_orgrelation a
     where a.orgid = pCurrentOrgId
       and a.complaintparenttype = vParentType
       and rownum = 1;
    --待处理机构名称
    select orgname
      into vAllotOrgName
      from jkpt_base_org
     where orgid = pCurrentOrgId;
  end if;

  -- jian cha shi fou pei zhi mo ren zhuang tai
  select count(*)
    into vCountStepDefine
    from JKPT_TSGL_STEPDEFINE a
   where a.passpath = 1
     and a.complaintparenttype = vParentType
     and a.sender = any (select b.grouptype
            from JKPT_TSGL_ORGRELATION b
           where b.orgid = pCreationOrgID
             and a.complaintparenttype = vParentType
             and rownum = 1)
     and a.successreceiver = vCurOrgGroupType;
  if (vCountStepDefine < 1) then
    pReturnVal := -2;
    pMSG       := '没有配置默认状态';
    return;
  else
    select successdescribe
      into vSuccessDescribe
      from JKPT_TSGL_STEPDEFINE a
     where a.passpath = 1
       and a.complaintparenttype = vParentType
       and a.sender = any (select b.grouptype
              from JKPT_TSGL_ORGRELATION b
             where b.orgid = pCreationOrgID
               and a.complaintparenttype = vParentType
               and rownum = 1)
       and a.successreceiver = vCurOrgGroupType;
  end if;

  --start huo qu bian hao
  select LPAD(currentid, 5, '0')
    into vCurrentID
    from jkpt_base_seq
   where upper(tablename) = 'JKPT_TSGL_COMPLAINT'
     for update;

  select count(*)
    into vCount
    from jkpt_tsgl_complaint t
   where t.creationtime > trunc(sysdate, 'yyyy');
  if (vCount > 0) then
    select to_char(sysdate, 'yy') || vCurrentID
      into vComplaintCode　from dual;
    update jkpt_base_seq
       set currentid = currentid + 1
     where upper(tablename) = 'JKPT_TSGL_COMPLAINT';
  else
    select to_char(sysdate, 'yy') || '00001'
      into vComplaintCode　from dual;
    update jkpt_base_seq
       set currentid = 2
     where upper(tablename) = 'JKPT_TSGL_COMPLAINT';
  end if;
  --end huo qu bian hao

  --start bu tong lei xing suo bao han zi du bu tong
  vEtcBillNo         := pEtcBillNo;
  vEtcAcceptCount    := pEtcAcceptCount;
  vEtcAgency         := pEtcAgency;
  vEtcAcceptUser     := pEtcAcceptUser;
  vEtcUserName       := pEtcUserName;
  vIdType            := pIdType;
  vIdNo              := pIdNo;
  vBankName          := pBankName;
  vBankAccount       := pBankAccount;
  vEtcRechargeBillNo := pEtcRechargeBillNo;
  vPayType           := pPayType;
  vComplaintTarget   := pComplaintTarget;
  vEventPlace        := pEventPlace;
  vIsCashPayment     := pIsCashPayment;
  if (pEtcAcceptTime = '' or pEtcAcceptTime is null) then
    vEtcAcceptTime := null;
  else
    vEtcAcceptTime := to_date(pEtcAcceptTime, 'yyyy-MM-dd hh24:mi:ss');
  end if;

  if (vParentType = 1) then
    vEventTime         := to_date(pEventTime, 'yyyy-MM-dd hh24:mi:ss');
    vEtcBillNo         := null;
    vEtcAcceptTime     := null;
    vEtcAcceptCount    := null;
    vEtcAgency         := null;
    vEtcAcceptUser     := null;
    vEtcUserName       := null;
    vIdType            := null;
    vIdNo              := null;
    vBankName          := null;
    vBankAccount       := null;
    vEtcRechargeBillNo := null;
    vPayType           := null;
    vEtcEventTime      := null;
  end if;
  if (vParentType = 2) then
    if (pComplaintType = 201) then
      vEventTime       := to_date(pEtcEventTime, 'yyyy-MM-dd hh24:mi:ss');
      vComplaintTarget := null;
      vEventPlace      := null;
      vIsCashPayment   := null;
      vEtcEventTime    := to_date(pEtcEventTime, 'yyyy-MM-dd hh24:mi:ss');
    else
      vEventTime         := to_date(pEtcEventTime, 'yyyy-MM-dd hh24:mi:ss');
      vEtcUserName       := null;
      vIdType            := null;
      vIdNo              := null;
      vBankName          := null;
      vBankAccount       := null;
      vEtcRechargeBillNo := null;
      vPayType           := null;
      vComplaintTarget   := null;
      vEventPlace        := null;
      vIsCashPayment     := null;
      vEtcEventTime      := to_date(pEtcEventTime, 'yyyy-MM-dd hh24:mi:ss');
    end if;
  end if;
  --end bu tong lei xing suo bao han zi du bu tong

  --cha ru tou su ji ben xin xi
  select SEQ_TSGL_COMPLAINT_ID.Nextval into vComplaintID from dual;
  insert into jkpt_tsgl_complaint
    (pkid,
     caller,
     telephone,
     platenumber,
     cardtype,
     cardnumber,
     tagtype,
     tagnumber,
     complainttype,
     complaintlevel,
     complainttarget,
     eventtime,
     eventplace,
     iscashpayment,
     eventdescribe,
     userappeal,
     isarchive,
     isrecyclebin,
     currentorgid,
     creationorgid,
     creationuserid,
     complaintcode,
     parenttype,
     EtcBillNo,
     EtcAcceptTime,
     EtcAcceptCount,
     EtcAgency,
     EtcAcceptUser,
     EtcUserName,
     IdType,
     IdNo,
     bankName,
     BankAccount,
     EtcRechargeBillNo,
     PayType,
     EtcEventTime)
  values
    (vComplaintID,
     pCaller,
     pTelphone,
     upper(pPlateNumber),
     pCardType,
     pCardNumber,
     pTagType,
     pTagNumber,
     pComplaintType,
     pComplaintLevel,
     vComplaintTarget,
     vEventTime,
     vEventPlace,
     vIsCashPayment,
     pEventDescribe,
     pUserAppeal,
     0,
     0,
     pCurrentOrgId,
     pCreationOrgID,
     pCreationUserID,
     vComplaintCode,
     vParentType,
     vEtcBillNo,
     vEtcAcceptTime,
     vEtcAcceptCount,
     vEtcAgency,
     vEtcAcceptUser,
     vEtcUserName,
     vIdType,
     vIdNo,
     vBankName,
     vBankAccount,
     vEtcRechargeBillNo,
     vPayType,
     vEtcEventTime);

  --cha ru tou su ci shu biao
  select SEQ_TSGL_AUDITINFO_ID.Nextval into vAuditInfoID from dual;
  insert into JKPT_TSGL_AUDITINFO
    (fkid,
     sendorgid,
     pkid,
     isreject,
     receiveorgid,
     passpath,
     senduserid,
     CURRENTSTATUSDESC)
  values
    (vComplaintID,
     pCreationOrgID,
     vAuditInfoID,
     0,
     pCurrentOrgId,
     1,
     pCreationUserID,
     '投诉待' || vAllotOrgName || '响应');

  --cha ru liu cheng biao
  insert into JKPT_TSGL_AUDITDETAIL
    (fkid,
     pkid,
     complaintid,
     statusinfo,
     senduserid,
     passpath,
     receiveorgid,
     status,
     sendorgid,
     isreject,
     isshow,
     receiveuserid)
  values
    (vAuditInfoID,
     SEQ_TSGL_AUDITDETAIL_ID.Nextval,
     vComplaintID,
     '投诉已受理',
     pCreationUserID,
     1,
     pCreationOrgID,
     0,
     pCreationOrgID,
     0,
     0,
     pCreationUserID);
  insert into JKPT_TSGL_AUDITDETAIL
    (fkid,
     pkid,
     complaintid,
     statusinfo,
     senduserid,
     passpath,
     receiveorgid,
     status,
     sendorgid,
     isreject,
     isshow)
  values
    (vAuditInfoID,
     SEQ_TSGL_AUDITDETAIL_ID.Nextval,
     vComplaintID,
     vSuccessDescribe,
     pCreationUserID,
     1,
     pCurrentOrgId,
     1,
     pCreationOrgID,
     0,
     0);

  --将发送机构和接收机构添加到接收机构列表中
  insert into jkpt_tsgl_receiveorg(id,flowid,orgid) values (seq_tsgl_receiveorg.nextval,vComplaintID, pCurrentOrgId);
  insert into jkpt_tsgl_receiveorg(id,flowid,orgid) values (seq_tsgl_receiveorg.nextval,vComplaintID, pCreationOrgID);

  insert into JKPT_BASE_ATTACHMENT
    (ATTACHMENTID,
     headid,
     type,
     oldname,
     newname,
     filepath,
     grouptype,
     filetype,
     remark_1,
     remark_2,
     creationorgid,
     creationuserid)
    select SEQ_BASE_ATTZCHMENTID.nextval,
           vAuditInfoID,
           6,
           t.oldname,
           t.newname,
           t.filepath,
           'ComplaintFileType',
           t.filetype,
           1,
           1,
           pCreationOrgID,
           pCreationUserID
      from table(fun_Split_Attachment(pAttachmentList)) t;
  pComplaintId := vComplaintID;
  commit;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    PRETURNVAL := 0;
    PMSG       := '执行失败:' + sqlerrm;
END PROC_tsgl_Addcomplaint;
/

