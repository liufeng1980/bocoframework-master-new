create PROCEDURE PROC_TSGL_FLOWAUDIT(PJSDEALTYPE    IN VARCHAR2,
                                                PJSDEALSTATUS  IN VARCHAR2,
                                                PRECEIVEUSERID IN VARCHAR2,
                                                PRECEIVEORGID  IN VARCHAR2,
                                                PSUGGESTION    IN VARCHAR2,
                                                PFKID          IN VARCHAR2, --jkpt_tsgl_auditinfo表主键
                                                PSUBMITTYPE    IN VARCHAR2,
                                                PREMARK_6      IN NUMBER,
                                                PRETURNVAL     OUT NUMBER,
                                                PMSG           OUT VARCHAR2) AS
  VAUDITINFO_PKID       NUMBER; --jkpt_tsgl_auditinfo表主键（新序列号）
  VCOMPLAINT_PKID       NUMBER; --JKPT_TSGL_COMPLAINT表主键
  VFREQUENCY            NUMBER; --不满意次数，从0依次递增
  VMAXFREQUENCY         NUMBER;
  VSENDORGID            VARCHAR2(20);
  VPASSPATH             VARCHAR2(1);
  VTOPASSPATH           VARCHAR2(1);
  VSENDSTATUS           NUMBER;
  VSENDUSERID           VARCHAR2(20);
  VPKID_MAX_AD          NUMBER; --JKPT_TSGL_AUDITDETAIL表主键
  VRECEIVEORGID         VARCHAR2(20); --接收机构
  VREMARK_1             VARCHAR2(10); --1-分中心已受理
  VSUGGESTION           VARCHAR2(50); --发送方处理意见及要求
  VCURDEALSTATUS        NUMBER; --获取当前流转状态
  VCURDEALDESCRIBE      VARCHAR2(100); --获取当前流转描述
  VDEALDESCRIBE         VARCHAR2(100); --审核通过描述信息
  VCOUNT                NUMBER; --行数
  v_Remark_6            NUMBER;
  vDetailNewStatus      number; --处理后想JKPT_TSGL_AUDITDETAIL.newstatus
  vCreationOrgId        VARCHAR2(20); --投诉创建机构
  vCreationOrgGroupType VARCHAR2(20); --投诉创建GroupType
  vParentType           VARCHAR2(20); --投诉父类型
BEGIN
  --获取投诉审核当前最新信息
  SELECT A.FKID,
         A.FREQUENCY,
         A.RECEIVEORGID,
         A.PASSPATH,
         A.CURRENTSTATUS,
         A.SENDUSERID,
         A.REMARK_1,
         A.REMARK_6
    INTO VCOMPLAINT_PKID,
         VFREQUENCY,
         VSENDORGID,
         VPASSPATH,
         VSENDSTATUS,
         VSENDUSERID,
         VREMARK_1,
         v_Remark_6
    FROM JKPT_TSGL_AUDITINFO A
   WHERE A.PKID = PFKID
     AND A.ISCURRENT = '1';

  --判断是否重复提交
  if PREMARK_6 <> v_Remark_6 then
    PRETURNVAL := 0;
    select '该 ' || fun_get_dicname('ComplaintType', a.complainttype) ||
           ' 已被 ' || c.username || ' 处理完成'
      into PMSG
      from JKPT_TSGL_COMPLAINT a, JKPT_TSGL_AUDITINFO b, jkpt_base_user c
     where a.pkid = b.fkid
       and b.pkid = PFKID
       and b.senduserid = c.loginid;
    return;
  end if;

  --每次修改变量+1，控制重复提交
  update JKPT_TSGL_AUDITINFO a
     set a.remark_6 = nvl(a.remark_6, 1) + 1
   where pkid = PFKID;

  --获取投诉历史最新记录主键
  SELECT MAX(A.PKID)
    INTO VPKID_MAX_AD
    FROM JKPT_TSGL_AUDITDETAIL A
   WHERE A.FKID = PFKID;

  --获取投诉创建机构id及创建机构GroupType和投诉父类型
  select a.creationorgid, a.parenttype
    into vCreationOrgId, vParentType
    from jkpt_tsgl_complaint a
   where a.pkid = VCOMPLAINT_PKID;
  select o.grouptype
    into vCreationOrgGroupType
    from jkpt_tsgl_orgrelation o
   where o.orgid = vCreationOrgId
     and o.complaintparenttype = vParentType
     and rownum = 1;

  --start 如果是投诉的创建机构
  IF PJSDEALTYPE = vCreationOrgGroupType THEN
    --处理意见及要求
    IF PSUBMITTYPE = '1' THEN
      --用户满意
      VSUGGESTION := '投诉完成，用户满意';
    ELSIF PSUBMITTYPE = '2' THEN
      --用户认可
      VSUGGESTION := '投诉完成，用户认可';
    ELSIF PSUBMITTYPE = '3' THEN
      --用户不满意
      VSUGGESTION := '用户未完成，用户不满意';
    ELSIF PSUBMITTYPE = '4' THEN
      --放入回收站
      VSUGGESTION := '无效投诉';
    END IF;

    --满意或认可，则完结投诉(并将处理结果保存到主表，
    --此时JKPT_TSGL_AUDITINFO的CURRENTSUGGESTION其实就是到发起机构前的最后一条处理意见)
    IF PSUBMITTYPE = '1' OR PSUBMITTYPE = '2' THEN
      UPDATE JKPT_TSGL_COMPLAINT A
         SET ARCHIVETIME       = SYSDATE,
             ISARCHIVE         = '1',
             USEDDAYS          = FUNC_BASE_GETDAYS(A.CREATIONTIME, SYSDATE),
             CURRENTORGID      = VSENDORGID,
             DEALRESULT        = PSUBMITTYPE,
             DEALRESULTCONTENT =
             (select CURRENTSUGGESTION
                from JKPT_TSGL_AUDITINFO
               WHERE PKID = PFKID)
       WHERE PKID = VCOMPLAINT_PKID;

      UPDATE JKPT_TSGL_AUDITINFO A
         SET A.CURRENTSUGGESTION = PSUGGESTION,
             ISARCHIVE           = '1',
             ARCHIVETIME         = SYSDATE,
             CURRENTSTATUS       = 99,
             DEALRESULT          = PSUBMITTYPE,
             USEDDAYS            = FUNC_BASE_GETDAYS(A.CREATIONTIME, SYSDATE),
             SENDUSERID          = PRECEIVEUSERID,
             A.SENDORGID         = VSENDORGID,
             CURRENTSTATUSDESC   = VSUGGESTION
       WHERE PKID = PFKID;
      --回访不满意
    ELSIF PSUBMITTYPE = '3' THEN
      --VFREQUENCY从0开始，如果投诉流转大于3次，则自动完结
      IF VFREQUENCY >= 2 THEN
        VSUGGESTION := '投诉已被处理3次，自动完结';
        UPDATE JKPT_TSGL_COMPLAINT A
           SET ARCHIVETIME       = SYSDATE,
               ISARCHIVE         = '1',
               USEDDAYS          = FUNC_BASE_GETDAYS(A.CREATIONTIME, SYSDATE),
               CURRENTORGID      = VSENDORGID,
               DEALRESULT        = PSUBMITTYPE,
               DEALRESULTCONTENT =
               (select CURRENTSUGGESTION
                  from JKPT_TSGL_AUDITINFO
                 WHERE PKID = PFKID)
         WHERE PKID = VCOMPLAINT_PKID;

        UPDATE JKPT_TSGL_AUDITINFO A
           SET A.CURRENTSUGGESTION = PSUGGESTION,
               ISARCHIVE           = '1',
               ARCHIVETIME         = SYSDATE,
               CURRENTSTATUS       = 98,
               DEALRESULT          = PSUBMITTYPE,
               USEDDAYS            = FUNC_BASE_GETDAYS(A.CREATIONTIME,
                                                       SYSDATE),
               SENDUSERID          = PRECEIVEUSERID,
               A.SENDORGID         = VSENDORGID,
               CURRENTSTATUSDESC   = VSUGGESTION
         WHERE PKID = PFKID;

        UPDATE JKPT_TSGL_AUDITDETAIL A
           SET A.DEALTIME      = SYSDATE,
               A.SUGGESTION    = PSUGGESTION,
               A.STATUSINFO    = VSUGGESTION,
               A.RECEIVEUSERID = PRECEIVEUSERID,
               A.NEWSTATUS     = 98
         WHERE PKID = VPKID_MAX_AD;
        COMMIT;
        PRETURNVAL := 1;
        RETURN;
      END IF;
      UPDATE JKPT_TSGL_AUDITINFO A
         SET A.CURRENTSUGGESTION = PSUGGESTION,
             A.ISCURRENT         = '0',
             A.DEALRESULT        = PSUBMITTYPE,
             CURRENTSTATUS       = 98,
             SENDUSERID          = PRECEIVEUSERID,
             ARCHIVETIME         = SYSDATE,
             USEDDAYS            = FUNC_BASE_GETDAYS(A.CREATIONTIME, SYSDATE),
             CURRENTSTATUSDESC   = VSUGGESTION
       WHERE PKID = PFKID;

      SELECT SEQ_TSGL_AUDITINFO_ID.NEXTVAL INTO VAUDITINFO_PKID FROM DUAL;

      SELECT MAX(A.FREQUENCY) + 1
        INTO VMAXFREQUENCY
        FROM JKPT_TSGL_AUDITINFO A
       WHERE A.FKID = VCOMPLAINT_PKID;

      /*SELECT ALLOTORGID
       INTO VRECEIVEORGID
       FROM JKPT_TSGL_ORGRELATION A
      WHERE A.GROUPTYPE = PJSDEALTYPE
        and a.complaintparenttype = vParentType
        AND ROWNUM = 1;*/

      select a.sendorgid
        INTO VRECEIVEORGID
        from jkpt_tsgl_auditdetail a
       where pkid = VPKID_MAX_AD;

      --判断流程状态及描述
      SELECT A.SUCCESSSTATUS, A.SUCCESSDESCRIBE
        INTO VCURDEALSTATUS, VCURDEALDESCRIBE
        FROM JKPT_TSGL_STEPDEFINE A
       WHERE A.SENDER = ANY (SELECT B.GROUPTYPE
                FROM JKPT_TSGL_ORGRELATION B
               WHERE B.ORGID = VSENDORGID
                 and b.complaintparenttype = vParentType)
         AND A.SUCCESSRECEIVER = ANY
       (SELECT B.GROUPTYPE
                FROM JKPT_TSGL_ORGRELATION B
               WHERE B.ORGID = VRECEIVEORGID
                 and B.complaintparenttype = vParentType)
         AND A.COMPLAINTPARENTTYPE = vParentType;

      --添加投诉次数表
      INSERT INTO JKPT_TSGL_AUDITINFO
        (FKID, FREQUENCY, SENDORGID, PKID, RECEIVEORGID, SENDUSERID)
      VALUES
        (VCOMPLAINT_PKID,
         VMAXFREQUENCY,
         VSENDORGID,
         VAUDITINFO_PKID,
         VRECEIVEORGID,
         PRECEIVEUSERID);

      --创建投诉历史表
      INSERT INTO JKPT_TSGL_AUDITDETAIL
        (FKID,
         PKID,
         COMPLAINTID,
         FREQUENCY,
         STATUSINFO,
         SENDUSERID,
         PASSPATH,
         RECEIVEORGID,
         STATUS,
         SENDORGID,
         ISREJECT,
         ISSHOW,
         RECEIVEUSERID)
      VALUES
        (VAUDITINFO_PKID,
         SEQ_TSGL_AUDITDETAIL_ID.NEXTVAL,
         VCOMPLAINT_PKID,
         VMAXFREQUENCY,
         '投诉已受理',
         PRECEIVEUSERID,
         1,
         VSENDORGID,
         0,
         VSENDORGID,
         0,
         0,
         PRECEIVEUSERID);

      INSERT INTO JKPT_TSGL_AUDITDETAIL
        (FKID,
         PKID,
         COMPLAINTID,
         FREQUENCY,
         STATUSINFO,
         SENDUSERID,
         PASSPATH,
         RECEIVEORGID,
         STATUS,
         SENDORGID,
         ISREJECT,
         ISSHOW)
      VALUES
        (VAUDITINFO_PKID,
         SEQ_TSGL_AUDITDETAIL_ID.NEXTVAL,
         VCOMPLAINT_PKID,
         VMAXFREQUENCY,
         VCURDEALDESCRIBE,
         PRECEIVEUSERID,
         1,
         VRECEIVEORGID,
         VCURDEALSTATUS,
         VSENDORGID,
         0,
         0);

      --修改等处理机构编码
      UPDATE JKPT_TSGL_COMPLAINT A
         SET A.CURRENTORGID = VRECEIVEORGID
       WHERE A.PKID = VCOMPLAINT_PKID;

      --判断是否存在附件
      SELECT COUNT(1)
        INTO VCOUNT
        FROM JKPT_BASE_ATTACHMENT A
       WHERE A.TYPE = 6
         AND A.HEADID = PFKID;

      --存在附件，添加附件到新投诉流程中
      IF VCOUNT > 0 THEN
        INSERT INTO JKPT_BASE_ATTACHMENT
          (ATTACHMENTID,
           HEADID,
           TYPE,
           OLDNAME,
           NEWNAME,
           FILEPATH,
           UPLOADTIME,
           FILESIZE,
           REMARK_2,
           REMARK_1,
           GROUPTYPE,
           FILETYPE,
           CREATIONORGID,
           CREATIONUSERID)
          SELECT SEQ_BASE_ATTZCHMENTID.NEXTVAL,
                 VAUDITINFO_PKID,
                 A.TYPE,
                 A.OLDNAME,
                 B.NEWFILENAME NEWNAME,
                 REPLACE(A.FILEPATH, A.NEWNAME, B.NEWFILENAME) FILEPATH,
                 SYSDATE,
                 A.FILESIZE,
                 A.REMARK_1,
                 A.REMARK_2,
                 A.GROUPTYPE,
                 A.FILETYPE,
                 A.CREATIONORGID,
                 A.CREATIONUSERID
            FROM JKPT_BASE_ATTACHMENT A,
                 (select A.ATTACHMENTID,
                         substr(A.NEWNAME, 0, instr(A.NEWNAME, '.', -1) - 1) || '_1' ||
                         substr(A.NEWNAME, instr(A.NEWNAME, '.', -1)) NEWFILENAME
                    from JKPT_BASE_ATTACHMENT A
                   WHERE A.HEADID = PFKID
                     AND A.TYPE = 6) B
           WHERE A.ATTACHMENTID = B.ATTACHMENTID;
      END IF;
      --放入回收站
    ELSIF PSUBMITTYPE = '4' THEN
      UPDATE JKPT_TSGL_COMPLAINT A
         SET RECYCLEBINTIME = SYSDATE,
             ISRECYCLEBIN   = '1',
             USEDDAYS       = FUNC_BASE_GETDAYS(A.CREATIONTIME, SYSDATE)
       WHERE PKID = VCOMPLAINT_PKID;

      UPDATE JKPT_TSGL_AUDITINFO A
         SET A.CURRENTSUGGESTION = PSUGGESTION,
             ISRECYCLEBIN        = '1',
             RECYCLEBINTIME      = SYSDATE,
             CURRENTSTATUS       = 99,
             USEDDAYS            = FUNC_BASE_GETDAYS(A.CREATIONTIME, SYSDATE),
             SENDUSERID          = PRECEIVEUSERID,
             SENDORGID           = VSENDORGID,
             CURRENTSTATUSDESC   = VSUGGESTION
       WHERE PKID = PFKID;

    END IF;

    IF PSUBMITTYPE = '1' OR PSUBMITTYPE = '2' or PSUBMITTYPE = '4' THEN
      vDetailNewStatus := 99;
    ELSIF PSUBMITTYPE = '3' THEN
      vDetailNewStatus := 98;
    END IF;
    UPDATE JKPT_TSGL_AUDITDETAIL A
       SET A.DEALTIME      = SYSDATE,
           A.SUGGESTION    = PSUGGESTION,
           A.STATUSINFO    = VSUGGESTION,
           A.RECEIVEUSERID = PRECEIVEUSERID,
           A.NEWSTATUS     = vDetailNewStatus
     WHERE PKID = VPKID_MAX_AD;

    COMMIT;
    PRETURNVAL := 1;
    RETURN;
  END IF;
  --end 如果是投诉的创建机构

  --start 获取接收机构
  IF PJSDEALTYPE = 'OperationDept' OR PJSDEALTYPE = 'MonitorDept' OR
     PJSDEALTYPE = 'GaoLuHearCenter' THEN
    IF VPASSPATH = '1' THEN
      --通过
      IF PSUBMITTYPE = '1' THEN
        VRECEIVEORGID := PRECEIVEORGID;
        --处理完成
      ELSIF PSUBMITTYPE = '5' THEN
        --呼叫中心->运营科，运营科直接处理完成，呼叫中心回访
        VRECEIVEORGID := '0110000';
      ELSE
        SELECT B.SENDORGID
          INTO VRECEIVEORGID
          FROM JKPT_TSGL_AUDITDETAIL B
         WHERE B.PKID = (SELECT MAX(PKID)
                           FROM JKPT_TSGL_AUDITDETAIL A
                          WHERE A.FKID = PFKID
                            AND A.RECEIVEORGID = VSENDORGID
                            AND A.ISREJECT <> '1'
                            AND A.PASSPATH = 1);
      END IF;
    ELSE
      IF PSUBMITTYPE = '1' THEN
        SELECT B.SENDORGID
          INTO VRECEIVEORGID
          FROM JKPT_TSGL_AUDITDETAIL B
         WHERE B.PKID = (SELECT MAX(PKID)
                           FROM JKPT_TSGL_AUDITDETAIL A
                          WHERE A.FKID = PFKID
                            AND A.RECEIVEORGID = VSENDORGID
                            AND A.PASSPATH <> VPASSPATH
                            AND A.ISREJECT <> '1');
      ELSE
        SELECT B.SENDORGID
          INTO VRECEIVEORGID
          FROM JKPT_TSGL_AUDITDETAIL B
         WHERE B.PKID = (SELECT MAX(PKID)
                           FROM JKPT_TSGL_AUDITDETAIL A
                          WHERE A.FKID = PFKID
                            AND A.RECEIVEORGID = VSENDORGID
                            AND A.ISREJECT <> '1');
      END IF;
    END IF;
  ELSIF PJSDEALTYPE = 'SubCenter' or PJSDEALTYPE = 'ETCDept' THEN
    IF PSUBMITTYPE = '2' THEN
      SELECT B.SENDORGID
        INTO VRECEIVEORGID
        FROM JKPT_TSGL_AUDITDETAIL B
       WHERE B.PKID = (SELECT MAX(PKID)
                         FROM JKPT_TSGL_AUDITDETAIL A
                        WHERE A.FKID = PFKID
                          AND A.RECEIVEORGID = VSENDORGID
                          AND A.RECEIVEORGID <> A.SENDORGID
                          AND A.ISREJECT <> '1');
    ELSE
      IF VREMARK_1 = '1' THEN
        --已受理
        SELECT B.SENDORGID
          INTO VRECEIVEORGID
          FROM JKPT_TSGL_AUDITDETAIL B
         WHERE B.PKID = (SELECT MAX(PKID)
                           FROM JKPT_TSGL_AUDITDETAIL A
                          WHERE A.FKID = PFKID
                            AND A.SENDORGID <> VSENDORGID
                            AND A.ISREJECT <> '1');
      ELSE
        --受理
        SELECT A.ALLOTORGID
          INTO VRECEIVEORGID
          FROM JKPT_TSGL_ORGRELATION A
         WHERE A.GROUPTYPE = PJSDEALTYPE
           AND A.ORGID = VSENDORGID
           AND A.complaintparenttype = vParentType
           and rownum = 1;
      END IF;
    END IF;
  END IF;
  --end 获取接收机构

  --start 获取状态
  IF PJSDEALTYPE = 'SubCenter' or PJSDEALTYPE = 'ETCDept' THEN
    --受理，处理完成
    IF PSUBMITTYPE = '1' OR PSUBMITTYPE = '3' THEN
      SELECT A.SUCCESSSTATUS,
             A.SUCCESSDESCRIBE,
             DEALSUCESSDESCRIBE,
             PASSPATH
        INTO VCURDEALSTATUS, VCURDEALDESCRIBE, VDEALDESCRIBE, VTOPASSPATH
        FROM JKPT_TSGL_STEPDEFINE A
       WHERE A.SENDER = ANY (SELECT B.GROUPTYPE
                FROM JKPT_TSGL_ORGRELATION B
               WHERE B.ORGID = VSENDORGID
                 AND B.complaintparenttype = vParentType)
         AND A.SUCCESSRECEIVER = ANY
       (SELECT B.GROUPTYPE
                FROM JKPT_TSGL_ORGRELATION B
               WHERE B.ORGID = VRECEIVEORGID
                 AND B.complaintparenttype = vParentType)
         AND A.COMPLAINTPARENTTYPE = vParentType;
    ELSE
      SELECT A.REJECTSTATUS, A.REJECTDESCRIBE, DEALREJECTDESCRIBE, PASSPATH
        INTO VCURDEALSTATUS, VCURDEALDESCRIBE, VDEALDESCRIBE, VTOPASSPATH
        FROM JKPT_TSGL_STEPDEFINE A
       WHERE A.SENDER = ANY (SELECT B.GROUPTYPE
                FROM JKPT_TSGL_ORGRELATION B
               WHERE B.ORGID = VRECEIVEORGID
                 AND B.complaintparenttype = vParentType)
         AND A.SUCCESSRECEIVER = ANY
       (SELECT B.GROUPTYPE
                FROM JKPT_TSGL_ORGRELATION B
               WHERE B.ORGID = VSENDORGID
                 AND B.complaintparenttype = vParentType)
         AND A.COMPLAINTPARENTTYPE = vParentType;
    END IF;
  ELSE
    IF VPASSPATH = '1' THEN
      IF PSUBMITTYPE = '1' OR PSUBMITTYPE = '5' THEN
        SELECT A.SUCCESSSTATUS,
               A.SUCCESSDESCRIBE,
               DEALSUCESSDESCRIBE,
               PASSPATH
          INTO VCURDEALSTATUS, VCURDEALDESCRIBE, VDEALDESCRIBE, VTOPASSPATH
          FROM JKPT_TSGL_STEPDEFINE A
         WHERE A.SENDER = ANY (SELECT B.GROUPTYPE
                  FROM JKPT_TSGL_ORGRELATION B
                 WHERE B.ORGID = VSENDORGID
                   AND B.complaintparenttype = vParentType)
           AND A.PASSPATH = VPASSPATH
           AND A.SUCCESSRECEIVER = ANY
         (SELECT B.GROUPTYPE
                  FROM JKPT_TSGL_ORGRELATION B
                 WHERE B.ORGID = VRECEIVEORGID
                   AND B.complaintparenttype = vParentType)
           AND A.COMPLAINTPARENTTYPE = vParentType;
      ELSE
        SELECT A.REJECTSTATUS,
               A.REJECTDESCRIBE,
               DEALREJECTDESCRIBE,
               PASSPATH
          INTO VCURDEALSTATUS, VCURDEALDESCRIBE, VDEALDESCRIBE, VTOPASSPATH
          FROM JKPT_TSGL_STEPDEFINE A
         WHERE A.SENDER = ANY (SELECT B.GROUPTYPE
                  FROM JKPT_TSGL_ORGRELATION B
                 WHERE B.ORGID = VRECEIVEORGID
                   AND B.complaintparenttype = vParentType)
           AND A.PASSPATH = VPASSPATH
           AND A.SUCCESSRECEIVER = ANY
         (SELECT B.GROUPTYPE
                  FROM JKPT_TSGL_ORGRELATION B
                 WHERE B.ORGID = VSENDORGID
                   AND B.complaintparenttype = vParentType)
           AND A.COMPLAINTPARENTTYPE = vParentType;
      END IF;
    ELSE
      IF PSUBMITTYPE = '1' THEN
        SELECT A.SUCCESSSTATUS,
               A.SUCCESSDESCRIBE,
               DEALSUCESSDESCRIBE,
               PASSPATH
          INTO VCURDEALSTATUS, VCURDEALDESCRIBE, VDEALDESCRIBE, VTOPASSPATH
          FROM JKPT_TSGL_STEPDEFINE A
         WHERE A.SENDER = ANY (SELECT B.GROUPTYPE
                  FROM JKPT_TSGL_ORGRELATION B
                 WHERE B.ORGID = VSENDORGID
                   AND B.complaintparenttype = vParentType)
           AND A.SUCCESSRECEIVER = ANY
         (SELECT B.GROUPTYPE
                  FROM JKPT_TSGL_ORGRELATION B
                 WHERE B.ORGID = VRECEIVEORGID
                   AND B.complaintparenttype = vParentType)
           AND A.COMPLAINTPARENTTYPE = vParentType
           AND ROWNUM = 1;
      ELSE
        SELECT A.REJECTSTATUS,
               A.REJECTDESCRIBE,
               DEALREJECTDESCRIBE,
               PASSPATH
          INTO VCURDEALSTATUS, VCURDEALDESCRIBE, VDEALDESCRIBE, VTOPASSPATH
          FROM JKPT_TSGL_STEPDEFINE A
         WHERE A.SENDER = ANY (SELECT B.GROUPTYPE
                  FROM JKPT_TSGL_ORGRELATION B
                 WHERE B.ORGID = VRECEIVEORGID
                   AND B.complaintparenttype = vParentType)
           AND A.SUCCESSRECEIVER = ANY
         (SELECT B.GROUPTYPE
                  FROM JKPT_TSGL_ORGRELATION B
                 WHERE B.ORGID = VSENDORGID
                   AND B.complaintparenttype = vParentType)
           AND A.COMPLAINTPARENTTYPE = vParentType
           AND ROWNUM = 1;
      END IF;
    END IF;
  END IF;
  --end 获取状态

  --被驳回处理
  IF PSUBMITTYPE = '2' THEN
    UPDATE JKPT_TSGL_AUDITDETAIL A
       SET A.DEALTIME      = SYSDATE,
           A.STATUSINFO    = VDEALDESCRIBE,
           A.SUGGESTION    = PSUGGESTION,
           A.RECEIVEUSERID = PRECEIVEUSERID,
           A.NEWSTATUS     = VCURDEALSTATUS,
           A.RECEIVEORGID  = VSENDORGID,
           A.ISREJECT      = '1'
     WHERE PKID = VPKID_MAX_AD;
  ELSE
    UPDATE JKPT_TSGL_AUDITDETAIL A
       SET A.DEALTIME      = SYSDATE,
           A.STATUSINFO    = VDEALDESCRIBE,
           A.SUGGESTION    = PSUGGESTION,
           A.RECEIVEUSERID = PRECEIVEUSERID,
           A.NEWSTATUS     = VCURDEALSTATUS,
           A.RECEIVEORGID  = VSENDORGID
     WHERE PKID = VPKID_MAX_AD;
  END IF;

  --被驳回处理
  IF PSUBMITTYPE = '2' THEN
    INSERT INTO JKPT_TSGL_AUDITDETAIL
      (FKID,
       STATUSINFO,
       SENDUSERID,
       DEALTIME,
       PASSPATH,
       PKID,
       STATUS,
       SENDORGID,
       RECEIVEORGID,
       FREQUENCY,
       COMPLAINTID,
       ISREJECT)
    VALUES
      (PFKID,
       VCURDEALDESCRIBE,
       PRECEIVEUSERID,
       SYSDATE,
       VTOPASSPATH,
       SEQ_TSGL_AUDITDETAIL_ID.NEXTVAL,
       VCURDEALSTATUS,
       VSENDORGID,
       VRECEIVEORGID,
       VFREQUENCY,
       VCOMPLAINT_PKID,
       '1');

    UPDATE JKPT_TSGL_AUDITINFO A
       SET A.CURRENTSTATUS     = VCURDEALSTATUS,
           A.CURRENTSUGGESTION = PSUGGESTION,
           A.SENDORGID         = VSENDORGID,
           A.SENDUSERID        = PRECEIVEUSERID,
           A.RECEIVEORGID      = VRECEIVEORGID,
           A.PASSPATH          = VTOPASSPATH,
           A.ISREJECT          = '1',
           A.CURRENTSTATUSDESC = VCURDEALDESCRIBE
     WHERE PKID = PFKID;
  ELSE
    INSERT INTO JKPT_TSGL_AUDITDETAIL
      (FKID,
       STATUSINFO,
       SENDUSERID,
       DEALTIME,
       PASSPATH,
       PKID,
       STATUS,
       SENDORGID,
       RECEIVEORGID,
       FREQUENCY,
       COMPLAINTID)
    VALUES
      (PFKID,
       VCURDEALDESCRIBE,
       PRECEIVEUSERID,
       SYSDATE,
       VTOPASSPATH,
       SEQ_TSGL_AUDITDETAIL_ID.NEXTVAL,
       VCURDEALSTATUS,
       VSENDORGID,
       VRECEIVEORGID,
       VFREQUENCY,
       VCOMPLAINT_PKID);

    UPDATE JKPT_TSGL_AUDITINFO A
       SET A.CURRENTSTATUS     = VCURDEALSTATUS,
           A.CURRENTSUGGESTION = PSUGGESTION,
           A.SENDORGID         = VSENDORGID,
           A.SENDUSERID        = PRECEIVEUSERID,
           A.RECEIVEORGID      = VRECEIVEORGID,
           A.PASSPATH          = VTOPASSPATH,
           A.ISREJECT          = '0',
           A.CURRENTSTATUSDESC = VCURDEALDESCRIBE
     WHERE PKID = PFKID;
  END IF;

  --分中心受理标识
  IF PSUBMITTYPE = '3' AND
     (PJSDEALTYPE = 'SubCenter' or PJSDEALTYPE = 'ETCDept') THEN
    UPDATE JKPT_TSGL_AUDITINFO A SET A.REMARK_1 = '1' WHERE PKID = PFKID;
    UPDATE JKPT_TSGL_COMPLAINT A
       SET A.Acceptorgid = VSENDORGID, accepttime = sysdate
     WHERE PKID = VCOMPLAINT_PKID;
  END IF;

  --分中心驳回标识
  IF (PSUBMITTYPE = '2' AND
     (PJSDEALTYPE = 'SubCenter' or PJSDEALTYPE = 'ETCDept')) OR
     ((PJSDEALTYPE = 'OperationDept' OR PJSDEALTYPE = 'MonitorDept' OR
     PJSDEALTYPE = 'GaoLuHearCenter') AND PSUBMITTYPE = '2' AND
     VPASSPATH = '2') THEN
    UPDATE JKPT_TSGL_AUDITINFO A SET A.REMARK_1 = NULL WHERE PKID = PFKID;
  END IF;

  --start记录是哪一个机构最后处理完成的
  --分中心，etc管理部处理完成
  if (PSUBMITTYPE = '1' and
     (PJSDEALTYPE = 'SubCenter' or PJSDEALTYPE = 'ETCDept')) then
    UPDATE JKPT_TSGL_COMPLAINT A
       SET A.Dealorgid = VSENDORGID
     WHERE PKID = VCOMPLAINT_PKID;
  end if;
  --运营科处理完成(运营科处理完成即受理完成，需同时记录受理机构id)
  if (PSUBMITTYPE = '5' and PJSDEALTYPE = 'OperationDept' and VPASSPATH = 1) then
    UPDATE JKPT_TSGL_COMPLAINT A
       SET A.Dealorgid   = VSENDORGID,
           a.acceptorgid = VSENDORGID,
           a.accepttime  = sysdate
     WHERE PKID = VCOMPLAINT_PKID;
  end if;
  --end记录是哪一个机构最后处理完成的

  --更新当前待处理机构
  UPDATE JKPT_TSGL_COMPLAINT A
     SET A.CURRENTORGID = VRECEIVEORGID
   WHERE PKID = VCOMPLAINT_PKID;

  --判断是否驳回
  if PSUBMITTYPE = '2' then
    select count(1)
      into VCOUNT
      from jkpt_flow_reject
     where flowtype = 2
       and flowid = VCOMPLAINT_PKID
       and receivedorgid = VRECEIVEORGID;
    if VCOUNT = 0 then
      insert into jkpt_flow_reject
      values
        (2, VCOMPLAINT_PKID, VRECEIVEORGID);
    end if;
  end if;

  --判断接受机构是否存在，如果不存在，则添加
  select count(1)
    into VCOUNT
    from jkpt_tsgl_receiveorg
   where flowid = VCOMPLAINT_PKID
     and orgid = VRECEIVEORGID;
  if VCOUNT = 0 then
    insert into jkpt_tsgl_receiveorg
      (id, flowid, orgid)
    values
      (seq_tsgl_receiveorg.nextval, VCOMPLAINT_PKID, VRECEIVEORGID);
  end if;

  COMMIT;
  PRETURNVAL := 1;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    PRETURNVAL := 0;
    PMSG       := SQLERRM;
    INSERT INTO JKPT_COMM_LOG
      (LOGID, MAINMODULE, USERID, OPESUMMARIZE, ISEXCEPTION, REMARK1)
    VALUES
      (SEQ_COMM_LOG_ID.NEXTVAL,
       '投诉管理',
       PRECEIVEUSERID,
       PMSG,
       '1',
       '投诉管理审核出现异常');
    COMMIT;
    PMSG := '执行失败';
END PROC_TSGL_FLOWAUDIT;
/

