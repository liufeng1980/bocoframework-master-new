create package PG_JKPT_XXZX_CALLTRANSFER is

  procedure PROC_DoneCallTransfer(pReceiveID    IN number,
                                  pReplyContent in varchar2,
                                  pUserID       in varchar2,
                                  pReturnVal    out number,
                                  pMSG          out varchar2);

  function TransferLog(pMsgID in number) return varchar2;

  --shou li
  procedure PROC_AcceptCallTransfer(pReceiveID    IN number,
                                    pReplyContent in varchar2,
                                    pReturnVal    out number,
                                    pMSG          out varchar2);

  procedure PROC_RejectCallTransfer(pReceiveID    IN number,
                                    pReplyContent in varchar2,
                                    pReturnVal    out number,
                                    pMSG          out varchar2);

  --zhuan fa
  procedure PROC_ForwardCallTransfer(pMsgID        IN number,
                                     pReceiveID    in number,
                                     pReplyContent in varchar2,
                                     pForwardOrgID in varchar2,
                                     pReceiveOrgID in varchar2,
                                     pReturnVal    out number,
                                     pMSG          out varchar2);

  procedure PROC_AddCallTransfer(pCreationUserID   IN varchar2,
                                 pContent          in varchar2,
                                 pCreationOrgID    in varchar2,
                                 pCustomerName     in varchar2,
                                 pCustomerMobile   in varchar2,
                                 pRoadID           in varchar2,
                                 pPosition         in varchar2,
                                 pCallTransferType in number,
                                 pPlateNum         in varchar2,
                                 pModel            in varchar2,
                                 pDirection        in varchar2,
                                 pComplaintObject  in varchar2,
                                 pReceiveOrgID     in varchar2,
                                 pReturnVal        out number,
                                 pMSG              out varchar2);

end PG_JKPT_XXZX_CALLTRANSFER;
/

