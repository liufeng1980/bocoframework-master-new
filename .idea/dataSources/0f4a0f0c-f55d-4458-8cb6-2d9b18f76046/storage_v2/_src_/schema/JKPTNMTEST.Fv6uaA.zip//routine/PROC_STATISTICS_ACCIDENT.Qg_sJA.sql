create PROCEDURE PROC_STATISTICS_ACCIDENT(PUSERID    in varchar2,
                                                     PRETURNVAL OUT NUMBER,
                                                     PMSG       OUT varchar2) AS
  CURSOR CUR IS
    SELECT roadid,
           min(stakeid) minstakeid,
           max(stakeid) maxstakeid,
           accidentnum
      FROM (select A.roadid, a.stakeid, sum(a.accidentnum) accidentnum
              from jkpt_tjfx_accident a
             where a.userid = PUSERID
             group by A.roadid, a.stakeid) t
     group by roadid, accidentnum;
  VROADID       VARCHAR2(20);                                 --事件来源
  VSTARTSTAKEID NUMBER;                                       --开始桩号
  VENDSTAKEID   NUMBER;                                       --结束桩号
  VACCIDENTNUM  NUMBER;                                       --事故次数
  I             NUMBER;                                       --循环变量
  VFLAG         NUMBER;                                       --循环标志
  VMINSTAKEID   NUMBER;                                       --桩号范围，起点桩号
  VMAXSTAKEID   NUMBER;                                       --桩号范围，止点桩号
  VCOUNT        NUMBER;                                       --条数
BEGIN
  PRETURNVAL := 1;
  OPEN CUR;
  delete from JKPT_TJFX_ACCIDENTRESULT where USERID = PUSERID;
  LOOP
    FETCH CUR
      INTO VROADID, VSTARTSTAKEID, VENDSTAKEID, VACCIDENTNUM;
    EXIT WHEN CUR%NOTFOUND;
    I     := VSTARTSTAKEID;
    VFLAG := 0;
    LOOP
      SELECT COUNT(1)
        INTO VCOUNT
        FROM (select A.roadid, a.stakeid, sum(a.accidentnum) accidentnum
                from jkpt_tjfx_accident a
               where a.userid = PUSERID
               group by A.roadid, a.stakeid) T
       WHERE ROADID = VROADID
         AND stakeiD = I
         AND accidentnum = VACCIDENTNUM;
      --如果存在，并且标志是0，则设置起点桩号
      IF VCOUNT > 0 and VFLAG = 0 THEN
        VMINSTAKEID := I;
        VFLAG       := VFLAG + 1;
      --如果存在，则标志+1
      ELSIF VCOUNT > 0 THEN
        VFLAG := VFLAG + 1;
      --如果不存在，并且起点桩号>0,则统计+1
      ELSE
        IF VMINSTAKEID > 0 THEN
          VFLAG       := 0;
          VMINSTAKEID := VMINSTAKEID - 1;
          VMAXSTAKEID := I - 1;
          INSERT INTO JKPT_TJFX_ACCIDENTRESULT
            (USERID, ROADID, STARTSTAKEID, ENDSTAKEID, ACCIDENTNUM)
          VALUES
            (PUSERID, VROADID, VMINSTAKEID, VMAXSTAKEID, VACCIDENTNUM);
          VMINSTAKEID := 0;
        END IF;
      END IF;
    
      EXIT WHEN I = VENDSTAKEID;
      I := I + 1;
    END LOOP;
  
    --如果标志>0，说明还存在最后一条记录，则统计+1
    IF VFLAG > 0 THEN
      VMINSTAKEID := VMINSTAKEID - 1;
      VMAXSTAKEID := I;
      INSERT INTO JKPT_TJFX_ACCIDENTRESULT
        (USERID, ROADID, STARTSTAKEID, ENDSTAKEID, ACCIDENTNUM)
      VALUES
        (PUSERID, VROADID, VMINSTAKEID, VMAXSTAKEID, VACCIDENTNUM);
    END IF;
  
  END LOOP;
  CLOSE CUR;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    PRETURNVAL := 0;
    PMSG       := '执行失败';
END PROC_STATISTICS_ACCIDENT;
/

