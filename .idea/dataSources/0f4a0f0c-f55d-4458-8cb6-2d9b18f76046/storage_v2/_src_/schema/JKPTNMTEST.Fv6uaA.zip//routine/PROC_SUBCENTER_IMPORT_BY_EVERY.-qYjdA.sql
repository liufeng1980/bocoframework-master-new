create PROCEDURE PROC_SUBCENTER_IMPORT_BY_EVERY(ID            IN NUMBER,
                                                           TABLENAME     IN VARCHAR2,
                                                           TALBE_TYPE    IN NUMBER,
                                                           MAX_ID        IN NUMBER,
                                                           SUB_CENTER_ID IN NUMBER) IS
  V_SQL_COUNT  VARCHAR2(5000);
  V_SQL        VARCHAR2(10000);
  V_CNT        NUMBER;
  V_PAGE_NUM   NUMBER;
  V_NEW_MAX_ID NUMBER;
  V_MAX_ID     NUMBER;
BEGIN
  /* DBMS_OUTPUT.PUT_LINE('---------导入分中心数据------');
  DBMS_OUTPUT.PUT_LINE(ID);
  DBMS_OUTPUT.PUT_LINE(TABLENAME);
  DBMS_OUTPUT.PUT_LINE(TALBE_TYPE);
  DBMS_OUTPUT.PUT_LINE(MAX_ID);
  DBMS_OUTPUT.PUT_LINE(SUB_CENTER_ID);*/

  V_PAGE_NUM := 500;
  V_MAX_ID   := MAX_ID;

  IF TALBE_TYPE = 1 THEN
    --导入JKPT_CJXT_DEVICEALERT1
    LOOP
      --DBMS_OUTPUT.PUT_LINE('---------检查type == 1有无新数据------');
      V_SQL_COUNT := 'SELECT COUNT(1) FROM ' || TABLENAME ||
                     ' T WHERE T.id > :1';
      EXECUTE IMMEDIATE V_SQL_COUNT
        INTO V_CNT
        USING V_MAX_ID;
      IF V_CNT <= 0 THEN
        --DBMS_OUTPUT.PUT_LINE('无新数据');
        EXIT;
      ELSE
        --DBMS_OUTPUT.PUT_LINE('需要导入新数据 =' || V_CNT);
        V_SQL := 'SELECT MAX(ID)
                 FROM (SELECT ID
                         FROM (SELECT ROWNUM ORDER_ID, T.ID
                                 FROM (SELECT ID
                                         FROM ' ||
                 TABLENAME || ' T
                                        WHERE T.ID > :maxid
                                        ORDER BY ID ASC) T) A
                        WHERE A.ORDER_ID <= :pageSize)';
        EXECUTE IMMEDIATE V_SQL
          INTO V_NEW_MAX_ID
          USING V_MAX_ID, V_PAGE_NUM;

        --删除无效重复数据
        V_SQL := 'DELETE FROM  JKPT_CJXT_DEVICEALERT T WHERE T.SUB_ID > :max_id AND t.SUB_CENTER_ID=:sub_center_id';
        EXECUTE IMMEDIATE V_SQL
          USING V_MAX_ID, SUB_CENTER_ID;

        V_SQL := 'INSERT INTO JKPT_CJXT_DEVICEALERT
              (ORGID,
               DEVICEID,
               ALERTID,
               ALERTDATE,
               SENDFLAG,
               VARIANTFLAG,
               RESTOREDATE,
               ALERTSTATE,
               SUB_ID,
               SUB_CENTER_ID)
              SELECT ORGID,DEVICEID,ALERTID, ALERTDATE, SENDFLAG, VARIANTFLAG, RESTOREDATE, ALERTSTATE, ID, :1 center_id
              FROM ' || TABLENAME ||
                 ' T WHERE T.ID > :1 and T.ID <=:1';
        EXECUTE IMMEDIATE V_SQL
          USING SUB_CENTER_ID, V_MAX_ID, V_NEW_MAX_ID;

        V_SQL := 'UPDATE jkpt_sub_center_import_config c
                   SET
                       import_max_id = :maxid
                 WHERE c.ID = :id';
        EXECUTE IMMEDIATE V_SQL
          USING V_NEW_MAX_ID, ID;
        V_MAX_ID := V_NEW_MAX_ID;
        COMMIT;
      END IF;
    END LOOP;
  ELSE
    --导入jkpt_txxt_issuelog
    LOOP
      --DBMS_OUTPUT.PUT_LINE('---------检查type == 2 jkpt_txxt_issuelog有无新数据------');
      V_SQL_COUNT := 'SELECT COUNT(1) FROM ' || TABLENAME ||
                     ' T WHERE T.id > :1';
      EXECUTE IMMEDIATE V_SQL_COUNT
        INTO V_CNT
        USING V_MAX_ID;
      IF V_CNT <= 0 THEN
        --DBMS_OUTPUT.PUT_LINE('无新数据');
        EXIT;
      ELSE
        --DBMS_OUTPUT.PUT_LINE('需要导入新数据 =' || V_CNT);
        V_SQL := 'SELECT MAX(ID)
                 FROM (SELECT ID
                         FROM (SELECT ROWNUM ORDER_ID, T.ID
                                 FROM (SELECT ID
                                         FROM ' ||
                 TABLENAME || ' T
                                        WHERE T.ID > :maxid
                                        ORDER BY ID ASC) T) A
                        WHERE A.ORDER_ID <= :pageSize)';
        EXECUTE IMMEDIATE V_SQL
          INTO V_NEW_MAX_ID
          USING V_MAX_ID, V_PAGE_NUM;

        --删除无效重复数据
        V_SQL := 'DELETE FROM JKPT_TXXT_ISSUELOG T WHERE T.ID > :max_id  AND  t.SUB_CENTER_ID=:sub_center_id';
        EXECUTE IMMEDIATE V_SQL
          USING V_MAX_ID, SUB_CENTER_ID;

        V_SQL := 'INSERT INTO JKPT_TXXT_ISSUELOG
              (ID,
                 ORGID,
                 DEVICEID,
                 OPERATORID,
                 CONTROLDATE,
                 ISSUEWORDCONTENT,
                 ISSUEINFO,
                 OPERATFLAG,
                 DEVICETYPEID,
                 SUB_CENTER_ID,
                 OPERATORNAME)
              SELECT
                 ID,
                 ORGID,
                 DEVICEID,
                 OPERATORID,
                 CONTROLDATE,
                 ISSUEWORDCONTENT,
                 ISSUEINFO,
                 OPERATFLAG,
                 DEVICETYPEID,
                 :1 center_id,
                 (select USERNAME from JKPT_BASE_USER x where t.OPERATORID=x.loginid) USERNAME
                FROM jkpt_txxt_issuelog@orcl@xlgl t where t.id>:1 and t.id<=:1';
        EXECUTE IMMEDIATE V_SQL
          USING SUB_CENTER_ID, V_MAX_ID, V_NEW_MAX_ID;

        V_SQL := 'UPDATE jkpt_sub_center_import_config c
                   SET
                       import_max_id = :maxid
                 WHERE c.ID = :id';
        EXECUTE IMMEDIATE V_SQL
          USING V_NEW_MAX_ID, ID;
        V_MAX_ID := V_NEW_MAX_ID;
        COMMIT;
      END IF;
    END LOOP;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    rollback;
    DBMS_OUTPUT.PUT_LINE(substr(sqlerrm, 1000));
END PROC_SUBCENTER_IMPORT_BY_EVERY;
/

