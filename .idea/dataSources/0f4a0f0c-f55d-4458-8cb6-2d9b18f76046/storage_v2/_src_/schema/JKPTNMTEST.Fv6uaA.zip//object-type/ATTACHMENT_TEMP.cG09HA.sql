create TYPE "ATTACHMENT_TEMP"                                                                                                                                as object
(
  OldName  varchar2(200),
  NewName  varchar2(200),
  FilePath varchar2(200),
  FileType number
)
/

