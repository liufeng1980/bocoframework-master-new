create PROCEDURE PROC_STATISTICS_EVENT(PUSERID    in varchar2,
                                                  PSTARTDATE in varchar2,
                                                  PENDDATE   in varchar2,
                                                  PROADID    in varchar2,
                                                  PRETURNVAL OUT NUMBER,
                                                  PMSG       OUT varchar2) AS
  CURSOR CUR IS
    SELECT a.ROADID,
           round(A.STARTSTAKEID) STARTSTAKEID,
           round(A.ENDSTAKEID) ENDSTAKEID
      FROM V_ROADEVENT A
     WHERE A.PARENTVALUE = '01' AND A.SUBEVENTID=0
       AND A.RECTIME >= PSTARTDATE
       and A.RECTIME <= PENDDATE;
  VROADID       VARCHAR2(20); --事件来源
  VSTARTSTAKEID NUMBER; --开始桩号
  VENDSTAKEID   NUMBER; --结束桩号
  I             NUMBER; --循环变量
BEGIN
  PRETURNVAL := 1; --返回值：1-成功，0-失败
  delete from JKPT_TJFX_ACCIDENT where USERID = PUSERID; --先删除查询用户生成记录
  OPEN CUR;
  LOOP
    FETCH CUR
      INTO VROADID, VSTARTSTAKEID, VENDSTAKEID;
    EXIT WHEN CUR%NOTFOUND;
    IF PROADID IS NULL THEN
      I := VSTARTSTAKEID + 1;
      LOOP
        INSERT INTO JKPT_TJFX_ACCIDENT
          (USERID, ROADID, STAKEID, ACCIDENTNUM)
        VALUES
          (PUSERID, VROADID, I, 1);
        EXIT WHEN I >= VENDSTAKEID;
        I := I + 1;
      END LOOP;

    ELSE
      IF PROADID = VROADID THEN
        I := VSTARTSTAKEID + 1;
        LOOP
          INSERT INTO JKPT_TJFX_ACCIDENT
            (USERID, ROADID, STAKEID, ACCIDENTNUM)
          VALUES
            (PUSERID, VROADID, I, 1);
          EXIT WHEN I >= VENDSTAKEID;
          I := I + 1;
        END LOOP;
      END IF;
    END IF;
  END LOOP;
  CLOSE CUR;
  COMMIT;
  --调用统计方法，返回事故统计数
  PROC_STATISTICS_ACCIDENT(PUSERID, PRETURNVAL, PMSG);
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    PRETURNVAL := 0;
    PMSG       := '执行失败';
END PROC_STATISTICS_EVENT;
/

