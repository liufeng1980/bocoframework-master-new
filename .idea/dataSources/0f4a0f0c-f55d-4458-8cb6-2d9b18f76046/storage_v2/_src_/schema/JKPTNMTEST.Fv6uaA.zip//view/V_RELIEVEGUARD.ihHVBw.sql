create view V_RELIEVEGUARD as
select A.MANONDUTY, A.LEADER, A.BEGINTIME, A.ENDTIME
  from jkpt_msg_relieveguard A
/

