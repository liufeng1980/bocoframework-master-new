create FUNCTION FUN_tsgl_getstatusdescpart1(pComplaintid in number)
  RETURN VARCHAR2 AS
  RETURNVAL     VARCHAR2(1000) := '';
  mTimes        number;
  mLastDealTime varchar2(20) := '';
BEGIN
  select a.frequency + 1
    into mTimes
    from Jkpt_Tsgl_Auditinfo a
   where a.fkid = pComplaintid
     and a.iscurrent = 1;

  select to_char(max(b.dealtime), 'yyyy-MM-dd hh24:mi:ss')
    into mLastDealTime
    from jkpt_tsgl_auditdetail b
   where b.complaintid = pComplaintid;

  if (mTimes = 1) then
    RETURNVAL := mLastDealTime;
  else
    RETURNVAL := '第' || mTimes || '次处理' || ' ' || mLastDealTime;
  end if;

  return RETURNVAL;
END FUN_tsgl_getstatusdescpart1;
/

