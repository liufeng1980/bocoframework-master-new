create view V_BASEORG as
select A.ORGID,
       A.ORGNAME,
       A.ORGTAG,
       A.ORGMANAGER,
       A.ORGADDRESS,
       A.POSTCODE,
       A.TELEPHONE,
       A.FAX,
       A.MOBLIE,
       A.EMAIL,
       A.STATUS,
       A.REMARK
  from JKPT_BASE_ORG A
/

