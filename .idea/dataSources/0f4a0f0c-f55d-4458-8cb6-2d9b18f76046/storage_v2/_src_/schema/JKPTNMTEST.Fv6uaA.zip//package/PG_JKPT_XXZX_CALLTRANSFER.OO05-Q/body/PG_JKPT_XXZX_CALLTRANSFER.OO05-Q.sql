create package body PG_JKPT_XXZX_CALLTRANSFER is
  --xiu gai ru ku
  procedure PROC_DoneCallTransfer(pReceiveID    IN number,
                                  pReplyContent in varchar2,
                                  pUserID       in varchar2,
                                  pReturnVal    out number,
                                  pMSG          out varchar2) as
    mMsgID                     number;
    mTransferOrgID             varchar2(20);
    mReceiveOrgDoneCount       number; --mei ge ji gou zui hou yi ci shou dao de shu liang
    mReceiveOrgCount           number; --jie shou ji gou shu liang(bu bao han chong fu)
    mHandleStatus              number;
    mReceiveOrgID              varchar2(20);
    mCallTransferTypeDesc      varchar2(20);
    mCallTransferTitle         varchar2(100);
    mCallTransferType          number;
    mCallTransferCreationOrgID varchar2(20);
  begin
    pReturnVal := 1;
    pMSG       := '';
  
    select msgid, handlestatus, ReceiveOrgID
      into mMsgID, mHandleStatus, mReceiveOrgID
      from JKPT_MSG_CALLTRANSFER_RECEIVE
     WHERE RECEIVEID = pReceiveID;
  
    if (mHandleStatus = 3 or mHandleStatus = 4 or mHandleStatus = 5) then
      pReturnVal := 0;
      pMSG       := '处于驳回,转发,处理完成状态下,不能再进行处理完成操作';
    else
      UPDATE JKPT_MSG_CALLTRANSFER_RECEIVE
         SET HANDLESTATUS = 5, replytime = sysdate, reply = pReplyContent
       WHERE RECEIVEID = pReceiveID;
    
      UPDATE JKPT_MSG_CALLTRANSFER_RECEIVE
         SET HANDLESTATUS = 5, replytime = sysdate
       WHERE RECEIVEID = (select min(RECEIVEID)
                            from JKPT_MSG_CALLTRANSFER_RECEIVE
                           where msgid = mMsgID);
    
      update JKPT_MSG_CALLTRANSFER
         set status        = 2,
             archivetime   = sysdate,
             archiveorgid  = mReceiveOrgID,
             archiveuserid = pUserID
       where msgid = mMsgID;
    
      select calltransfertype, title, creationorgid
        into mCallTransferType,
             mCallTransferTitle,
             mCallTransferCreationOrgID
        from jkpt_msg_calltransfer
       where msgid = mMsgID;
    
      select t.dicname
        into mCallTransferTypeDesc
        from jkpt_comm_paramdic t
       where t.grouptype = 'CallTransferType'
         and dicvalue = mCallTransferType;
    
      insert into jkpt_base_msg
        (id,
         title,
         content,
         receiveorgid,
         receiveuserid,
         type,
         sendtype,
         relationid,
         url)
        select seq_base_msgid.nextval,
               mCallTransferTypeDesc||' 处理完成',
               mCallTransferTitle,
               mCallTransferCreationOrgID,
               userid,
               2,
               2,
               mMsgID,
               '/Xxzx/Xxzx/CallTransferDetailPage?msgID=' || mMsgID ||
               '&receiveID=' || pReceiveID||'&type=2'
          from jkpt_base_user
         where orgid = mCallTransferCreationOrgID;
    end if;
  
    commit;
  
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end PROC_DoneCallTransfer;

  function TransferLog(pMsgID in number) return varchar2 is
    mResult varchar2(500);
    cursor c_list is
      select (select orgname from jkpt_base_org where a.sendorgid = orgid) sendorgname,
             (select orgname from jkpt_base_org where a.receiveorgid = orgid) receiveorgname,
             (select dicname
                from jkpt_comm_paramdic
               where grouptype = 'CallHandleStatus'
                 and dicvalue = a.handlestatus) handlestatusdesc
        from jkpt_msg_calltransfer_receive a
       where a.msgid = pMsgID
       order by a.receiveid asc;
  begin
    for c in c_list loop
      mResult := mResult || c.receiveorgname ||
                 ' <span style=''color:blue;''>' || c.handlestatusdesc ||
                 '</span><br>';
    end loop;
    return mResult;
  end;

  --shou li
  procedure PROC_AcceptCallTransfer(pReceiveID    IN number,
                                    pReplyContent in varchar2,
                                    pReturnVal    out number,
                                    pMSG          out varchar2) as
    mHandleStatus number;
  begin
    pReturnVal := 1;
    pMSG       := '';
  
    select handlestatus
      into mHandleStatus
      from JKPT_MSG_CALLTRANSFER_RECEIVE
     where RECEIVEID = pReceiveID;
  
    if (mHandleStatus <> 1) then
      pReturnVal := 0;
      pMSG       := '只有在未受理状态下可以进行受理操作';
    else
      UPDATE JKPT_MSG_CALLTRANSFER_RECEIVE
         SET HANDLESTATUS = 2, replytime = sysdate, reply = pReplyContent
       WHERE RECEIVEID = pReceiveID;
    
      commit;
    end if;
  
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end PROC_AcceptCallTransfer;

  --bo hui
  procedure PROC_RejectCallTransfer(pReceiveID    IN number,
                                    pReplyContent in varchar2,
                                    pReturnVal    out number,
                                    pMSG          out varchar2) as
    mHandleStatus number;
    mMsgID        number;
    mReceiveOrgID varchar2(20);
    mCount        number;
  begin
    pReturnVal := 1;
    pMSG       := '';
  
    select handlestatus, msgid, receiveorgid
      into mHandleStatus, mMsgID, mReceiveOrgID
      from JKPT_MSG_CALLTRANSFER_RECEIVE
     where RECEIVEID = pReceiveID;
  
    IF (mHandleStatus = 3 or mHandleStatus = 5) THEN
      pReturnVal := 0;
      pMSG       := '已经驳回或已处理完成的呼叫流转不能再进行驳回操作';
    ELSIF (mHandleStatus = 4) THEN
      SELECT COUNT(*)
        into mCount
        FROM JKPT_MSG_CALLTRANSFER_RECEIVE
       WHERE sendorgid = mReceiveOrgID
         and msgid = mMsgID
         and handlestatus <> 3;
      if (mCount > 0) then
        pReturnVal := 0;
        pMSG       := '只有转发记录都驳回才可以进行驳回操作';
      else
        UPDATE JKPT_MSG_CALLTRANSFER_RECEIVE
           SET HANDLESTATUS = 3, replytime = sysdate, reply = pReplyContent
         WHERE RECEIVEID = pReceiveID;
      end if;
    ELSE
      UPDATE JKPT_MSG_CALLTRANSFER_RECEIVE
         SET HANDLESTATUS = 3, replytime = sysdate, reply = pReplyContent
       WHERE RECEIVEID = pReceiveID;
    END IF;
  
    commit;
  
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end PROC_RejectCallTransfer;

  --zhuan fa
  procedure PROC_ForwardCallTransfer(pMsgID        IN number,
                                     pReceiveID    in number,
                                     pReplyContent in varchar2,
                                     pForwardOrgID in varchar2,
                                     pReceiveOrgID in varchar2,
                                     pReturnVal    out number,
                                     pMSG          out varchar2) as
    mHandleStatus number;
    mCount        number;
  begin
    insert into proc_log
      (param)
    values
      ('pMsgID=' || pMsgID || ';pReceiveID=' || pReceiveID ||
       ';pReplyContent=' || pReplyContent || ';pForwardOrgID=' ||
       pForwardOrgID || ';pReceiveOrgID=' || pReceiveOrgID);
    pReturnVal := 1;
    pMSG       := '';
  
    select handlestatus
      into mHandleStatus
      from JKPT_MSG_CALLTRANSFER_RECEIVE
     where RECEIVEID = pReceiveID;
  
    IF (mHandleStatus = 3 or mHandleStatus = 5) THEN
      pReturnVal := 0;
      pMSG       := '已经驳回或已处理完成的呼叫流转不能再进行转发操作';
    ELSIF (mHandleStatus = 4) THEN
      SELECT COUNT(*)
        into mCount
        FROM JKPT_MSG_CALLTRANSFER_RECEIVE
       WHERE sendorgid = pForwardOrgID
         and msgid = pMsgID
         and handlestatus <> 3;
      if (mCount > 0) then
        pReturnVal := 0;
        pMSG       := '只有转发记录都被驳回才可以再进行转发操作';
      else
        UPDATE JKPT_MSG_CALLTRANSFER_RECEIVE
           SET HANDLESTATUS = 4, replytime = sysdate, reply = pReplyContent
         WHERE RECEIVEID = pReceiveID;
      
        update JKPT_MSG_CALLTRANSFER t
           set t.status = 1
         where t.msgid = pMsgID;
      
        insert into JKPT_MSG_CALLTRANSFER_RECEIVE
          (MSGID,
           RECEIVEID,
           RECEIVEORGID,
           SENDTIME,
           SENDORGID,
           HANDLESTATUS)
        values
          (pMsgID,
           SEQ_MSG_CALLTRANSFERRECEIVEID.NEXTVAL,
           pReceiveOrgID,
           sysdate,
           pForwardOrgID,
           1);
      
      end if;
    ELSE
      UPDATE JKPT_MSG_CALLTRANSFER_RECEIVE
         SET HANDLESTATUS = 4, replytime = sysdate, reply = pReplyContent
       WHERE RECEIVEID = pReceiveID;
    
      update JKPT_MSG_CALLTRANSFER t
         set t.status = 1
       where t.msgid = pMsgID;
    
      insert into JKPT_MSG_CALLTRANSFER_RECEIVE
        (MSGID, RECEIVEID, RECEIVEORGID, SENDTIME, SENDORGID, HANDLESTATUS)
      values
        (pMsgID,
         SEQ_MSG_CALLTRANSFERRECEIVEID.NEXTVAL,
         pReceiveOrgID,
         sysdate,
         pForwardOrgID,
         1);
    END IF;
  
    commit;
  
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end PROC_ForwardCallTransfer;

  -- tian jia hu jiao liu zhuan
  procedure PROC_AddCallTransfer(pCreationUserID   IN varchar2,
                                 pContent          in varchar2,
                                 pCreationOrgID    in varchar2,
                                 pCustomerName     in varchar2,
                                 pCustomerMobile   in varchar2,
                                 pRoadID           in varchar2,
                                 pPosition         in varchar2,
                                 pCallTransferType in number,
                                 pPlateNum         in varchar2,
                                 pModel            in varchar2,
                                 pDirection        in varchar2,
                                 pComplaintObject  in varchar2,
                                 pReceiveOrgID     in varchar2,
                                 pReturnVal        out number,
                                 pMSG              out varchar2) as
    vPrefix    varchar2(2);
    vCurrentID varchar2(7);
    vCount     number;
    vCode      varchar2(20);
    vMsgID     number;
  begin
    pReturnVal := 1;
    pMSG       := '';
  
    select decode(pCallTransferType,
                  1,
                  'JY',
                  2,
                  'TS',
                  3,
                  'TF',
                  4,
                  'QZ',
                  10,
                  'QT')
      into vPrefix
      from dual;
  
    --start huo qu bian hao
    select LPAD(currentid, 5, '0')
      into vCurrentID
      from jkpt_base_seq
     where upper(tablename) = 'JKPT_MSG_CALLTRANSFER'
       and prefix = vPrefix
       for update;
  
    select count(*)
      into vCount
      from JKPT_MSG_CALLTRANSFER t
     where t.creationtime > trunc(sysdate, 'yyyy')
       and t.calltransfertype = pCallTransferType;
    if (vCount > 0) then
      select vPrefix || to_char(sysdate, 'yy') || vCurrentID
        into vCode　from dual;
      update jkpt_base_seq
         set currentid = currentid + 1
       where upper(tablename) = 'JKPT_MSG_CALLTRANSFER'
         and prefix = vPrefix;
    else
      select vPrefix || to_char(sysdate, 'yy') || '00001'
        into vCode　from dual;
      update jkpt_base_seq
         set currentid = 2
       where upper(tablename) = 'JKPT_MSG_CALLTRANSFER'
         and prefix = vPrefix;
    end if;
    --end huo qu bian hao
  
    select SEQ_MSG_CALLTRANSFERID.Nextval into vMsgID from dual;
    insert into jkpt_msg_calltransfer
      (msgid,
       creationuserid,
       creationtime,
       content,
       creationorgid,
       customername,
       customermobile,
       roadid,
       position,
       calltransfertype,
       platenum,
       model,
       direction,
       complaintobject,
       status,
       code)
    values
      (vMsgID,
       pCreationUserID,
       sysdate,
       pContent,
       pCreationOrgID,
       pCustomerName,
       pCustomerMobile,
       pRoadID,
       pPosition,
       pCallTransferType,
       pPlateNum,
       pModel,
       pDirection,
       pComplaintObject,
       1,
       vCode);
  
    insert into JKPT_MSG_CALLTRANSFER_RECEIVE
      (MSGID, RECEIVEID, RECEIVEORGID, SENDTIME, SENDORGID, HANDLESTATUS)
    values
      (vMsgID,
       SEQ_MSG_CALLTRANSFERRECEIVEID.NEXTVAL,
       pReceiveOrgID,
       sysdate,
       pCreationOrgID,
       1);
  
    commit;
  
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end PROC_AddCallTransfer;

end PG_JKPT_XXZX_CALLTRANSFER;
/

