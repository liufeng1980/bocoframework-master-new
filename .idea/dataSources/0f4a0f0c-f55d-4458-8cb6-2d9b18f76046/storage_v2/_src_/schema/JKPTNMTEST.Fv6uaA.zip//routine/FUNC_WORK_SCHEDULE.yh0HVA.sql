create function FUNC_WORK_Schedule(pOrgId    in varchar2,
                                              beginDate in varchar2,
                                              endDate   in varchar2)
  return number is
  PRAGMA AUTONOMOUS_TRANSACTION;
  vResult    number;
  vBeginDate date;
  vEndDate   date;
  vDayCount  number;
  vWorkDate  date;

  cursor morning_cur is
    select * from jkpt_work_team a where a.orgid=pOrgId order by a.ordermorning asc;
  cursor middle_cur is
    select * from jkpt_work_team a where a.orgid=pOrgId order by a.ordermiddle asc;
  cursor night_cur is
    select * from jkpt_work_team a where a.orgid=pOrgId order by a.ordernight asc;
  my_tab             jkpt_work_team%rowtype;
  x                  number;
  vShiftId           number;
  vShiftCode         varchar2(10);
  vShiftBeginTimeStr varchar2(10);
  vShiftEndTimeStr   varchar2(10);
  vShiftBeginTimeNum number;
  vShiftEndTimeNum   number;
  vBeginTime         date;
  vEndTime           date;
begin
  select to_date(beginDate, 'yyyy-MM-dd') into vBeginDate from dual;
  select to_date(endDate, 'yyyy-MM-dd') into vEndDate from dual;

  select trunc(vEndDate) - trunc(vBeginDate) into vDayCount from dual;

  delete jkpt_work_Schedule
   where orgid = pOrgId
     and workdate >= vBeginDate
     and workdate <= vEndDate;
  --早班
  vWorkDate := vBeginDate - 1;
  x         := 0;
  select id,
         code,
         begintime,
         endtime,
         to_number(replace(begintime, ':', '')),
         to_number(replace(endtime, ':', ''))
    into vShiftId,
         vShiftCode,
         vShiftBeginTimeStr,
         vShiftEndTimeStr,
         vShiftBeginTimeNum,
         vShiftEndTimenum
    from JKPT_WORK_SHIFT
   where orgid = pOrgId
     and type = 1;
  WHILE x <= vDayCount LOOP
    open morning_cur;
    loop
      fetch morning_cur
        into my_tab;
      exit when morning_cur%notfound;
      vWorkDate := vWorkDate + 1;
      x         := x + 1;
      if (x > vDayCount) then
        exit;
      end if;
      select to_date(to_char(vWorkDate, 'yyyy-MM-dd') || ' ' ||
                     vShiftBeginTimeStr,
                     'yyyy-MM-dd HH24:mi:ss')
        into vBeginTime
        from dual;
      if (vShiftEndTimeNum < vShiftBeginTimeNum) then
        select to_date(to_char(vWorkDate + 1, 'yyyy-MM-dd') || ' ' ||
                       vShiftEndTimeStr,
                       'yyyy-MM-dd HH24:mi:ss')
          into vEndTime
          from dual;
      else
        select to_date(to_char(vWorkDate, 'yyyy-MM-dd') || ' ' ||
                       vShiftEndTimeStr,
                       'yyyy-MM-dd HH24:mi:ss')
          into vEndTime
          from dual;
      end if;
      insert into jkpt_work_Schedule
        (id,
         Orgid,
         Workdate,
         Workshiftid,
         Workteamid,
         workshiftcode,
         workteamcode,
         begintime,
         endtime)
      values
        (SEQ_WORK_SCHEDULE.Nextval,
         pOrgId,
         vWorkDate,
         vShiftId,
         my_tab.id,
         vShiftCode,
         my_tab.code,
         vBeginTime,
         vEndTime);
    end loop;
    close morning_cur;
  END LOOP;
  --早班结束

  --中班
  vWorkDate := vBeginDate - 1;
  x         := 0;
  select id,
         code,
         begintime,
         endtime,
         to_number(replace(begintime, ':', '')),
         to_number(replace(endtime, ':', ''))
    into vShiftId,
         vShiftCode,
         vShiftBeginTimeStr,
         vShiftEndTimeStr,
         vShiftBeginTimeNum,
         vShiftEndTimenum
    from JKPT_WORK_SHIFT
   where orgid = pOrgId
     and type = 2;
  WHILE x <= vDayCount LOOP
    open middle_cur;
    loop
      fetch middle_cur
        into my_tab;
      exit when middle_cur%notfound;
      vWorkDate := vWorkDate + 1;
      x         := x + 1;
      if (x > vDayCount) then
        exit;
      end if;
      select to_date(to_char(vWorkDate, 'yyyy-MM-dd') || ' ' ||
                     vShiftBeginTimeStr,
                     'yyyy-MM-dd HH24:mi:ss')
        into vBeginTime
        from dual;
      if (vShiftEndTimeNum < vShiftBeginTimeNum) then
        select to_date(to_char(vWorkDate + 1, 'yyyy-MM-dd') || ' ' ||
                       vShiftEndTimeStr,
                       'yyyy-MM-dd HH24:mi:ss')
          into vEndTime
          from dual;
      else
        select to_date(to_char(vWorkDate, 'yyyy-MM-dd') || ' ' ||
                       vShiftEndTimeStr,
                       'yyyy-MM-dd HH24:mi:ss')
          into vEndTime
          from dual;
      end if;
      insert into jkpt_work_Schedule
        (id,
         Orgid,
         Workdate,
         Workshiftid,
         Workteamid,
         workshiftcode,
         workteamcode,
         begintime,
         endtime)
      values
        (SEQ_WORK_SCHEDULE.Nextval,
         pOrgId,
         vWorkDate,
         vShiftId,
         my_tab.id,
         vShiftCode,
         my_tab.code,
         vBeginTime,
         vEndTime);
    end loop;
    close middle_cur;
  END LOOP;
  --中班结束

  --晚班
  vWorkDate := vBeginDate - 1;
  x         := 0;
  select id,
         code,
         begintime,
         endtime,
         to_number(replace(begintime, ':', '')),
         to_number(replace(endtime, ':', ''))
    into vShiftId,
         vShiftCode,
         vShiftBeginTimeStr,
         vShiftEndTimeStr,
         vShiftBeginTimeNum,
         vShiftEndTimenum
    from JKPT_WORK_SHIFT
   where orgid = pOrgId
     and type = 3;
  WHILE x <= vDayCount LOOP
    open night_cur;
    loop
      fetch night_cur
        into my_tab;
      exit when night_cur%notfound;
      vWorkDate := vWorkDate + 1;
      x         := x + 1;
      if (x > vDayCount) then
        exit;
      end if;
      select to_date(to_char(vWorkDate, 'yyyy-MM-dd') || ' ' ||
                     vShiftBeginTimeStr,
                     'yyyy-MM-dd HH24:mi:ss')
        into vBeginTime
        from dual;
      if (vShiftEndTimeNum < vShiftBeginTimeNum) then
        select to_date(to_char(vWorkDate + 1, 'yyyy-MM-dd') || ' ' ||
                       vShiftEndTimeStr,
                       'yyyy-MM-dd HH24:mi:ss')
          into vEndTime
          from dual;
      else
        select to_date(to_char(vWorkDate, 'yyyy-MM-dd') || ' ' ||
                       vShiftEndTimeStr,
                       'yyyy-MM-dd HH24:mi:ss')
          into vEndTime
          from dual;
      end if;
      insert into jkpt_work_Schedule
        (id,
         Orgid,
         Workdate,
         Workshiftid,
         Workteamid,
         workshiftcode,
         workteamcode,
         begintime,
         endtime)
      values
        (SEQ_WORK_SCHEDULE.Nextval,
         pOrgId,
         vWorkDate,
         vShiftId,
         my_tab.id,
         vShiftCode,
         my_tab.code,
         vBeginTime,
         vEndTime);
    end loop;
    close night_cur;
  END LOOP;
  --晚班结束

  commit;
  return(1);
end FUNC_WORK_Schedule;

/

