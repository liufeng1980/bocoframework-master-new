create view V_VEHICLE as
select A.VEHICLEPLATE,
       A.DRIVER,
       A.PHONE,
       A.REVTIME,
       A.REMARK,
       A.ORGID,
       B.ORGNAME
  from JKPT_BASE_VEHICLE A, JKPT_BASE_ORG B
 WHERE A.ORGID = B.ORGID
/

