create package body PG_JKPT_TSGL is

  --气象信息统计报表
  procedure PROC_ExportAuditDetail(PUserID        IN VARCHAR2,
                                   pComplaintID   IN number,
                                   PReturnVal     OUT NUMBER,
                                   PMSG           OUT varchar2,
                                   PResultDataSet OUT Cur_Result) as
    VFrequency number;
    I          number;
    VCount     number;
    VPKID      number;
    VQUERYTYPE VARCHAR2(30); --查询类型
    ILoop      number;

  begin

    PReturnVal := 1;
    PMSG       := '';
    VFrequency := 0;
    I          := 0;
    VCount     := 0;
    VQUERYTYPE := 'TSGL';
    ILoop      := 1;

    --删除历史查询记录
    DELETE FROM JKPT_TJFX_COMM
     WHERE QUERYTYPE = VQUERYTYPE
       AND COL41 = pComplaintID
       and COL1 = PUserID;
       COMMIT;

    --获取最大不满意次数
    select a.frequency
      into VFrequency
      from jkpt_tsgl_auditinfo a
     where a.fkid = pComplaintID
       and a.iscurrent = '1';

    LOOP
      --判断运营科是否有响应记录
      select count(1)
        into VCount
        from jkpt_tsgl_auditdetail a
       where a.complaintid = pComplaintID
         and a.frequency = I
         and a.sendorgid in
             (select a.orgid
                from jkpt_tsgl_orgrelation a
               where a.grouptype = 'OperationDept')
         and a.passpath = '1';

      if VCount > 0 then

        select max(a.pkid)
          into VPKID
          from jkpt_tsgl_auditdetail a
         where a.complaintid = pComplaintID
           and a.frequency = I
           and a.sendorgid in
               (select a.orgid
                  from jkpt_tsgl_orgrelation a
                 where a.grouptype = 'OperationDept')
           and a.passpath = '1';

        --保存运营科接收意见
        insert into JKPT_TJFX_COMM
          (QUERYTYPE,
           COL41,
           LINE,
           COL1,
           COL2,
           COL3,
           COL4,
           COL31,
           COL42,
           COL43,
           COL44,
           COL86,
           COL87)
          select VQUERYTYPE,
                 pComplaintID,
                 ILoop,
                 PUserID,
                 a.sendorgid,
                 a.receiveorgid,
                 b.receiveuserid,
                 b.suggestion,
                 a.passpath,
                 I,
                 a.pkid,
                 b.dealtime,
                 sysdate
            from jkpt_tsgl_auditdetail a,
                 (select d.suggestion, d.dealtime, d.receiveuserid, d.fkid
                    from jkpt_tsgl_auditdetail d
                   where d.pkid =
                         (select max(f.pkid)
                            from jkpt_tsgl_auditdetail f
                           where f.complaintid = pComplaintID
                             and f.frequency = I
                             and f.receiveorgid in
                                 (select g.orgid
                                    from jkpt_tsgl_orgrelation g
                                   where g.grouptype = 'OperationDept')
                             and f.passpath = '1'
                             and f.pkid < VPKID)) b
           where a.pkid = VPKID
             and a.fkid = b.fkid;

        ILoop := ILoop + 1;

        --判断监控部是否有响应记录
        select count(1)
          into VCount
          from jkpt_tsgl_auditdetail a
         where a.complaintid = pComplaintID
           and a.frequency = I
           and a.sendorgid in
               (select a.orgid
                  from jkpt_tsgl_orgrelation a
                 where a.grouptype = 'MonitorDept' or a.grouptype = 'GaoLuHearCenter')
           and a.passpath = '1'
           and a.pkid > VPKID;

        if VCount > 0 then

          select max(a.pkid)
            into VPKID
            from jkpt_tsgl_auditdetail a
           where a.complaintid = pComplaintID
             and a.frequency = I
             and a.sendorgid in
                 (select a.orgid
                    from jkpt_tsgl_orgrelation a
                   where a.grouptype = 'MonitorDept' or a.grouptype = 'GaoLuHearCenter')
             and a.passpath = '1'
             and a.pkid > VPKID;

          --保存监控部接收意见
          insert into JKPT_TJFX_COMM
            (QUERYTYPE,
             COL41,
             LINE,
             COL1,
             COL2,
             COL3,
             COL4,
             COL31,
             COL42,
             COL43,
             COL44,
             COL86,
             COL87)
            select VQUERYTYPE,
                   pComplaintID,
                   ILoop,
                   PUserID,
                   a.sendorgid,
                   a.receiveorgid,
                   b.receiveuserid,
                   b.suggestion,
                   a.passpath,
                   I,
                   a.pkid,
                   b.dealtime,
                   sysdate
              from jkpt_tsgl_auditdetail a,
                   (select d.suggestion, d.dealtime, d.receiveuserid, d.fkid
                      from jkpt_tsgl_auditdetail d
                     where d.pkid =
                           (select max(f.pkid)
                              from jkpt_tsgl_auditdetail f
                             where f.complaintid = pComplaintID
                               and f.frequency = I
                               and f.receiveorgid in
                                   (select g.orgid
                                      from jkpt_tsgl_orgrelation g
                                     where g.grouptype = 'MonitorDept' or g.grouptype = 'GaoLuHearCenter')
                               and f.passpath = '1'
                               and f.pkid < VPKID)) b
             where a.pkid = VPKID
               and a.fkid = b.fkid;
          ILoop := ILoop + 1;

        end if;

      end if;

      --判断分中心是否有审核记录
      select count(1)
        into VCount
        from jkpt_tsgl_auditdetail a
       where a.complaintid = pComplaintID
         and a.frequency = I
         and a.sendorgid in
             (select a.orgid
                from jkpt_tsgl_orgrelation a
               where a.grouptype = 'SubCenter')
         and a.passpath = '2'
         and a.sendorgid <> a.receiveorgid and a.suggestion is not null;

      if VCount > 0 then

        select max(a.pkid)
          into VPKID
          from jkpt_tsgl_auditdetail a
         where a.complaintid = pComplaintID
           and a.frequency = I
           and a.sendorgid in
               (select a.orgid
                  from jkpt_tsgl_orgrelation a
                 where a.grouptype = 'SubCenter')
           and a.passpath = '2'
           and a.sendorgid <> a.receiveorgid and a.suggestion is not null;

        --保存分中心审核意见
        insert into JKPT_TJFX_COMM
          (QUERYTYPE,
           COL41,
           LINE,
           COL1,
           COL2,
           COL3,
           COL4,
           COL31,
           COL42,
           COL43,
           COL44,
           COL86,
           COL87)
          select VQUERYTYPE,
                 pComplaintID,
                 ILoop,
                 PUserID,
                 a.sendorgid,
                 a.receiveorgid,
                 b.receiveuserid,
                 b.suggestion,
                 a.passpath,
                 I,
                 a.pkid,
                 b.dealtime,
                 sysdate
            from jkpt_tsgl_auditdetail a,
                 (select d.suggestion, d.dealtime, d.receiveuserid, d.fkid
                    from jkpt_tsgl_auditdetail d
                   where d.pkid =
                         (select max(f.pkid)
                            from jkpt_tsgl_auditdetail f
                           where f.complaintid = pComplaintID
                             and f.frequency = I
                             and f.receiveorgid in
                                 (select g.orgid
                                    from jkpt_tsgl_orgrelation g
                                   where g.grouptype = 'SubCenter') and f.pkid<VPKID)) b
           where a.pkid = VPKID
             and a.fkid = b.fkid;
        ILoop := ILoop + 1;

      end if;

      EXIT WHEN I >= VFrequency;
      I := I + 1;
    END LOOP;
    commit;
    open PResultDataSet for
      select COL2 SendOrgID, --处理方机构编码
             (select b.orgname from jkpt_base_org b where a.col2=b.orgid) SendOrgName,--处理方机构名称
             COL3 ReceiveOrgID, --收件方编码
             (select b.orgname from jkpt_base_org b where a.col3=b.orgid) ReceiveOrgName,--收件方名称
             COL4 SendUserID,--处理工号
             u.LOGINID SendUserLoginId,--
             COL31 Suggestion, --意见及要求
             COL42 PassPath, --通过路径：1-投诉，2-处理，3-回访
             COL43 Frequency, --不满意次数
             COL44 PKID, --主键
             COL86 DealTime --发送时间
        from JKPT_TJFX_COMM a
        LEFT JOIN JKPT_BASE_USER u ON a.COL4 = u.USERID
       where a.querytype = 'TSGL'
         AND COL41 = pComplaintID
         and COL1 = PUserID
       order by a.line;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败:' || sqlerrm;
  end;

end PG_JKPT_TSGL;
/

