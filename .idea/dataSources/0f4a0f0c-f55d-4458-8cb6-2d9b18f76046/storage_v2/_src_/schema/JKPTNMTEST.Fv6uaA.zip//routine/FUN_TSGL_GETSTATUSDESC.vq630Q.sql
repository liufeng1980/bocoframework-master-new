create FUNCTION FUN_tsgl_getstatusdesc(complaintid in number)
  RETURN VARCHAR2 AS
  RETURNVAL          VARCHAR2(1000) := '';
  mTimes             number;
  mCreationTime      varchar2(20) := '';
  mCurrentOrgName    varchar2(20) := '';
  mCurrentSuggestion varchar2(1000) := '';
  mCurrentStatusDesc varchar2(100) := '';
BEGIN
  select a.frequency + 1,
         to_char(a.creationtime, 'yyyy-MM-dd hh24:mi:ss'),
         b.orgname,
         decode(a.currentsuggestion, '', '', '-' || a.currentsuggestion) currentsuggestion,
         a.currentstatusdesc
    into mTimes,
         mCreationTime,
         mCurrentOrgName,
         mCurrentSuggestion,
         mCurrentStatusDesc
    from Jkpt_Tsgl_Auditinfo a, jkpt_base_org b
   where a.fkid = complaintid
     and a.iscurrent = 1
     and a.receiveorgid = b.orgid;
  if (mTimes = 1) then
    RETURNVAL := mCreationTime || mCurrentOrgName || ' ' || '【' ||
                 mCurrentStatusDesc || mCurrentSuggestion || '】';
  else
    RETURNVAL := '第' || mTimes || '次处理' || ' ' || mCreationTime ||
                 mCurrentOrgName || '【' || mCurrentStatusDesc ||
                 mCurrentSuggestion || '】';
  end if;

  return RETURNVAL;
END FUN_tsgl_getstatusdesc;
/

