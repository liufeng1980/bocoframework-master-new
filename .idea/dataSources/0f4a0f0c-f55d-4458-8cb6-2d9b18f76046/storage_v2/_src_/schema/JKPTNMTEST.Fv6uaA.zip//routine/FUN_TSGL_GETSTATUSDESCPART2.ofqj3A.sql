create FUNCTION FUN_tsgl_getstatusdescpart2(complaintid in number)
  RETURN VARCHAR2 AS
  RETURNVAL          VARCHAR2(1000) := '';
  mCurrentOrgName    varchar2(20) := '';
  mCurrentStatusDesc varchar2(100) := '';
BEGIN
  select b.orgname,
         a.currentstatusdesc
    into mCurrentOrgName, mCurrentStatusDesc
    from Jkpt_Tsgl_Auditinfo a, jkpt_base_org b
   where a.fkid = complaintid
     and a.iscurrent = 1
     and a.receiveorgid = b.orgid;

  RETURNVAL := mCurrentOrgName || ' 【' || mCurrentStatusDesc || '】';

  return RETURNVAL;
END FUN_tsgl_getstatusdescpart2;
/

