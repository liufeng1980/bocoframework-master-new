create package PG_JKPT_TSGL is

  -- 定义游标
  type Cur_Result is ref cursor;

  procedure PROC_ExportAuditDetail(PUserID        IN VARCHAR2,
                                   pComplaintID   IN number,
                                   pReturnVal     out number,
                                   pMSG           out varchar2,
                                   PResultDataSet OUT Cur_Result);

end PG_JKPT_TSGL;
/

