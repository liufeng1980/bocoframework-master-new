create package body PG_JKPT_REPORT is

  procedure GetTRAFFICFLUX(PUserID        IN VARCHAR2,
                           PQueryDate     IN VARCHAR2,
                           PRoadID        IN VARCHAR2,
                           PDeviceID      IN VARCHAR2,
                           PValidateMode  IN VARCHAR2,
                           PORGID         IN VARCHAR2,
                           PReturnVal     OUT NUMBER,
                           PMSG           OUT varchar2,
                           PResultDataSet OUT Cur_Result) as
    I           number; --定义变量
    VDAYMAX     number; --天最大值
    VCOUNT      number; --记录行数
    VDATE       varchar(20); --日期
    VORGNAME    VARCHAR2(100); --组织机构名称
    VROADNAME   VARCHAR2(100); --路线名称
    VDEVICENAME VARCHAR2(100); --设备名称
    VQUERYTYPE  VARCHAR2(30); --统计类型
  begin
    --返回值：1-成功，0-失败
    PReturnVal := 1;
    VQUERYTYPE := 'TRAFFICFLUX';
    --删除历史查询记录
    DELETE FROM JKPT_TJFX_COMM
     WHERE QUERYTYPE = VQUERYTYPE
       AND COL1 = PUserID;
    SELECT A.DEVICENAME, B.ROADNAME, C.ORGNAME
      INTO VDEVICENAME, VROADNAME, VORGNAME
      FROM JKPT_BASE_DEVICE A, JKPT_BASE_ORG_ROAD B, JKPT_BASE_ORG C
     WHERE A.ROADID = B.ROADID
       AND B.ORGID = C.ORGID
       AND A.DEVICEID = PDeviceID
       AND A.ROADID = PRoadID
       AND C.ORGID = PORGID;
    --日统计
    if PValidateMode = 'd' then
      I := 0;
      loop
        --拼接天
        if i < 10 then
          VDATE := PQueryDate || ' 0' || I;
        else
          VDATE := PQueryDate || ' ' || I;
        end if;

        --判断记录是否存在
        SELECT count(1)
          into VCOUNT
          FROM JKPT_BASE_TRAIVD_HIS A,
               JKPT_BASE_DEVICE     B,
               JKPT_BASE_ORG_ROAD   C,
               JKPT_BASE_ORG        D
         WHERE A.DEVICEID = B.DEVICEID
           AND B.ROADID = C.ROADID
           AND C.ORGID = D.ORGID
           AND A.DEVICEID = PDeviceID
           AND B.ROADID = PRoadID
           AND D.ORGID = PORGID
           and TO_CHAR(A.REVTIME, 'yyyy-mm-dd hh24') = VDATE;
        if VCOUNT = 0 then
          INSERT INTO JKPT_TJFX_COMM
            (QUERYTYPE,
             LINE,
             COL1,
             COL2,
             COL3,
             COL4,
             COL5,
             COL6,
             COL41,
             COL42,
             COL43,
             COL44,
             COL45,
             COL46,
             COL47,
             COL48,
             COL49,
             COL50,
             COL56,
             COL57,
             COL58,
             COL59,
             COL60,
             COL61,
             COL62,
             COL63,
             COL64,
             COL65,
             COL66,
             COL86)
          VALUES
            (VQUERYTYPE,
             I,
             PUSERID,
             PRoadID,
             VROADNAME,
             I || '时',
             VDEVICENAME,
             PDeviceID,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             sysdate);
        else
          INSERT INTO JKPT_TJFX_COMM
            (QUERYTYPE,
             LINE,
             COL1,
             COL2,
             COL3,
             COL4,
             COL5,
             COL6,
             COL41,
             COL42,
             COL43,
             COL44,
             COL45,
             COL46,
             COL47,
             COL48,
             COL49,
             COL50,
             COL56,
             COL57,
             COL58,
             COL59,
             COL60,
             COL61,
             COL62,
             COL63,
             COL64,
             COL65,
             COL66,
             COL86)
            SELECT VQUERYTYPE,
                   I,
                   PUserID,
                   L.ROADID,
                   L.ROADNAME,
                   I || '时',
                   N.DEVICENAME,
                   M.*,
                   sysdate
              FROM (SELECT DEVICEID,
                           SUM(TRAFFLUX) TRAFFLUX,
                           SUM(MSBUSTRAFFLUX) MSBUSTRAFFLUX,
                           SUM(MINIVANTRAFFLUX) MINIVANTRAFFLUX,
                           SUM(BUSTRAFFLUX) BUSTRAFFLUX,
                           SUM(MVANTRAFFLUX) MVANTRAFFLUX,
                           SUM(LVANTRAFFLUX) LVANTRAFFLUX,
                           SUM(VLVANTRAFFLUX) VLVANTRAFFLUX,
                           SUM(CONTAINERTRAFFLUX) CONTAINERTRAFFLUX,
                           SUM(TRACTORTRAFFLUX) TRACTORTRAFFLUX,
                           SUM(MOTOTRAFFLUX) MOTOTRAFFLUX,
                           AVG(AVGSPEED) AVGSPEED,
                           AVG(AVGHOLDRATE) AVGHOLDRATE,
                           AVG(MSBUSAVGSPEED) MSBUSAVGSPEED,
                           AVG(MINIVANAVGSPEED) MINIVANAVGSPEED,
                           AVG(BUSAVGSPEED) BUSAVGSPEED,
                           AVG(MVANAVGSPEED) MVANAVGSPEED,
                           AVG(LVANAVGSPEED) LVANAVGSPEED,
                           AVG(VLVANAVGSPEED) VLVANAVGSPEED,
                           AVG(CONTAINERAVGSPEED) CONTAINERAVGSPEED,
                           AVG(TRACTORAVGSPEED) TRACTORAVGSPEED,
                           AVG(MOTOAVGSPEED) MOTOAVGSPEED
                      FROM JKPT_BASE_TRAIVD_HIS A
                     WHERE A.DEVICEID = PDeviceID
                       and TO_CHAR(A.REVTIME, 'yyyy-mm-dd hh24') = VDATE
                     GROUP BY A.DEVICEID) M,
                   JKPT_BASE_DEVICE N,
                   JKPT_BASE_ORG_ROAD L,
                   JKPT_BASE_ORG T
             WHERE M.DEVICEID = N.DEVICEID
               AND N.ROADID = L.ROADID
               AND N.ROADID = PRoadID
               AND L.ORGID = T.ORGID
               AND L.ORGID = PORGID;
        end if;
        exit when I = 23;
        I := I + 1;
      end loop;
      --月统计
    elsif PValidateMode = 'm' then
      select to_char(last_day(to_date(PQueryDate, 'yyyy-mm-dd')), 'dd')
        INTO VDAYMAX
        from dual;
      I := 1;
      loop
        --拼接天
        if i < 10 then
          SELECT TO_CHAR(to_date(PQueryDate, 'yyyy-mm-dd'), 'yyyy-mm') || '-0' || I
            INTO VDATE
            FROM DUAL;
        else
          SELECT TO_CHAR(to_date(PQueryDate, 'yyyy-mm-dd'), 'yyyy-mm') || '-' || I
            INTO VDATE
            FROM DUAL;
        end if;

        --判断记录是否存在
        SELECT count(1)
          into VCOUNT
          FROM JKPT_BASE_TRAIVD_HIS A,
               JKPT_BASE_DEVICE     B,
               JKPT_BASE_ORG_ROAD   C,
               JKPT_BASE_ORG        D
         WHERE A.DEVICEID = B.DEVICEID
           AND B.ROADID = C.ROADID
           AND A.DEVICEID = PDeviceID
           AND B.ROADID = PRoadID
           AND C.ORGID = D.ORGID
           AND C.ORGID = PORGID
           and TO_CHAR(A.REVTIME, 'yyyy-mm-dd') = VDATE;
        if VCOUNT = 0 then
          INSERT INTO JKPT_TJFX_COMM
            (QUERYTYPE,
             LINE,
             COL1,
             COL2,
             COL3,
             COL4,
             COL5,
             COL6,
             COL41,
             COL42,
             COL43,
             COL44,
             COL45,
             COL46,
             COL47,
             COL48,
             COL49,
             COL50,
             COL56,
             COL57,
             COL58,
             COL59,
             COL60,
             COL61,
             COL62,
             COL63,
             COL64,
             COL65,
             COL66,
             COL86)
          VALUES
            (VQUERYTYPE,
             I,
             PUSERID,
             PRoadID,
             VROADNAME,
             I || '日',
             VDEVICENAME,
             PDeviceID,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             sysdate);
        else
          INSERT INTO JKPT_TJFX_COMM
            (QUERYTYPE,
             LINE,
             COL1,
             COL2,
             COL3,
             COL4,
             COL5,
             COL6,
             COL41,
             COL42,
             COL43,
             COL44,
             COL45,
             COL46,
             COL47,
             COL48,
             COL49,
             COL50,
             COL56,
             COL57,
             COL58,
             COL59,
             COL60,
             COL61,
             COL62,
             COL63,
             COL64,
             COL65,
             COL66,
             COL86)
            SELECT VQUERYTYPE,
                   I,
                   PUserID,
                   L.ROADID,
                   L.ROADNAME,
                   I || '日',
                   N.DEVICENAME,
                   M.*,
                   sysdate
              FROM (SELECT DEVICEID,
                           SUM(TRAFFLUX) TRAFFLUX,
                           SUM(MSBUSTRAFFLUX) MSBUSTRAFFLUX,
                           SUM(MINIVANTRAFFLUX) MINIVANTRAFFLUX,
                           SUM(BUSTRAFFLUX) BUSTRAFFLUX,
                           SUM(MVANTRAFFLUX) MVANTRAFFLUX,
                           SUM(LVANTRAFFLUX) LVANTRAFFLUX,
                           SUM(VLVANTRAFFLUX) VLVANTRAFFLUX,
                           SUM(CONTAINERTRAFFLUX) CONTAINERTRAFFLUX,
                           SUM(TRACTORTRAFFLUX) TRACTORTRAFFLUX,
                           SUM(MOTOTRAFFLUX) MOTOTRAFFLUX,
                           AVG(AVGSPEED) AVGSPEED,
                           AVG(AVGHOLDRATE) AVGHOLDRATE,
                           AVG(MSBUSAVGSPEED) MSBUSAVGSPEED,
                           AVG(MINIVANAVGSPEED) MINIVANAVGSPEED,
                           AVG(BUSAVGSPEED) BUSAVGSPEED,
                           AVG(MVANAVGSPEED) MVANAVGSPEED,
                           AVG(LVANAVGSPEED) LVANAVGSPEED,
                           AVG(VLVANAVGSPEED) VLVANAVGSPEED,
                           AVG(CONTAINERAVGSPEED) CONTAINERAVGSPEED,
                           AVG(TRACTORAVGSPEED) TRACTORAVGSPEED,
                           AVG(MOTOAVGSPEED) MOTOAVGSPEED
                      FROM JKPT_BASE_TRAIVD_HIS A
                     WHERE A.DEVICEID = PDeviceID
                       and TO_CHAR(A.REVTIME, 'yyyy-mm-dd') = VDATE
                     GROUP BY A.DEVICEID) M,
                   JKPT_BASE_DEVICE N,
                   JKPT_BASE_ORG_ROAD L
             WHERE M.DEVICEID = N.DEVICEID
               AND N.ROADID = L.ROADID
               AND N.ROADID = PRoadID;
        end if;
        exit when I = VDAYMAX;
        I := I + 1;
      end loop;
      --年统计
    elsif PValidateMode = 'y' then
      I := 1;
      loop
        --拼接天
        if i < 10 then
          SELECT TO_CHAR(to_date(PQueryDate, 'yyyy-mm-dd'), 'yyyy') || '-0' || I
            INTO VDATE
            FROM DUAL;
        else
          SELECT TO_CHAR(to_date(PQueryDate, 'yyyy-mm-dd'), 'yyyy') || '-' || I
            INTO VDATE
            FROM DUAL;
        end if;

        --判断记录是否存在
        SELECT count(1)
          into VCOUNT
          FROM JKPT_BASE_TRAIVD_HIS A,
               JKPT_BASE_DEVICE     B,
               JKPT_BASE_ORG_ROAD   C,
               JKPT_BASE_ORG        D
         WHERE A.DEVICEID = B.DEVICEID
           AND B.ROADID = C.ROADID
           AND A.DEVICEID = PDeviceID
           AND B.ROADID = PRoadID
           AND C.ORGID = D.ORGID
           AND C.ORGID = PORGID
           and TO_CHAR(A.REVTIME, 'yyyy-mm') = VDATE;
        if VCOUNT = 0 then
          INSERT INTO JKPT_TJFX_COMM
            (QUERYTYPE,
             LINE,
             COL1,
             COL2,
             COL3,
             COL4,
             COL5,
             COL6,
             COL41,
             COL42,
             COL43,
             COL44,
             COL45,
             COL46,
             COL47,
             COL48,
             COL49,
             COL50,
             COL56,
             COL57,
             COL58,
             COL59,
             COL60,
             COL61,
             COL62,
             COL63,
             COL64,
             COL65,
             COL66,
             COL86)
          VALUES
            (VQUERYTYPE,
             I,
             PUSERID,
             PRoadID,
             VROADNAME,
             I || '月',
             VDEVICENAME,
             PDeviceID,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             0.00,
             sysdate);
        else
          INSERT INTO JKPT_TJFX_COMM
            (QUERYTYPE,
             LINE,
             COL1,
             COL2,
             COL3,
             COL4,
             COL5,
             COL6,
             COL41,
             COL42,
             COL43,
             COL44,
             COL45,
             COL46,
             COL47,
             COL48,
             COL49,
             COL50,
             COL56,
             COL57,
             COL58,
             COL59,
             COL60,
             COL61,
             COL62,
             COL63,
             COL64,
             COL65,
             COL66,
             COL86)
            SELECT VQUERYTYPE,
                   I,
                   PUserID,
                   L.ROADID,
                   L.ROADNAME,
                   I || '月',
                   N.DEVICENAME,
                   M.*,
                   sysdate
              FROM (SELECT DEVICEID,
                           SUM(TRAFFLUX) TRAFFLUX,
                           SUM(MSBUSTRAFFLUX) MSBUSTRAFFLUX,
                           SUM(MINIVANTRAFFLUX) MINIVANTRAFFLUX,
                           SUM(BUSTRAFFLUX) BUSTRAFFLUX,
                           SUM(MVANTRAFFLUX) MVANTRAFFLUX,
                           SUM(LVANTRAFFLUX) LVANTRAFFLUX,
                           SUM(VLVANTRAFFLUX) VLVANTRAFFLUX,
                           SUM(CONTAINERTRAFFLUX) CONTAINERTRAFFLUX,
                           SUM(TRACTORTRAFFLUX) TRACTORTRAFFLUX,
                           SUM(MOTOTRAFFLUX) MOTOTRAFFLUX,
                           AVG(AVGSPEED) AVGSPEED,
                           AVG(AVGHOLDRATE) AVGHOLDRATE,
                           AVG(MSBUSAVGSPEED) MSBUSAVGSPEED,
                           AVG(MINIVANAVGSPEED) MINIVANAVGSPEED,
                           AVG(BUSAVGSPEED) BUSAVGSPEED,
                           AVG(MVANAVGSPEED) MVANAVGSPEED,
                           AVG(LVANAVGSPEED) LVANAVGSPEED,
                           AVG(VLVANAVGSPEED) VLVANAVGSPEED,
                           AVG(CONTAINERAVGSPEED) CONTAINERAVGSPEED,
                           AVG(TRACTORAVGSPEED) TRACTORAVGSPEED,
                           AVG(MOTOAVGSPEED) MOTOAVGSPEED
                      FROM JKPT_BASE_TRAIVD_HIS A
                     WHERE A.DEVICEID = PDeviceID
                       and TO_CHAR(A.REVTIME, 'yyyy-mm') = VDATE
                     GROUP BY A.DEVICEID) M,
                   JKPT_BASE_DEVICE N,
                   JKPT_BASE_ORG_ROAD L
             WHERE M.DEVICEID = N.DEVICEID
               AND N.ROADID = L.ROADID
               AND N.ROADID = PRoadID;
        end if;
        exit when I = 12;
        I := I + 1;
      end loop;
    end if;
    commit;
    OPEN PResultDataSet FOR
      SELECT COL2 ROADID,
             COL3 ROADNAME,
             COL4 REVTIME,
             COL5 DEVICENAME,
             COL6 DEVICEID,
             PORGID ORGID,
             VORGNAME ORGNAME,
             COL41 TRAFFLUX,
             COL42 MSBUSTRAFFLUX,
             COL43 MINIVANTRAFFLUX,
             COL44 BUSTRAFFLUX,
             COL45 MVANTRAFFLUX,
             COL46 LVANTRAFFLUX,
             COL47 VLVANTRAFFLUX,
             COL48 CONTAINERTRAFFLUX,
             COL49 TRACTORTRAFFLUX,
             COL50 MOTOTRAFFLUX,
             COL56 AVGSPEED,
             COL57 AVGHOLDRATE,
             COL58 MSBUSAVGSPEED,
             COL59 MINIVANAVGSPEED,
             COL60 BUSAVGSPEED,
             COL61 MVANAVGSPEED,
             COL62 LVANAVGSPEED,
             COL63 VLVANAVGSPEED,
             COL64 CONTAINERAVGSPEED,
             COL65 TRACTORAVGSPEED,
             COL66 MOTOAVGSPEED,
             NVL(COL43, 0) + NVL(COL45, 0) + NVL(COL46, 0) + NVL(COL47, 0) SUMTRUCKTRAFFLUX,
             NVL(COL42, 0) + NVL(COL44, 0) SUMBUSTRAFFLUX
        FROM JKPT_TJFX_COMM
       WHERE QUERYTYPE = VQUERYTYPE
         AND COL1 = PUserID
       ORDER BY LINE;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end;

  --气象信息统计报表
  procedure GetWeatherInfo(PStartDate     IN VARCHAR2,
                           PEndDate       IN VARCHAR2,
                           PRoadID        IN VARCHAR2,
                           PDeviceID      IN VARCHAR2,
                           PRoadSurface   IN VARCHAR2,
                           PORGID         IN VARCHAR2,
                           PReturnVal     OUT NUMBER,
                           PMSG           OUT varchar2,
                           PResultDataSet OUT Cur_Result) as
  begin
    PReturnVal := 1;
    PMSG       := '';
    if PRoadID is not null then
      if PDeviceID is not null then
        if PRoadSurface is not null then
          open PResultDataSet for
            SELECT *
              FROM V_WEATHERINFO A
             WHERE TO_CHAR(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
               AND TO_CHAR(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
               AND A.ROADID = PRoadID
               AND A.DEVICEID = PDeviceID
               AND A.ROADSURFACE = PRoadSurface
               AND A.ORGID = PORGID;
        else
          open PResultDataSet for
            SELECT *
              FROM V_WEATHERINFO A
             WHERE TO_CHAR(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
               AND TO_CHAR(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
               AND A.ROADID = PRoadID
               AND A.DEVICEID = PDeviceID
               AND A.ORGID = PORGID;
        end if;
      else
        if PRoadSurface is not null then
          open PResultDataSet for
            SELECT *
              FROM V_WEATHERINFO A
             WHERE TO_CHAR(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
               AND TO_CHAR(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
               AND A.ROADID = PRoadID
               AND A.ROADSURFACE = PRoadSurface
               AND A.ORGID = PORGID;
        else
          open PResultDataSet for
            SELECT *
              FROM V_WEATHERINFO A
             WHERE TO_CHAR(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
               AND TO_CHAR(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
               AND A.ROADID = PRoadID
               AND A.ORGID = PORGID;
        end if;
      end if;
    else
      if PDeviceID is not null then
        if PRoadSurface is not null then
          open PResultDataSet for
            SELECT *
              FROM V_WEATHERINFO A
             WHERE TO_CHAR(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
               AND TO_CHAR(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
               AND A.DEVICEID = PDeviceID
               AND A.ROADSURFACE = PRoadSurface
               AND A.ORGID = PORGID;
        else
          open PResultDataSet for
            SELECT *
              FROM V_WEATHERINFO A
             WHERE TO_CHAR(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
               AND TO_CHAR(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
               AND A.DEVICEID = PDeviceID
               AND A.ORGID = PORGID;
        end if;
      else
        if PRoadSurface is not null then
          open PResultDataSet for
            SELECT *
              FROM V_WEATHERINFO A
             WHERE TO_CHAR(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
               AND TO_CHAR(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
               AND A.ROADSURFACE = PRoadSurface
               AND A.ORGID = PORGID;
        else
          open PResultDataSet for
            SELECT *
              FROM V_WEATHERINFO A
             WHERE TO_CHAR(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
               AND TO_CHAR(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
               AND A.ORGID = PORGID;
        end if;
      end if;
    end if;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end;

  --信息发布报表
  procedure GetIntelligence(PStartDate     IN VARCHAR2,
                            PEndDate       IN VARCHAR2,
                            PRoadID        IN VARCHAR2,
                            PDeviceID      IN VARCHAR2,
                            PORGID         IN VARCHAR2,
                            PQueryType     IN VARCHAR2,
                            PReturnVal     OUT NUMBER,
                            PMSG           OUT varchar2,
                            PResultDataSet OUT Cur_Result) as
  begin
    PReturnVal := 1;
    PMSG       := '';
    --发布内容查询
    if PQueryType = '1' then
      if PDeviceID is not null then
        open PResultDataSet for
          SELECT A.ORGID,
                 A.ORGNAME,
                 A.DEVICEID,
                 A.DEVICENAME,
                 TO_CHAR(A.REVTIME, 'yyyy-mm-dd') REVTIME,
                 A.STAKEID,
                 A.CONTENT
            FROM V_INTELLIGENCE A
           WHERE A.ORGID = PORGID
             AND A.ROADID = PRoadID
             AND A.DEVICEID = PDeviceID
             AND to_char(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
             AND to_char(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
           order by a.REVTIME desc, a.DEVICENAME;
      else
        open PResultDataSet for
          SELECT A.ORGID,
                 A.ORGNAME,
                 A.DEVICEID,
                 A.DEVICENAME,
                 TO_CHAR(A.REVTIME, 'yyyy-mm-dd') REVTIME,
                 A.STAKEID,
                 A.CONTENT
            FROM V_INTELLIGENCE A
           WHERE A.ORGID = PORGID
             AND A.ROADID = PRoadID
             AND to_char(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
             AND to_char(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
           order by a.REVTIME desc, a.DEVICENAME;
      end if;
    else
      --发布次数统计
      if PDeviceID is not null then
        open PResultDataSet for
          SELECT M.ORGNAME, M.DEVICEID, M.DEVICENAME, M.TIMES, N.STAKEID
            FROM (SELECT A.ORGNAME, A.DEVICEID, A.DEVICENAME, COUNT(1) TIMES
                    FROM V_INTELLIGENCE A
                   WHERE A.ORGID = PORGID
                     AND A.ROADID = PRoadID
                     AND A.DEVICEID = PDeviceID
                     AND to_char(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
                     AND to_char(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
                   GROUP BY A.ORGNAME, A.DEVICEID, A.DEVICENAME) M,
                 JKPT_BASE_DEVICE N
           WHERE M.DEVICEID = N.DEVICEID
           ORDER BY M.TIMES DESC, M.DEVICENAME;
      else
        open PResultDataSet for
          SELECT M.ORGNAME, M.DEVICEID, M.DEVICENAME, M.TIMES, N.STAKEID
            FROM (SELECT A.ORGNAME, A.DEVICEID, A.DEVICENAME, COUNT(1) TIMES
                    FROM V_INTELLIGENCE A
                   WHERE A.ORGID = PORGID
                     AND A.ROADID = PRoadID
                     AND to_char(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
                     AND to_char(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
                   GROUP BY A.ORGNAME, A.DEVICEID, A.DEVICENAME) M,
                 JKPT_BASE_DEVICE N
           WHERE M.DEVICEID = N.DEVICEID
           ORDER BY M.TIMES DESC, M.DEVICENAME;
      end if;
    end if;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end;

  --卡口车辆报表
  procedure GetBayonetCar(PStartDate     IN VARCHAR2,
                          PEndDate       IN VARCHAR2,
                          PVEHICLEPLATE  IN VARCHAR2,
                          PReturnVal     OUT NUMBER,
                          PMSG           OUT varchar2,
                          PResultDataSet OUT Cur_Result) as
  begin
    PReturnVal := 1;
    PMSG       := '';
    if PVEHICLEPLATE is not null then
      open PResultDataSet for
        SELECT *
          FROM V_BayonetCar A
         WHERE to_char(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
           AND to_char(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
           AND A.VEHICLEPLATE LIKE '%' || PVEHICLEPLATE || '%';
    else
      open PResultDataSet for
        SELECT *
          FROM V_BayonetCar A
         WHERE to_char(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
           AND to_char(A.REVTIME, 'yyyy-mm-dd') <= PEndDate;
    end if;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end;

  --值班信息报表
  procedure GetRelieveGuard(PStartDate     IN VARCHAR2,
                            PEndDate       IN VARCHAR2,
                            PDUTYUSER      IN VARCHAR2,
                            PReturnVal     OUT NUMBER,
                            PMSG           OUT varchar2,
                            PResultDataSet OUT Cur_Result) as
  begin
    PReturnVal := 1;
    PMSG       := '';
    open PResultDataSet for
      SELECT *
        FROM V_RELIEVEGUARD A
       WHERE to_char(A.BEGINTIME, 'yyyy-mm-dd') >= PStartDate
         AND to_char(A.ENDTIME, 'yyyy-mm-dd') <= PEndDate
         AND A.MANONDUTY LIKE '%' || PDUTYUSER || '%'
       ORDER BY A.BEGINTIME DESC;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end;

  --车辆信息报表
  procedure GetVehicle(PStartDate     IN VARCHAR2,
                       PEndDate       IN VARCHAR2,
                       PVEHICLEPLATE  IN VARCHAR2,
                       PORGID         IN VARCHAR2,
                       PReturnVal     OUT NUMBER,
                       PMSG           OUT varchar2,
                       PResultDataSet OUT Cur_Result) as
  begin
    PReturnVal := 1;
    PMSG       := '';
    if PORGID is not null then
      if PVEHICLEPLATE is not null then
        open PResultDataSet for
          SELECT *
            FROM V_VEHICLE A
           WHERE to_char(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
             AND to_char(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
             AND A.VEHICLEPLATE LIKE '%' || PVEHICLEPLATE || '%'
             AND A.ORGID = PORGID
           ORDER BY A.ORGNAME, A.VEHICLEPLATE;
      else
        open PResultDataSet for
          SELECT *
            FROM V_VEHICLE A
           WHERE to_char(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
             AND to_char(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
             AND A.ORGID = PORGID
           ORDER BY A.ORGNAME, A.VEHICLEPLATE;
      end if;
    else
      if PVEHICLEPLATE is not null then
        open PResultDataSet for
          SELECT *
            FROM V_VEHICLE A
           WHERE to_char(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
             AND to_char(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
             AND A.VEHICLEPLATE LIKE '%' || PVEHICLEPLATE || '%'
           ORDER BY A.ORGNAME, A.VEHICLEPLATE;
      else
        open PResultDataSet for
          SELECT *
            FROM V_VEHICLE A
           WHERE to_char(A.REVTIME, 'yyyy-mm-dd') >= PStartDate
             AND to_char(A.REVTIME, 'yyyy-mm-dd') <= PEndDate
           ORDER BY A.ORGNAME, A.VEHICLEPLATE;
      end if;
    end if;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end;

  --基础信息报表
  procedure GetBasicInfo(PQueryType     IN VARCHAR2,
                         PORGID         IN VARCHAR2,
                         PROADID        IN VARCHAR2,
                         PReturnVal     OUT NUMBER,
                         PMSG           OUT varchar2,
                         PResultDataSet OUT Cur_Result) as
  begin
    PReturnVal := 1;
    PMSG       := '';
    if PQueryType = '1' then
      open PResultDataSet for
        select * from V_BASEORG A ORDER BY A.ORGNAME;
    elsif PQueryType = '2' then
      open PResultDataSet for
        select * from V_BASEROAD A ORDER BY A.ORGNAME, A.ROADNAME;
    elsif PQueryType = '3' then
      if PORGID is not null then
        open PResultDataSet for
          select *
            from V_BASEUSER A
           WHERE A.Userid <> 'admin'
             AND A.ORGID = PORGID
           ORDER BY A.ORGNAME, A.USERNAME;
      else
        open PResultDataSet for
          select *
            from V_BASEUSER A
           WHERE A.Userid <> 'admin'
           ORDER BY A.ORGNAME, A.USERNAME;
      end if;
    elsif PQueryType = '4' then
      if PORGID is not null then
        if PROADID is not null then
          open PResultDataSet for
            select *
              from V_BASEDEVICE A
             WHERE A.ORGID = PORGID
               AND A.ROADID = PROADID
             ORDER BY A.ORGID, A.ROADID, A.DEVICETYPE, A.DEVICENAME;
        else
          open PResultDataSet for
            select *
              from V_BASEDEVICE A
             WHERE A.ORGID = PORGID
             ORDER BY A.ORGID, A.ROADID, A.DEVICETYPE, A.DEVICENAME;
        end if;
      else
        if PROADID is not null then
          open PResultDataSet for
            select *
              from V_BASEDEVICE A
             WHERE A.ROADID = PROADID
             ORDER BY A.ORGID, A.ROADID, A.DEVICETYPE, A.DEVICENAME;
        else
          open PResultDataSet for
            select *
              from V_BASEDEVICE A
             ORDER BY A.ORGID, A.ROADID, A.DEVICETYPE, A.DEVICENAME;
        end if;
      end if;

    end if;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end;

  --路产损失报表
  procedure GetHightWayLoss(PStartDate     IN VARCHAR2,
                            PEndDate       IN VARCHAR2,
                            PORGID         IN VARCHAR2,
                            PReturnVal     OUT NUMBER,
                            PMSG           OUT varchar2,
                            PResultDataSet OUT Cur_Result) as
  begin
    PReturnVal := 1;
    PMSG       := '';
    if PORGID is not null then
      open PResultDataSet for
        SELECT M.*, N.ORGNAME, L.ROADNAME
          FROM (SELECT A.ORGID,
                       A.ROADID,
                       SUM(NVL(A.LOSTROADBASENUM, 0)) LOSTROADBASENUM,
                       SUM(NVL(A.LOSTROADBASEMONEY, 0)) LOSTROADBASEMONEY,
                       SUM(NVL(A.LOSTROADSURFACENUM, 0)) LOSTROADSURFACENUM,
                       SUM(NVL(A.LOSTROADSURFACEMONEY, 0)) LOSTROADSURFACEMONEY,
                       SUM(NVL(A.LOSTBRIDGENUM, 0)) LOSTBRIDGENUM,
                       SUM(NVL(A.LOSTBRIDGEMONEY, 0)) LOSTBRIDGEMONEY,
                       SUM(NVL(A.LOSTCULVERTNUM, 0)) LOSTCULVERTNUM,
                       SUM(NVL(A.LOSTCULVERTMONEY, 0)) LOSTCULVERTMONEY,
                       SUM(NVL(A.LOSTPROTECTIONNUM, 0)) LOSTPROTECTIONNUM,
                       SUM(NVL(A.LOSTPROTECTIONMOENY, 0)) LOSTPROTECTIONMOENY,
                       SUM(NVL(A.LOSTOTHERNUM, 0)) LOSTOTHERNUM,
                       SUM(NVL(A.LOSTOTHERMONEY, 0)) LOSTOTHERMONEY
                  FROM JKPT_SJGL_ROADEVENT A
                 WHERE A.ORGID = PORGID
                   AND to_char(A.RECTIME, 'yyyy-mm-dd') >= PStartDate
                   AND to_char(A.RECTIME, 'yyyy-mm-dd') <= PEndDate
                   AND A.SUBEVENTID <> 0
                   AND A.SUBEVENTID =
                       (SELECT MAX(B.SUBEVENTID)
                          FROM JKPT_SJGL_ROADEVENT B
                         WHERE A.EVENTID = B.EVENTID
                           AND B.SUBEVENTID <> 0
                           AND B.ORGID = PORGID
                           AND to_char(B.RECTIME, 'yyyy-mm-dd') >= PStartDate
                           AND to_char(B.RECTIME, 'yyyy-mm-dd') <= PEndDate)
                 GROUP BY A.ORGID, A.ROADID) M,
               JKPT_BASE_ORG N,
               JKPT_BASE_ORG_ROAD L
         WHERE M.ORGID = N.ORGID
           AND M.ROADID = L.ROADID;
    else
      open PResultDataSet for
        SELECT M.*, N.ORGNAME, L.ROADNAME
          FROM (SELECT A.ORGID,
                       A.ROADID,
                       SUM(NVL(A.LOSTROADBASENUM, 0)) LOSTROADBASENUM,
                       SUM(NVL(A.LOSTROADBASEMONEY, 0)) LOSTROADBASEMONEY,
                       SUM(NVL(A.LOSTROADSURFACENUM, 0)) LOSTROADSURFACENUM,
                       SUM(NVL(A.LOSTROADSURFACEMONEY, 0)) LOSTROADSURFACEMONEY,
                       SUM(NVL(A.LOSTBRIDGENUM, 0)) LOSTBRIDGENUM,
                       SUM(NVL(A.LOSTBRIDGEMONEY, 0)) LOSTBRIDGEMONEY,
                       SUM(NVL(A.LOSTCULVERTNUM, 0)) LOSTCULVERTNUM,
                       SUM(NVL(A.LOSTCULVERTMONEY, 0)) LOSTCULVERTMONEY,
                       SUM(NVL(A.LOSTPROTECTIONNUM, 0)) LOSTPROTECTIONNUM,
                       SUM(NVL(A.LOSTPROTECTIONMOENY, 0)) LOSTPROTECTIONMOENY,
                       SUM(NVL(A.LOSTOTHERNUM, 0)) LOSTOTHERNUM,
                       SUM(NVL(A.LOSTOTHERMONEY, 0)) LOSTOTHERMONEY
                  FROM JKPT_SJGL_ROADEVENT A
                 WHERE to_char(A.RECTIME, 'yyyy-mm-dd') >= PStartDate
                   AND to_char(A.RECTIME, 'yyyy-mm-dd') <= PEndDate
                   AND A.SUBEVENTID <> 0
                   AND A.SUBEVENTID =
                       (SELECT MAX(B.SUBEVENTID)
                          FROM JKPT_SJGL_ROADEVENT B
                         WHERE A.EVENTID = B.EVENTID
                           AND B.SUBEVENTID <> 0
                           AND to_char(B.RECTIME, 'yyyy-mm-dd') >= PStartDate
                           AND to_char(B.RECTIME, 'yyyy-mm-dd') <= PEndDate)
                 GROUP BY A.ORGID, A.ROADID) M,
               JKPT_BASE_ORG N,
               JKPT_BASE_ORG_ROAD L
         WHERE M.ORGID = N.ORGID
           AND M.ROADID = L.ROADID;
    end if;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end;

  --事件管理打印
  procedure GetRoadEventPrint(PEventID       IN NUMBER,
                              PSubEventID    IN NUMBER,
                              PPrintType     IN VARCHAR2,
                              PReturnVal     OUT NUMBER,
                              PMSG           OUT varchar2,
                              PResultDataSet OUT Cur_Result) AS
    VSQL VARCHAR(5000);
  begin
    PReturnVal := 1;
    PMSG       := '';
    VSQL       := 'with Temp as
 (select t.dicname, t.dicvalue, t.dicparentid, t.grouptype
    from jkpt_comm_paramdic t
   where t.grouptype in (' || chr(39) ||
                  'DeviceCtrlDirection' || chr(39) || ',
                         ' || chr(39) || 'AffectLanes' ||
                  chr(39) || ',
                         ' || chr(39) ||
                  'InfluenceLevelType' || chr(39) || ',
                         ' || chr(39) || 'DieType' ||
                  chr(39) || ',
                         ' || chr(39) || 'EventPosType' ||
                  chr(39) || ',
                         ' || chr(39) || 'UnKnowDieType' ||
                  chr(39) || ',
                         ' || chr(39) || 'EventLevel' ||
                  chr(39) || ',
                         ' || chr(39) || 'RoadSurfaceType' ||
                  chr(39) || ',
                         ' || chr(39) || 'WeatherType' ||
                  chr(39) || '))
select a.eventid,
       a.subeventid,
       to_char(a.rectime,' || chr(39) ||
                  'yyyy-MM-dd HH24:mi' || chr(39) ||
                  ') rectime,
       to_char(a.prestoretime,' || chr(39) ||
                  'yyyy-MM-dd HH24:mi' || chr(39) ||
                  ') prestoretime,
       to_char(a.frestoretime, ' || chr(39) ||
                  'yyyy-MM-dd HH24:mi' || chr(39) ||
                  ') frestoretime,
       (select count(1)
          from jkpt_sjgl_roadevent u
         where a.eventid = u.eventid) AllEventCount,
       (select replace(wm_concat(to_char(m.updatetime,
                                         ' || chr(39) ||
                  'yyyy-MM-dd HH24:mi:ss' || chr(39) || ')),
                       ' || chr(39) || ',' || chr(39) || ',
                       ' || chr(39) || '~' || chr(39) ||
                  ') updatetime
          from (select t.updatetime
                  from jkpt_sjgl_roadevent t
                 where t.eventid =' || PEventID || '
                 order by t.updatetime) m) allupdatetime,
       a.reporterinfo,
       b.dicname weathername,
       fun_get_paramdicname(' || chr(39) || 'EventType' ||
                  chr(39) || ', a.eventtype,' || chr(39) || '1' || chr(39) ||
                  ') eventname,
       c.dicname eventlevelname,
       n.roadname,
       d.dicname dirname,
       a.startstakeid,
       a.endstakeid,
       l.tunnelname,
       k.stationname,
       e.dicname roadsurfacename,
       f.dicname fluelanename,
       g.dicname fluelevelname,
       a.influencescop,
       a.content,
       a.processinfo,
       a.restoredetail,
       h.orgname,
       i.username,
       j.dicname eventposname,
       o.dicname diename,
       p.dicname unknowdiename,
       a.die,
       a.seriousinjury,
       a.slightinjury,
       a.relatedperson,
       a.holdperson,
       a.causetroublecarnum,
       a.badveh,
       a.holdveh,
       a.lostroadbasenum,
       a.lostroadbasemoney,
       a.lostroadsurfacenum,
       a.Lostroadsurfacemoney,
       a.lostbridgenum,
       a.lostbridgemoney,
       a.lostculvertnum,
       a.lostculvertmoney,
       a.lostprotectionnum,
       a.lostprotectionmoeny,
       a.lostothernum,
       a.lostothermoney,
       a.eventtype,
       ' || chr(39) || '' || chr(39) || ' eventparentid,
       ' || chr(39) || '' || chr(39) ||
                  ' eventparentname,
       a.roadid,
       a.orgid,
       a.dir,
       a.eventlevel,
       a.eventpos,
       a.fillname,
       a.fillphone,
       a.influencelane,
       a.INFLUENCELANEDESC,
       a.influencelevel,
       a.isinjuryordie,
       a.isinjuryunknow,
       a.isover,
       a.lostotheritemname,
       a.reader,
       a.readtime,
       a.region1,
       a.region2,
       a.roadsurface,
       a.title,
       a.tunnelid,
       a.weather,
       a.istop,
       a.tollid,
       k.STATIONNAME tollname,
       to_char(a.updatetime,' || chr(39) ||
                  'yyyy-MM-dd HH24:mi' || chr(39) || ') updatetime
  from jkpt_sjgl_roadevent a,
       (SELECT * FROM Temp t WHERE t.GROUPTYPE=' || chr(39)|| 'WeatherType'||chr(39)||')  b,
       Temp                c,
       jkpt_base_org_road  m,
       jkpt_base_road      n,
       Temp                d,
       jkpt_base_tunnel    l,
       jkpt_base_station   k,
       Temp                e,
       Temp                f,
       Temp                g,
       jkpt_base_org       h,
       jkpt_base_user      i,
       Temp                j,
       Temp                o,
       Temp                p
 where a.eventid = ' || PEventID;

    if PPrintType = '1' then
      VSQL := VSQL || ' and a.subeventid =' || PSubEventID;
    end if;
    VSQL := VSQL || ' and m.adminid = n.roadid
   and a.roadid = m.roadid
   and a.weather = b.dicvalue(+)

   and a.eventlevel = c.dicvalue
   and c.grouptype = ' || chr(39) || 'EventLevel' || chr(39) || '
   and a.dir = d.dicvalue
   and d.grouptype = ' || chr(39) || 'DeviceCtrlDirection' ||
            chr(39) || '
   and a.tunnelid = l.tunnelid(+)
   and a.tollid = k.stationid(+)
   and a.roadsurface = e.dicvalue
   and e.grouptype =' || chr(39) || 'RoadSurfaceType' || chr(39) || '
   and a.influencelane = f.dicvalue
   and f.grouptype = ' || chr(39) || 'AffectLanes' || chr(39) || '
   and a.influencelevel = g.dicvalue
   and g.grouptype = ' || chr(39) || 'InfluenceLevelType' ||
            chr(39) || '
   and a.orgid = h.orgid
   and a.fillname = i.userid
   and a.eventpos = j.dicvalue
   and j.grouptype =' || chr(39) || 'EventPosType' || chr(39) || '
   and a.isinjuryordie = o.dicvalue
   and o.grouptype = ' || chr(39) || 'DieType' || chr(39) || '
   and a.isinjuryunknow = p.dicvalue
   and p.grouptype = ' || chr(39) || 'UnKnowDieType' || chr(39) ||
            ' order by a.subeventid';
    dbms_output.put_line(VSQL);
    open PResultDataSet for VSQL;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end;
  --路网报表服务水平报表
  procedure GetRoadNetworkServiceLevel(PStartDate     IN VARCHAR2,
                                       PEndDate       IN VARCHAR2,
                                       PReturnVal     OUT NUMBER,
                                       PMSG           OUT varchar2,
                                       PResultDataSet OUT Cur_Result) as
    VDays  number; --两个日期间隔天数
    VSQL_1 varchar2(1000);
    VSQL_2 varchar2(1000);
    VSQL_3 varchar2(100);
    VSQL   varchar2(5000);
  begin
    PReturnVal := 1;
    PMSG       := '';
    select trunc(to_date(PEndDate, 'yyyy-mm-dd') -
                 to_date(PStartDate, 'yyyy-mm-dd')) + 1
      into VDays
      from dual;
    VDays  := VDays * 24 * 2; --天数*24小时*2车道
    VSQL_1 := 'SELECT d.orgname,b.roadname,a.devicename,round(nvl(sum(c.trafflux), 0) / ' ||
              VDays ||') trafflux
              FROM jkpt_Base_Device a inner join jkpt_base_org d on a.orgid = d.orgid inner join jkpt_base_org_road b
              on a.roadid = b.roadid left join ';
    VSQL_2 := ' c on a.deviceid = c.deviceid
              and c.revtime <= to_date(' || chr(39) ||
              PEndDate || ' 23:59:59' || chr(39) || ',' || chr(39) ||
              'yyyy-mm-dd HH24:mi:ss' || chr(39) ||
              ') and c.revtime >= to_date(' || chr(39) || PStartDate ||
              ' 00:00:00' || chr(39) || ',' || chr(39) ||
              'yyyy-mm-dd HH24:mi:ss' || chr(39) ||
              ')  where a.devicetype =' || chr(39) || '100' || chr(39) || '';
    VSQL_3 := ' group by d.orgname, b.roadname, a.devicename';
    VSQL   := 'select orgname,roadname,devicename,trafflux,case  when trafflux between 0 and 749 then ' ||
              chr(39) || '1级' || chr(39) ||
              ' when trafflux between 750 and 1599 then ' || chr(39) || '2级' ||
              chr(39) || ' when trafflux between 1600 and 1949 then ' ||
              chr(39) || '3级' || chr(39) ||
              ' when trafflux between 1950 and 2199 then ' || chr(39) || '4级' ||
              chr(39) || ' when trafflux between 2200 and 99999999 then ' ||
              chr(39) || '5级' || chr(39) ||
              ' end traffluxname from (';
    VSQL   := VSQL || VSQL_1 || 'jkpt_base_traivd_his' || VSQL_2 ||
              ' and a.devicesubtype=' || chr(39) || '1004' || chr(39) || '' ||
              VSQL_3 || ' union all ' || VSQL_1 || 'jkpt_base_traiivd_his' ||
              VSQL_2 || ' and a.devicesubtype=' || chr(39) || '1005' ||
              chr(39) || '' || VSQL_3 || ' union all ' || VSQL_1 ||
              'jkpt_base_traiiivd_his' || VSQL_2 || ' and a.devicesubtype=' ||
              chr(39) || '1006' || chr(39) || '' || VSQL_3;
    VSQL   := VSQL || ') order by orgname,roadname,devicename';
    --dbms_output.put_line(VSQL);
    open PResultDataSet for VSQL;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end;

  --路段畅通级别报表
  procedure GetRoadFreeFlowingLevel(PStartDate     IN VARCHAR2,
                                    PEndDate       IN VARCHAR2,
                                    PReturnVal     OUT NUMBER,
                                    PMSG           OUT varchar2,
                                    PResultDataSet OUT Cur_Result) as
    VSQL_1 varchar2(1000);
    VSQL_2 varchar2(1000);
    VSQL_3 varchar2(100);
    VSQL   varchar2(5000);
  begin
    PReturnVal := 1;
    PMSG       := '';
    VSQL_1     := 'SELECT d.orgname,b.roadname,a.devicename,nvl(avg(c.avgspeed), 100) avgspeed
              FROM jkpt_Base_Device a inner join jkpt_base_org d on a.orgid = d.orgid inner join jkpt_base_org_road b
              on a.roadid = b.roadid left join ';
    VSQL_2     := ' c on a.deviceid = c.deviceid
              and c.revtime <= to_date(' || chr(39) ||
                  PEndDate || ' 23:59:59' || chr(39) || ',' || chr(39) ||
                  'yyyy-mm-dd HH24:mi:ss' || chr(39) ||
                  ') and c.revtime >= to_date(' || chr(39) || PStartDate ||
                  ' 00:00:00' || chr(39) || ',' || chr(39) ||
                  'yyyy-mm-dd HH24:mi:ss' || chr(39) ||
                  ')  where a.devicetype =' || chr(39) || '100' || chr(39) || '';
    VSQL_3     := ' group by d.orgname, b.roadname, a.devicename';
    VSQL       := 'select orgname,roadname,devicename,avgspeed,case  when avgspeed between 0 and 29.99 then ' ||
              chr(39) || '严重拥堵' || chr(39) ||
              ' when avgspeed between 30 and 49.99 then ' || chr(39) || '中度拥堵' ||
              chr(39) || ' when avgspeed between 50 and 69.99 then ' ||
              chr(39) || '轻度拥堵' || chr(39) ||
              ' when avgspeed between 70 and 89.99 then ' || chr(39) || '基本畅通' ||
              chr(39) || ' when avgspeed between 90 and 99999999 then ' ||
              chr(39) || '畅通' || chr(39) ||
              ' end avgspeedname from (';
    VSQL       := VSQL || VSQL_1 || 'jkpt_base_traivd_his' || VSQL_2 ||
                  ' and a.devicesubtype=' || chr(39) || '1004' || chr(39) || '' ||
                  VSQL_3 || ' union all ' || VSQL_1 ||
                  'jkpt_base_traiivd_his' || VSQL_2 ||
                  ' and a.devicesubtype=' || chr(39) || '1005' || chr(39) || '' ||
                  VSQL_3 || ' union all ' || VSQL_1 ||
                  'jkpt_base_traiiivd_his' || VSQL_2 ||
                  ' and a.devicesubtype=' || chr(39) || '1006' || chr(39) || '' ||
                  VSQL_3;
    VSQL       := VSQL || ') order by orgname,roadname,devicename';
    --dbms_output.put_line(VSQL);
    open PResultDataSet for VSQL;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end;


    --路况信息、综合信息打印
  procedure GetEventPrint(PEventID       IN NUMBER,
                              PSubEventID    IN NUMBER,
                              PPrintType     IN VARCHAR2,
                              PReturnVal     OUT NUMBER,
                              PMSG           OUT varchar2,
                              PResultDataSet OUT Cur_Result) AS
    VSQL VARCHAR(5000);
  begin
    PReturnVal := 1;
    PMSG       := '';
    VSQL       := 'with Temp as
 (select t.dicname, t.dicvalue, t.dicparentid, t.grouptype
    from jkpt_comm_paramdic t
   where t.grouptype in (' || chr(39) ||
                  'DeviceCtrlDirection' || chr(39) || ',
                         ' || chr(39) || 'AffectLanes' ||
                  chr(39) || ',
                         ' || chr(39) ||
                  'InfluenceLevelType' || chr(39) || ',
                         ' || chr(39) || 'DieType' ||
                  chr(39) || ',
                         ' || chr(39) || 'EventPosType' ||
                  chr(39) || ',
                         ' || chr(39) || 'UnKnowDieType' ||
                  chr(39) || ',
                         ' || chr(39) || 'EventLevel' ||
                  chr(39) || ',
                         ' || chr(39) || 'RoadSurfaceType' ||
                  chr(39) || ',
                         ' || chr(39) || 'WeatherType' ||
                  chr(39) || ',
                         ' || chr(39) || 'InfluenceValueType' || chr(39) || ',
                         ' || chr(39) || 'InformationType' || chr(39) || ',
                         ' || chr(39) || 'RoadConditionType' || chr(39) || '))
select a.eventid,
       a.subeventid,
       to_char(a.rectime,' || chr(39) ||
                  'yyyy-MM-dd HH24:mi' || chr(39) ||
                  ') rectime,
       to_char(a.prestoretime,' || chr(39) ||
                  'yyyy-MM-dd HH24:mi' || chr(39) ||
                  ') prestoretime,
       to_char(a.frestoretime, ' || chr(39) ||
                  'yyyy-MM-dd HH24:mi' || chr(39) ||
                  ') frestoretime,
       (select count(1)
          from JKPT_SJGL_EVENT u
         where a.eventid = u.eventid) AllEventCount,
       (select replace(wm_concat(to_char(m.updatetime,
                                         ' || chr(39) ||
                  'yyyy-MM-dd HH24:mi:ss' || chr(39) || ')),
                       ' || chr(39) || ',' || chr(39) || ',
                       ' || chr(39) || '~' || chr(39) ||
                  ') updatetime
          from (select t.updatetime
                  from JKPT_SJGL_EVENT t
                 where t.eventid =' || PEventID || '
                 order by t.updatetime) m) allupdatetime,
       a.reporterinfo,
       b.dicname weathername,
       Q.DICNAME EVENTNAME,
       c.dicname eventlevelname,
       n.roadname,
       d.dicname dirname,
       a.startstakeid,
       a.endstakeid,
       l.tunnelname,
       k.stationname,
       e.dicname roadsurfacename,
       f.dicname fluelanename,
       g.dicname fluelevelname,
       a.influencescop,
       a.content,
       a.processinfo,
       a.restoredetail,
       h.orgname,
       i.username,
       j.dicname eventposname,
       o.dicname diename,
       p.dicname unknowdiename,
       a.die,
       a.seriousinjury,
       a.slightinjury,
       a.relatedperson,
       a.holdperson,
       a.causetroublecarnum,
       a.badveh,
       a.holdveh,
       a.lostroadbasenum,
       a.lostroadbasemoney,
       a.lostroadsurfacenum,
       a.Lostroadsurfacemoney,
       a.lostbridgenum,
       a.lostbridgemoney,
       a.lostculvertnum,
       a.lostculvertmoney,
       a.lostprotectionnum,
       a.lostprotectionmoeny,
       a.lostothernum,
       a.lostothermoney,
       a.eventtype,
       ' || chr(39) || '' || chr(39) || ' eventparentid,
       ' || chr(39) || '' || chr(39) ||
                  ' eventparentname,
       a.roadid,
       a.orgid,
       a.dir,
       a.eventlevel,
       a.eventpos,
       a.fillname,
       a.fillphone,
       a.influencelane,
       a.INFLUENCELANEDESC,
       a.influencelevel,
       a.isinjuryordie,
       a.isinjuryunknow,
       a.isover,
       a.lostotheritemname,
       a.reader,
       a.readtime,
       a.region1,
       a.region2,
       a.roadsurface,
       a.title,
       a.tunnelid,
       a.weather,
       a.istop,
       a.tollid,
       k.STATIONNAME tollname,
       to_char(a.updatetime,' || chr(39) ||
                  'yyyy-MM-dd HH24:mi' || chr(39) || ') updatetime,
       g.DICNAME INFLUENCELEVELDESC,
       a.DIRDESC
  from JKPT_SJGL_EVENT a
 LEFT JOIN (SELECT * FROM TEMP T WHERE T.GROUPTYPE =' || chr(39) || 'WeatherType'|| chr(39)|| ') B
    ON (A.WEATHER = B.DICVALUE)
  LEFT JOIN TEMP C
    ON (A.EVENTLEVEL = C.DICVALUE AND C.GROUPTYPE = ' || chr(39) || 'EventLevel'|| chr(39)|| ')
  LEFT JOIN JKPT_BASE_ORG_ROAD M ON A.ROADID = M.ROADID
  LEFT JOIN JKPT_BASE_ROAD N ON M.ADMINID = N.ROADID
  LEFT JOIN TEMP D
    ON (A.DIR = D.DICVALUE AND D.GROUPTYPE = ' || chr(39) || 'DeviceCtrlDirection' || chr(39)|| ')
  LEFT JOIN JKPT_BASE_TUNNEL L
    ON A.TUNNELID = L.TUNNELID
  LEFT JOIN JKPT_BASE_STATION K
    ON A.TOLLID = K.STATIONID
  LEFT JOIN TEMP E
    ON (A.ROADSURFACE = E.DICVALUE AND E.GROUPTYPE = ' || chr(39) ||  'RoadSurfaceType' || chr(39)|| ')
  LEFT JOIN TEMP F
    ON A.INFLUENCELANE = F.DICVALUE
   AND F.GROUPTYPE = ' || chr(39) ||  'AffectLanes' || chr(39)|| '
  LEFT JOIN TEMP G
    ON A.INFLUENCELEVEL = G.DICVALUE
   AND G.GROUPTYPE = ' || chr(39) ||  'InfluenceValueType' || chr(39)|| '
  LEFT JOIN JKPT_BASE_ORG H
    ON A.ORGID = H.ORGID
  LEFT JOIN JKPT_BASE_USER I
    ON A.FILLNAME = I.USERID
  LEFT JOIN TEMP J
    ON A.EVENTPOS = J.DICVALUE
   AND J.GROUPTYPE = ' || chr(39) ||  'EventPosType' || chr(39)|| '
  LEFT JOIN TEMP O
    ON A.ISINJURYORDIE = O.DICVALUE
   AND O.GROUPTYPE = ' || chr(39) ||  'DieType' || chr(39)|| '
  LEFT JOIN TEMP P
    ON A.ISINJURYUNKNOW = P.DICVALUE
   AND P.GROUPTYPE = ' || chr(39) ||  'UnKnowDieType' || chr(39)|| '
  LEFT JOIN TEMP Q
    ON (A.EVENTTYPE = Q.DICVALUE AND (Q.GROUPTYPE = ' || chr(39) ||  'InformationType' || chr(39)|| ' OR
       Q.GROUPTYPE = ' || chr(39) ||  'RoadConditionType' || chr(39)|| '))
 where a.eventid = ' || PEventID;

    if PPrintType = '1' then
      VSQL := VSQL || ' and a.subeventid =' || PSubEventID;
    end if;

    VSQL := VSQL || ' ORDER BY A.SUBEVENTID';

    dbms_output.put_line(VSQL);
    open PResultDataSet for VSQL;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end;

end PG_JKPT_REPORT;

/

