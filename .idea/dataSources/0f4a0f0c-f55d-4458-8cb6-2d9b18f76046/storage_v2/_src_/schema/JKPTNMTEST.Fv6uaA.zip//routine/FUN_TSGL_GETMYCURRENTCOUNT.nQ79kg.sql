create function FUN_TSGL_GETMYCURRENTCOUNT(pOrgID in varchar2)
  return number is
  mCount       number;
  mIsSubCenter number;
begin
  select count(*)
    into mIsSubCenter
    from jkpt_tsgl_orgrelation t
   where t.grouptype = 'SubCenter'
     and t.orgid = pOrgID;

  if (mIsSubCenter = 0) then
    select count(*)
      into mCount
      from jkpt_tsgl_complaint a, jkpt_tsgl_auditinfo b
     where a.pkid = b.fkid
       and b.iscurrent = 1
       and a.currentorgid = pOrgID
       and a.isarchive <> 1
       and a.isrecyclebin <> 1;
  else
    select count(*)
      into mCount
      from jkpt_tsgl_complaint a, jkpt_tsgl_auditinfo b
     where a.pkid = b.fkid
       and b.iscurrent = 1
       and a.currentorgid = pOrgID
       and a.isarchive <> 1
       and a.isrecyclebin <> 1
       and nvl(b.remark_1, ' ') <> '1';--对于分中心来说 已经受理的不再提示
  end if;

  return mCount;

end FUN_TSGL_GETMYCURRENTCOUNT;
/

