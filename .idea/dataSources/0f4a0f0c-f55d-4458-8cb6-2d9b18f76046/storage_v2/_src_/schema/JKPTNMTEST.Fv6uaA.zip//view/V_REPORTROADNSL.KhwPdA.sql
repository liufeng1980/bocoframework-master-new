create view V_REPORTROADNSL as
select '' orgname,'' roadname,'' devicename,'' trafflux,'' traffluxname from dual
/

