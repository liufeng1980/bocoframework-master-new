create package body PG_JKPT_YJCZ_STOCK is
  --xiu gai ru ku
  procedure PROC_InstoreUpdate(pOrderID        IN number,
                               pCount          IN number,
                               pType           IN number,
                               pQADate         IN VARCHAR2,
                               pExpirationDate IN VARCHAR2,
                               pSupplierID     IN VARCHAR2,
                               pPrice          in number,
                               pOrgID          in varchar2,
                               pStoreID        in number,
                               pInvoice        in varchar2,
                               pHaveInvoice    in number,
                               pModifyUserID   in varchar2,
                               pReturnVal      OUT NUMBER,
                               pMSG            OUT varchar2) as
    mNewInCount  number; --xiu gai hou de jin huo shu liang 
    mNowOutCount number; --dang qian de chu huo shu liang
    mGoodsID     number;
  begin
    pReturnVal := 1;
    pMSG       := '';
  
    --jin huo chu liang bu neng xiao yu chu huo shu liang
    select goodsid
      into mGoodsID
      from jkpt_yjcz_instore
     where orderid = pOrderID;
  
    select nvl(sum(count), 0) + pCount
      into mNewInCount
      from jkpt_yjcz_instore
     where goodsid = mGoodsID
       and orderid <> pOrderID;
  
    select nvl(sum(count), 0)
      into mNowOutCount
      from jkpt_yjcz_outstore
     where goodsid = mGoodsID;
  
    if (mNewInCount - mNowOutCount < 0) then
      pReturnVal := 0;
      pMSG       := '进货总数不能小于出货总数 该物资出货数量:' || mNowOutCount || ',修改后进货数量:' ||
                    mNewInCount;
    else
      update jkpt_yjcz_instore t
         set t.count          = PCount,
             t.type           = PType,
             t.qadate         = to_date(PQADate,'yyyy-MM-dd'),
             t.expirationdate = to_date(PExpirationDate,'yyyy-MM-dd'),
             t.supplierid     = PSupplierID,
             t.price          = PPrice,
             t.totalprice     = PPrice * PCount,
             t.orgid          = POrgID,
             t.storeid        = PStoreID,
             t.invoice        = PInvoice,
             t.haveinvoice    = PHaveInvoice,
             t.modifyuserid   = PModifyUserID,
             t.modifytime     = sysdate
       where t.orderid = POrderID;
    
      commit;
    end if;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end PROC_InstoreUpdate;

  --shan chu ru ku
  procedure PROC_InstoreDel(pOrderID   IN number,
                            pReturnVal OUT NUMBER,
                            pMSG       OUT varchar2) as
    mNewInCount  number; --xiu gai hou de jin huo shu liang 
    mNowOutCount number; --dang qian de chu huo shu liang
    mGoodsID     number; --wu zi id
  begin
    pReturnVal := 1;
    pMSG       := '';
  
    --jin huo chu liang bu neng xiao yu chu huo shu liang
    select goodsid
      into mGoodsID
      from jkpt_yjcz_instore
     where orderid = pOrderID;
  
    select nvl(sum(count), 0)
      into mNewInCount
      from jkpt_yjcz_instore
     where goodsid = mGoodsID
       and orderid <> pOrderID;
  
    select nvl(sum(count), 0)
      into mNowOutCount
      from jkpt_yjcz_outstore
     where goodsid = mGoodsID;
  
    if (mNewInCount - mNowOutCount < 0) then
      pReturnVal := 0;
      pMSG       := '进货总数不能小于出货总数 该物资出货数量:' || mNowOutCount || ',删除后进货数量:' ||
                    mNewInCount;
    else
      delete jkpt_yjcz_instore where orderid = pOrderID;
    
      commit;
    end if;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end PROC_InstoreDel;

  --tian jia chu ku
  procedure PROC_OutstoreAdd(pGoodsID        IN number,
                             pCount          IN number,
                             pType           IN number,
                             pGetOrgID       IN VARCHAR2,
                             pReceiptor      in varchar2,
                             pCreationUserID in varchar2,
                             pReturnVal      OUT NUMBER,
                             pMSG            OUT varchar2) as
    mNowInCount  number; --xiu gai hou de jin huo shu liang 
    mNewOutCount number;
    mNowOutCount number;
  begin
    pReturnVal := 1;
    pMSG       := '';
  
    --chu ku shu liang bu neng da yu ku cun shu liang
    select nvl(sum(count), 0)
      into mNowInCount
      from jkpt_yjcz_instore
     where goodsid = pGoodsID;
  
    select nvl(sum(count), 0)
      into mNowOutCount
      from jkpt_yjcz_outstore
     where goodsid = pGoodsID;
  
    mNewOutCount := mNowOutCount + pCount;
  
    if (mNowInCount - mNewOutCount < 0) then
      pReturnVal := 0;
      pMSG       := '出库数量不能大于库存数量 库存实际数量:' || (mNowInCount - mNowOutCount);
    else
      insert into jkpt_yjcz_outstore
        (orderid,
         goodsid,
         count,
         type,
         outtime,
         getorgid,
         creationuserid,
         creationtime,
         Receiptor)
      values
        (SEQ_YJCZ_OUTSTORE_ID.Nextval,
         pGoodsID,
         pCount,
         pType,
         sysdate,
         pGetOrgID,
         pCreationUserID,
         sysdate,
         pReceiptor);
      commit;
    end if;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end PROC_OutstoreAdd;

  --xiu gai chu ku
  procedure PROC_OutstoreUpdate(pOrderID      IN number,
                                pCount        IN number,
                                pType         IN number,
                                pGetOrgID     IN VARCHAR2,
                                pReceiptor    in varchar2,
                                pModifyUserID in varchar2,
                                pReturnVal    OUT NUMBER,
                                pMSG          OUT varchar2) as
    mNowInCount  number; --xiu gai hou de jin huo shu liang 
    mGoodsID     number;
    mNewOutCount number;
  begin
    pReturnVal := 1;
    pMSG       := '';
    --chu ku shu liang bu neng da yu ku cun shu liang
    select goodsid
      into mGoodsID
      from jkpt_yjcz_outstore
     where orderid = pOrderID;
  
    select nvl(sum(count), 0)
      into mNowInCount
      from jkpt_yjcz_instore
     where goodsid = mGoodsID;
  
    select nvl(sum(count), 0) + pCount
      into mNewOutCount
      from jkpt_yjcz_outstore
     where goodsid = mGoodsID
       and orderid <> pOrderID;
  
    if (mNowInCount - mNewOutCount < 0) then
      pReturnVal := 0;
      pMSG       := '出库总数不能大于入库总数 入库总数:' || mNowInCount || ',修改后出库总数:' ||
                    mNewOutCount;
    else
      update jkpt_yjcz_outstore t
         set t.count        = pCount,
             t.type         = pType,
             t.getorgid     = pGetOrgID,
             t.modifyuserid = pModifyUserID,
             t.modifytime   = sysdate,
             t.receiptor    = pReceiptor
       where t.orderid = pOrderID;
    
      commit;
    end if;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      PReturnVal := 0;
      PMSG       := '执行失败';
  end PROC_OutstoreUpdate;

end PG_JKPT_YJCZ_STOCK;
/

