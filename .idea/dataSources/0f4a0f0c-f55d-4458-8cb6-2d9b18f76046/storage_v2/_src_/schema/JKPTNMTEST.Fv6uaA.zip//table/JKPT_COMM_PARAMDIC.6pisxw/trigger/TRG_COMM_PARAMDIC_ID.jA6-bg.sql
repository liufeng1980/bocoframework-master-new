create trigger TRG_COMM_PARAMDIC_ID
  before insert
  on JKPT_COMM_PARAMDIC
  for each row
declare
  -- local variables here
begin
  select seq_comm_paramdic_id.nextval into :new.id from dual;
end trg_comm_paramDic_id;

/

