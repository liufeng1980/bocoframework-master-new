create view V_ACCIDENT as
select a.userid,
       a.roadid,
       b.roadname,
       a.startstakeid,
       a.endstakeid,
       'K' || a.startstakeid || '—K' || a.endstakeid STAKESCOPE,
       a.accidentnum,
       b.gisroadid
  from jkpt_tjfx_accidentresult a, jkpt_base_road b,jkpt_base_org_road c
 where a.roadid = c.roadid and b.roadid=c.adminid
 order by a.accidentnum desc
/

