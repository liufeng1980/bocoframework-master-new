create view V_BASEDEVICE as
select A.ROADID,
       B.ROADNAME,
       A.ORGID,
       C.ORGNAME,
       A.DEVICEID,
       A.TUNNELID,
       D.TUNNELNAME,
       A.DEVICENAME,
       A.MANUFACTURER,
       A.DEVICETYPE,
       fun_get_paramdicname('DeviceType',A.DEVICETYPE) DEVICETYPENAME,
       A.STAKEID,
       A.DIRECTION,
       fun_get_paramdicname('DeviceCtrlDirection',A.DIRECTION) DIRECTIONNAME,
       A.DEVICESTATUS,
       fun_get_paramdicname('DeviceStatus',a.devicestatus) DEVICESTATUSNAME,
       A.LONGITUDE,
       A.LATITUDE,
       A.WRITETIME,
       A.ALIASNAME,
       A.REMARK
  from JKPT_BASE_DEVICE A
 INNER JOIN JKPT_BASE_ORG_ROAD B
    ON A.ROADID = B.ROADID
 INNER JOIN JKPT_BASE_ORG C
    ON A.ORGID = C.ORGID
 LEFT JOIN JKPT_BASE_TUNNEL D
   ON A.TUNNELID=D.TUNNELID
/

