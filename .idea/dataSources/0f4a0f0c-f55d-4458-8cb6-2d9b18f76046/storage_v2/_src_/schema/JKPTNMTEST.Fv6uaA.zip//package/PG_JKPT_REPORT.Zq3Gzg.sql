create package PG_JKPT_REPORT is

  -- Author  : 张建中
  -- Created : 2015/5/10 8:25:32
  -- Purpose : 定义交通流量查询报表

  -- 定义游标
  type Cur_Result is ref cursor;

  -- 交通流量查询报表
  procedure GetTRAFFICFLUX(PUserID        IN VARCHAR2,
                           PQueryDate     IN VARCHAR2,
                           PRoadID        IN VARCHAR2,
                           PDeviceID      IN VARCHAR2,
                           PValidateMode  IN VARCHAR2,
                           PORGID         IN VARCHAR2,
                           PReturnVal     OUT NUMBER,
                           PMSG           OUT varchar2,
                           PResultDataSet OUT Cur_Result);

  --气象信息统计报表
  procedure GetWeatherInfo(PStartDate     IN VARCHAR2,
                           PEndDate       IN VARCHAR2,
                           PRoadID        IN VARCHAR2,
                           PDeviceID      IN VARCHAR2,
                           PRoadSurface   IN VARCHAR2,
                           PORGID         IN VARCHAR2,
                           PReturnVal     OUT NUMBER,
                           PMSG           OUT varchar2,
                           PResultDataSet OUT Cur_Result);

  --信息发布报表
  procedure GetIntelligence(PStartDate     IN VARCHAR2,
                            PEndDate       IN VARCHAR2,
                            PRoadID        IN VARCHAR2,
                            PDeviceID      IN VARCHAR2,
                            PORGID         IN VARCHAR2,
                            PQueryType     IN VARCHAR2,
                            PReturnVal     OUT NUMBER,
                            PMSG           OUT varchar2,
                            PResultDataSet OUT Cur_Result);

  --卡口车辆报表
  procedure GetBayonetCar(PStartDate     IN VARCHAR2,
                          PEndDate       IN VARCHAR2,
                          PVEHICLEPLATE  IN VARCHAR2,
                          PReturnVal     OUT NUMBER,
                          PMSG           OUT varchar2,
                          PResultDataSet OUT Cur_Result);
  --值班信息报表
  procedure GetRelieveGuard(PStartDate     IN VARCHAR2,
                            PEndDate       IN VARCHAR2,
                            PDUTYUSER      IN VARCHAR2,
                            PReturnVal     OUT NUMBER,
                            PMSG           OUT varchar2,
                            PResultDataSet OUT Cur_Result);

  --车辆信息报表
  procedure GetVehicle(PStartDate     IN VARCHAR2,
                       PEndDate       IN VARCHAR2,
                       PVEHICLEPLATE  IN VARCHAR2,
                       PORGID         IN VARCHAR2,
                       PReturnVal     OUT NUMBER,
                       PMSG           OUT varchar2,
                       PResultDataSet OUT Cur_Result);

  --基础信息报表
  procedure GetBasicInfo(PQueryType     IN VARCHAR2,
                         PORGID         IN VARCHAR2,
                         PROADID        IN VARCHAR2,
                         PReturnVal     OUT NUMBER,
                         PMSG           OUT varchar2,
                         PResultDataSet OUT Cur_Result);

  --路产损失报表
  procedure GetHightWayLoss(PStartDate     IN VARCHAR2,
                            PEndDate       IN VARCHAR2,
                            PORGID         IN VARCHAR2,
                            PReturnVal     OUT NUMBER,
                            PMSG           OUT varchar2,
                            PResultDataSet OUT Cur_Result);

  --事件管理打印
  procedure GetRoadEventPrint(PEventID       IN NUMBER,
                              PSubEventID    IN NUMBER,
                              PPrintType     IN VARCHAR2,
                              PReturnVal     OUT NUMBER,
                              PMSG           OUT varchar2,
                              PResultDataSet OUT Cur_Result);

  --路网报表服务水平报表
  procedure GetRoadNetworkServiceLevel(PStartDate     IN VARCHAR2,
                                       PEndDate       IN VARCHAR2,
                                       PReturnVal     OUT NUMBER,
                                       PMSG           OUT varchar2,
                                       PResultDataSet OUT Cur_Result);

  --路段畅通级别报表
  procedure GetRoadFreeFlowingLevel(PStartDate     IN VARCHAR2,
                                    PEndDate       IN VARCHAR2,
                                    PReturnVal     OUT NUMBER,
                                    PMSG           OUT varchar2,
                                    PResultDataSet OUT Cur_Result);

     --路况信息、综合信息打印
  procedure GetEventPrint(PEventID       IN NUMBER,
                              PSubEventID    IN NUMBER,
                              PPrintType     IN VARCHAR2,
                              PReturnVal     OUT NUMBER,
                              PMSG           OUT varchar2,
                              PResultDataSet OUT Cur_Result);

end PG_JKPT_REPORT;

/

